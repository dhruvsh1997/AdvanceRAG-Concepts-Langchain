from typing import TypedDict, List, Optional, Any
from datetime import date, datetime
import openai
import logging

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from .message import (activity_5_8, activity_8_15, activity_15_18,
                      activity_else, activity_sunday,
                      )
from .prompt import (HORSE_HUMAN_TURN, HORSE_HUMAN_TURN_RETRY, HORSE_SYSTEM_PROMPT)
from .utils import get_greeting
from .chat_integration import QUALITY_THRESHOLD


logger = logging.getLogger("ChatbotAPI")

current_year = datetime.now().year

_GENERATE_PROMPT = ChatPromptTemplate.from_messages(
    [
        ("system", HORSE_SYSTEM_PROMPT),
        ("human", HORSE_HUMAN_TURN),
    ]
)

_GENERATE_RETRY_PROMPT = ChatPromptTemplate.from_messages(
    [
        ("system", HORSE_SYSTEM_PROMPT),
        ("human", HORSE_HUMAN_TURN_RETRY),
    ]
)

_DATE_HINT = (
    "The user is asking about {weekday}, {readable_date}. "
    "Only describe what is in the knowledge base for that specific date. "
    "If nothing is found, say so honestly and in character — do not invent activities."
)

def _format_chat_history(history: list, horse_name: str) -> str:
    tail = history[-12:] if len(history) > 12 else history
    if len(tail) % 2 != 0:
        tail = tail[1:]

    lines = []
    for i, msg in enumerate(tail):
        role = "User" if i % 2 == 0 else horse_name.capitalize()
        lines.append(f"{role}: {msg}")

    return "\n".join(lines) if lines else ""


def _get_activity(current_day: str, current_hour: int) -> str:
    if current_day == "Sunday":
        return activity_sunday
    if 5 <= current_hour < 8:
        return activity_5_8
    if 8 <= current_hour < 15:
        return activity_8_15
    if 15 <= current_hour < 18:
        return activity_15_18
    return activity_else


def _openai_error_answer(state, exc):
    user = state["user_name"]

    if isinstance(exc, openai.RateLimitError):
        code = (getattr(exc, "body", {}) or {}).get("code", "")
        if code == "insufficient_quota":
            return f"I'm sorry {user}, service limit hit — please contact support."
        return f"I'm a little overwhelmed right now, {user}! Give me a moment."

    if isinstance(exc, openai.APIConnectionError):
        return f"I'm having trouble connecting, {user}. Please try again."

    if isinstance(exc, openai.APIStatusError):
        logger.error(f"[OPENAI] {exc.status_code}: {exc.message}")
        return f"Something went wrong on my end, {user}. Please try again shortly."

    return None


## State

class HorseState(TypedDict):
    user_input: str
    horse_id: Any
    horse_name: str
    user_name: str
    user_age: str
    user_gender: str
    user_id: Any
    chat_history: list
    session_id: str
    llm: Any
    embeddings: Any
    activity: str
    weather_data: str
    personality: str
    character: str
    response_behavior: str
    qdrant_available: bool

    guardrail_bucket: str
    canned_response: str
    skip_retrieval: bool

    rewritten_query: str
    intent: str
    memory_types: List[str]
    force_daily: bool
    resolved_date: Optional[date]

    context: list
    answer: str

    quality_score: float
    quality_reason: str
    needs_retry: bool

    expanded_context: list
    
    
    
def _build_date_hint(resolved_date):
    if not resolved_date:
        return ""

    return _DATE_HINT.format(
        weekday=resolved_date.strftime("%A"),
        readable_date=resolved_date.strftime("%d %B %Y"),
    )


def _make_prompt_vars(state, docs_content, date_hint):
    return {
        "horse_name": state["horse_name"],
        "personality": state["personality"],
        "character": state["character"],
        "response_behavior": state["response_behavior"],
        "current_year": current_year,
        "question": state["user_input"],
        "context": docs_content,
        "user_name": state["user_name"],
        "user_age": state["user_age"],
        "user_gender": state["user_gender"],
        "activity": state["activity"],
        "chat_history1": _format_chat_history(
            state["chat_history"],
            state["horse_name"]
        ),
        "geeting": get_greeting(state["user_name"]),
        "weather_data": state["weather_data"],
        "resolved_date_hint": date_hint,
    }


def _run_generate(state, docs_content, date_hint, prompt):
    chain = prompt | state["llm"] | StrOutputParser()
    return chain.invoke(
        _make_prompt_vars(state, docs_content, date_hint)
    )
    
    
def _classify_weather_intent(user_input: str, llm) -> dict:
    """
    Use LLM to determine:
    - is_weather:   is this asking about weather at all?
    - is_future:    is it asking about future weather?
    - is_past_date: is it asking about a specific past date?
    Returns dict with those three booleans.
    """
    from langchain_core.output_parsers import JsonOutputParser
    from langchain_core.prompts import ChatPromptTemplate

    _prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                """\
You are a query classifier. Analyse the user message and return ONLY valid JSON, no markdown.

{{
  "is_weather":   true or false,
  "is_future":    true or false,
  "is_past_date": true or false
}}

RULES:
- "is_weather"   → true if the query asks about weather, temperature, climate, rain, snow, sun, wind, humidity, or any atmospheric/outdoor condition
- "is_future"    → true if asking about future weather (tomorrow, next week, next month, forecast, will it, going to be, etc.)
- "is_past_date" → true if asking about a specific past or relative past date (yesterday, last Monday, April 5th, 3 days ago, on Tuesday, last week, etc.)
- "is_future" and "is_past_date" are mutually exclusive — only one can be true
- If "is_weather" is false, both "is_future" and "is_past_date" must also be false
- If no date is mentioned and not future → both false (implies current/today)
- Return ONLY the JSON object, nothing else, no explanation
""",
            ),
            ("human", "{user_message}"),
        ]
    )

    _fallback = {"is_weather": False, "is_future": False, "is_past_date": False}

    try:
        chain = _prompt | llm | JsonOutputParser()
        result = chain.invoke({"user_message": user_input})
        classified = {
            "is_weather": bool(result.get("is_weather", False)),
            "is_future": bool(result.get("is_future", False)),
            "is_past_date": bool(result.get("is_past_date", False)),
        }
        logger.info(f"[WEATHER_CLASSIFY] result={classified} | msg='{user_input[:50]}'")
        return classified
    except Exception as exc:
        logger.warning(f"[WEATHER_CLASSIFY] Failed ({exc}), defaulting to non-weather")
        return _fallback


def _route_after_guardrail(state: HorseState) -> str:
    """Skip directly to end when guardrail has a canned answer."""
    if state.get("skip_retrieval"):
        logger.info(
            f"[ROUTE:guardrail] bucket={state['guardrail_bucket']} → skip to __end__"
        )
        return "__end__"
    return "intent_resolve"


def _route_after_evaluate(state: HorseState) -> str:
    if state.get("needs_retry"):
        logger.info(
            f"[ROUTE:evaluate] score {state.get('quality_score',0):.2f} "
            f"< {QUALITY_THRESHOLD} → expanding retrieval"
        )
        return "retrieve_expanded"
    return "__end__"
