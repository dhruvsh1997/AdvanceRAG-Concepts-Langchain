import os
import sys
import uuid
import logging
from pathlib import Path

PROJECT_ROOT    = "/var/www/html/aiml/ExceedEquine-TKCS-ML"
FAISS_ROOT      = f"{PROJECT_ROOT}/exceedproject/faiss_index"  # ← fix if needed
QDRANT_URL      = "http://localhost:6333"
COLLECTION      = "horses_memory"
EMBED_MODEL     = "text-embedding-ada-002"
VECTOR_SIZE     = 1536
BATCH_SIZE      = 64
KNOWN_HORSE_IDS = ["2", "3", "4", "5", "6", "7", "8"]

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("migration")


def setup_django():
    if PROJECT_ROOT not in sys.path:
        sys.path.insert(0, PROJECT_ROOT)
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "exceedproject.settings")
    try:
        import django
        django.setup()
        logger.info("Django ready.")
    except Exception as e:
        logger.warning(f"Django bootstrap skipped ({e})")


def get_qdrant_client():
    from qdrant_client import QdrantClient
    from qdrant_client.models import Distance, VectorParams, OptimizersConfigDiff

    client = QdrantClient(url=QDRANT_URL)
    existing = [c.name for c in client.get_collections().collections]

    if COLLECTION not in existing:
        client.create_collection(
            collection_name=COLLECTION,
            vectors_config=VectorParams(size=VECTOR_SIZE, distance=Distance.COSINE),
            optimizers_config=OptimizersConfigDiff(indexing_threshold=0),
        )
        logger.info(f"Created collection: {COLLECTION}")
    else:
        logger.info(f"Collection already exists: {COLLECTION}")

    return client


def load_faiss(horse_id, embeddings):
    from langchain_community.vectorstores import FAISS
    path = os.path.join(FAISS_ROOT, horse_id)
    if not os.path.isdir(path):
        logger.warning(f"  [SKIP] No FAISS folder: {path}")
        return None
    try:
        store = FAISS.load_local(path, embeddings, allow_dangerous_deserialization=True)
        logger.info(f"  Loaded horse '{horse_id}' — {len(store.docstore._dict)} docs")
        return store
    except Exception as e:
        logger.error(f"  Failed to load FAISS for horse '{horse_id}': {e}")
        return None


def extract_docs(store):
    docstore  = store.docstore._dict
    index_map = store.index_to_docstore_id
    faiss_idx = store.index
    results   = []
    for i in range(faiss_idx.ntotal):
        doc_id = index_map.get(i)
        if not doc_id:
            continue
        doc = docstore.get(doc_id)
        if not doc:
            continue
        vector = faiss_idx.reconstruct(i).tolist()
        results.append((doc, vector))
    return results


def infer_memory_type(meta):
    mt  = meta.get("memory_type", "")
    src = meta.get("source", "")
    KNOWN = ("facility", "equipment", "humans", "horses", "btr_show_summary", "daily_summary")
    if mt in KNOWN:
        return mt
    for tag in KNOWN:
        if tag in src:
            return tag
    if "memory_json_" in src:
        for tag in ("facility", "equipment", "humans", "horses"):
            if tag in src:
                return tag
    return "general"


def migrate_horse(horse_id, embeddings, client):
    logger.info(f"\n{'='*50}\n  Migrating horse_id = {horse_id}\n{'='*50}")
    store = load_faiss(horse_id, embeddings)
    if store is None:
        return 0

    docs_vecs = extract_docs(store)
    total     = len(docs_vecs)
    logger.info(f"  Extracted {total} document(s)")

    from qdrant_client.models import PointStruct
    batch, count = [], 0

    for doc, vec in docs_vecs:
        memory_type = infer_memory_type(doc.metadata)
        payload = {
            "horse_id":    str(horse_id),   # always string
            "memory_type": memory_type,
            "source":      doc.metadata.get("source", "unknown"),
            "text":        doc.page_content,
        }
        for k, v in doc.metadata.items():
            if k not in payload:
                payload[k] = v

        batch.append(PointStruct(id=str(uuid.uuid4()), vector=vec, payload=payload))

        if len(batch) >= BATCH_SIZE:
            client.upsert(collection_name=COLLECTION, points=batch)
            count += len(batch)
            logger.info(f"  → {count}/{total} upserted …")
            batch = []

    if batch:
        client.upsert(collection_name=COLLECTION, points=batch)
        count += len(batch)

    logger.info(f"  ✓ horse '{horse_id}' complete — {count} points written")
    return count


def print_summary(client):
    from qdrant_client.models import Filter, FieldCondition, MatchValue
    logger.info("\n" + "="*60)
    logger.info("MIGRATION SUMMARY")
    logger.info("="*60)
    total_all = client.count(collection_name=COLLECTION, exact=True).count
    logger.info(f"Total points in collection: {total_all}")
    for horse_id in KNOWN_HORSE_IDS:
        try:
            n = client.count(
                collection_name=COLLECTION,
                count_filter=Filter(must=[
                    FieldCondition(key="horse_id", match=MatchValue(value=str(horse_id)))
                ]),
                exact=True,
            ).count
            if n > 0:
                logger.info(f"  horse {horse_id:>4} : {n:>5} points")
        except Exception:
            pass
    logger.info("="*60)


def main():
    setup_django()

    if not os.environ.get("OPENAI_API_KEY"):
        logger.error("OPENAI_API_KEY not set. Run: export OPENAI_API_KEY=sk-...")
        sys.exit(1)

    from langchain_openai import OpenAIEmbeddings
    embeddings = OpenAIEmbeddings(model=EMBED_MODEL)
    client     = get_qdrant_client()

    faiss_root = Path(FAISS_ROOT)
    if not faiss_root.exists():
        logger.error(f"FAISS root not found: {FAISS_ROOT}")
        sys.exit(1)

    disk_ids  = sorted([d.name for d in faiss_root.iterdir() if d.is_dir()])
    horse_ids = sorted(set(disk_ids + KNOWN_HORSE_IDS))
    logger.info(f"Horse IDs to migrate: {horse_ids}")

    grand_total = 0
    for hid in horse_ids:
        grand_total += migrate_horse(hid, embeddings, client)

    from qdrant_client.models import OptimizersConfigDiff
    client.update_collection(
        collection_name=COLLECTION,
        optimizers_config=OptimizersConfigDiff(indexing_threshold=20_000),
    )
    logger.info(f"\n✓ Migration complete — {grand_total} total points.")
    print_summary(client)


if __name__ == "__main__":
    main()