from django.apps import AppConfig


class ExceedappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'exceedapp'
