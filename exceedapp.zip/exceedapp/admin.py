from django.contrib import admin
from .models import SessionChatbot, HorseFileMetadata, HorseFileMetadataRecord, UserChatHistorySession

@admin.register(UserChatHistorySession)
class UserChatHistorySessionAdmin(admin.ModelAdmin):
    list_display = ('session_id', 'history', 'user_id', 'timestamp', 'is_restriction')  # Columns to display in the admin list view
    search_fields = ('session_id','timestamp')                                          # Add a search bar for session_id
    list_filter = ('history',)                                                          # Add filtering options (if applicable)

@admin.register(SessionChatbot)
class SessionChatbotAdmin(admin.ModelAdmin):
    list_display = ('session_id', 'history')  # Columns to display in the admin list view
    search_fields = ('session_id',)          # Add a search bar for session_id
    list_filter = ('history',)               # Add filtering options (if applicable)

@admin.register(HorseFileMetadata)
class HorseFileMetadataAdmin(admin.ModelAdmin):
    list_display = ('horse_id', 'last_modified_file', 'last_modified_fixed_file')  # Columns to display
    search_fields = ('horse_id',)                                                  # Add a search bar for horse_id
    list_filter = ('last_modified_file',)                                          # Add filtering options
from django.contrib import admin

@admin.register(HorseFileMetadataRecord)
class HorseFileMetadataRecordAdmin(admin.ModelAdmin):
    list_display = [field.name for field in HorseFileMetadataRecord._meta.fields]
    search_fields = ('horse_id',)
    # list_filter = ('last_modified_file',)
