from rest_framework import serializers

class HorseDocumentUploadSerializer(serializers.Serializer):
    horse_id = serializers.CharField(required=True)
    custom_data = serializers.FileField(required=True)
    pedigree = serializers.FileField(required=True)
    racing_record = serializers.FileField(required=True)
    bloodline = serializers.FileField(required=True)

class UploadHarnessDocumentsSerializer(serializers.Serializer):
    harness_data = serializers.FileField(required=True)
    frehorse_data = serializers.FileField(required=True)
    barn_people = serializers.FileField(required=True)

class HorseChatSerializer(serializers.Serializer):
    horse_id = serializers.CharField(required=True)
    session_id = serializers.CharField(required=True)
    message = serializers.CharField(required=True)
    user_name = serializers.CharField(required=True)
    user_age = serializers.IntegerField(required=True)
    user_gender = serializers.CharField(required=True)
    user_id = serializers.CharField(required=True)
    horse_name = serializers.CharField(required=True)

class HorseVectorSerializer(serializers.Serializer):
    horse_id = serializers.CharField(required=True)
