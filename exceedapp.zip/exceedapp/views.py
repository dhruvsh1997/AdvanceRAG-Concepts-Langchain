from __future__ import annotations

import hashlib
import logging
import os
import shutil
from datetime import date, datetime, timedelta
from typing import Any, List, Optional

from datetime import datetime

from rest_framework import status
from rest_framework.parsers import JSONParser
from rest_framework.response import Response
from rest_framework.views import APIView

import boto3
import openai
import pytz
import requests
from botocore.exceptions import NoCredentialsError, PartialCredentialsError
from django.conf import settings
from django.utils.timezone import now
from docx import Document
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_core.documents import Document as documentation
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langgraph.graph import START, StateGraph
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.parsers import FormParser, MultiPartParser
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView
from typing_extensions import List, TypedDict
from .helpers import EmailAI_new

# ── Internal modules ──────────────────────────────────────────────────────────
from .graph_helpers import (_format_chat_history,_get_activity,_openai_error_answer,
                            HorseState,_build_date_hint,_make_prompt_vars,_run_generate,
                            _classify_weather_intent,_route_after_guardrail,_route_after_evaluate,
                            _GENERATE_PROMPT,_GENERATE_RETRY_PROMPT,_DATE_HINT)


from .graph_nodes import (GRAPH)
from .chat_integration import (QUALITY_THRESHOLD, RERANK_TOP_N, RETRIEVAL_K,
                               build_docs_content,
                               build_expanded_retrieval_chain,
                               build_memory_context, build_retrieval_chain,
                               check_qdrant_available, evaluate_answer_quality,
                               fetch_all_daily_chunks_for_date,
                               fetch_most_recent_daily_summary,
                               get_horse_daily_summary, resolve_query_dates,
                               rewrite_and_classify, run_guardrail)
from .message import (activity_5_8, activity_8_15, activity_15_18,
                      activity_else, activity_sunday, data_validation,
                      error_in_processing, file_processing, s3_connection,
                      s3_credentials, s3_files_unavailable, upload_sucessfully,
                      vector_file, vectors_updated, vercotrs_not_updates)
from .models import HorseFileMetadataRecord, UserChatHistorySession
from .prompt import (gpt4o_prompt, gpt4omini_prompt, gpt4omini_prompt_new,
                     personality_of_horse)
from .utils import EmailAI

import asyncio
import random
from datetime import datetime

import openai
from django.conf import settings
from django.core.mail import send_mail
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response


# from .memory_integration import (build_memory_context, extract_date_from_query,
#                                  get_horse_daily_summary,
#                                  index_general_knowledge, index_json_memories,
#                                  rerank_docs, retrieve_from_qdrant,
#                                  rewrite_and_classify)
from .serializers import (HorseChatSerializer, HorseDocumentUploadSerializer,
                          HorseVectorSerializer,
                          UploadHarnessDocumentsSerializer)
from .utils import (fetch_weather_data, get_greeting, get_random_response,
                    handle_file_processing, modify_paraphrase,
                    modify_paraphrase_for_day)

current_year = datetime.now().year


from dotenv import load_dotenv

load_dotenv()


logger = logging.getLogger("ChatbotAPI")


class UploadHorseDocuments(APIView):
    parser_classes = [MultiPartParser, FormParser]

    def post(self, request):
        """POST API for uploading horse files to DigitalOcean Spaces"""
        try:
            serializer = HorseDocumentUploadSerializer(data=request.data)
            if serializer.is_valid():
                horse_id = serializer.validated_data["horse_id"]
                custom_data_file = serializer.validated_data["custom_data"]
                pedigree_file = serializer.validated_data["pedigree"]
                racing_record_file = serializer.validated_data["racing_record"]
                bloodline_file = serializer.validated_data["bloodline"]
            else:
                return Response(
                    {
                        "IsSuccess": False,
                        "StatusCode": 400,
                        "message": "Data validation failed",
                        "errors": serializer.errors,
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )

            # Configure boto3 client for DigitalOcean Spaces
            spaces_client = boto3.client(
                "s3",
                region_name=os.environ.get("DO_REGION"),
                endpoint_url=os.environ.get("DO_ENDPOINT_URL"),
                aws_access_key_id=os.environ.get("DO_ACCESS_KEY"),
                aws_secret_access_key=os.environ.get("DO_SECRET_KEY"),
            )

            bucket_name = os.environ.get("DO_BUCKET_NAME")
            folder_path = f"horse_documents/{horse_id}/"
            file_paths = {
                "custom_data": f"{folder_path}horse_data.docx",
                "pedigree": f"{folder_path}pedigree.pdf",
                "racing_record": f"{folder_path}racing_record.pdf",
                "bloodline": f"{folder_path}bloodline.docx",
            }

            files_to_upload = {
                file_paths["custom_data"]: custom_data_file,
                file_paths["pedigree"]: pedigree_file,
                file_paths["racing_record"]: racing_record_file,
                file_paths["bloodline"]: bloodline_file,
            }

            for path, file_obj in files_to_upload.items():
                try:
                    content_type = (
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        if path.endswith(".docx")
                        else "application/pdf"
                    )

                    spaces_client.upload_fileobj(
                        file_obj,
                        bucket_name,
                        path,
                        ExtraArgs={"ContentType": content_type},
                    )
                except (NoCredentialsError, PartialCredentialsError):
                    return Response(
                        {"message": "Invalid DigitalOcean credentials"},
                        status=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    )
                except Exception as e:
                    return Response(
                        {"message": "Error occurred while uploading file"},
                        status=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    )

            return Response(
                {
                    "IsSuccess": True,
                    "StatusCode": 200,
                    "message": "Files uploaded successfully",
                    "uploaded_files": list(file_paths.values()),
                },
                status=status.HTTP_200_OK,
            )

        except Exception:
            return Response(
                {
                    "IsSuccess": False,
                    "StatusCode": 500,
                    "message": "Failed to connect to DigitalOcean Spaces",
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )


class UploadHarnessDocuments(APIView):
    parser_classes = [MultiPartParser, FormParser]

    def post(self, request):
        """POST API to upload harness and free horse documents to DigitalOcean Spaces"""
        try:
            serializer = UploadHarnessDocumentsSerializer(data=request.data)

            if serializer.is_valid():
                harness_data_file = serializer.validated_data.get("harness_data")
                frehorse_data_file = serializer.validated_data.get("frehorse_data")
                barn_people = serializer.validated_data.get("barn_people")
            else:
                return Response(
                    {
                        "IsSuccess": False,
                        "StatusCode": 400,
                        "message": "Data validation failed",
                        "errors": serializer.errors,
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )

            # DigitalOcean Spaces configuration
            spaces_client = boto3.client(
                "s3",
                region_name=os.environ.get("DO_REGION"),
                endpoint_url=os.environ.get("DO_ENDPOINT_URL"),
                aws_access_key_id=os.environ.get("DO_ACCESS_KEY"),
                aws_secret_access_key=os.environ.get("DO_SECRET_KEY"),
            )

            bucket_name = os.environ.get("DO_BUCKET_NAME")
            folder_path = "horse_documents/harness_freehorse_data/"
            file_paths = {
                "harness_data": f"{folder_path}harness_data.docx",
                "frehorse_data": f"{folder_path}frehorse_data.docx",
                "barn_people": f"{folder_path}barn_people.docx",
            }

            files_to_upload = {
                file_paths["harness_data"]: harness_data_file,
                file_paths["frehorse_data"]: frehorse_data_file,
                file_paths["barn_people"]: barn_people,
            }

            for path, file_obj in files_to_upload.items():
                try:
                    spaces_client.upload_fileobj(
                        file_obj,
                        bucket_name,
                        path,
                        ExtraArgs={
                            "ContentType": "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        },
                    )
                except (NoCredentialsError, PartialCredentialsError):
                    return Response(
                        {"message": "Invalid DigitalOcean credentials"},
                        status=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    )
                except Exception as e:
                    return Response(
                        {"message": f"Error occurred while uploading file: {str(e)}"},
                        status=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    )

            return Response(
                {
                    "IsSuccess": True,
                    "StatusCode": 200,
                    "message": "Files uploaded successfully",
                    "uploaded_files": list(file_paths.values()),
                },
                status=status.HTTP_200_OK,
            )

        except Exception as error:
            return Response(
                {
                    "IsSuccess": False,
                    "StatusCode": 500,
                    "message": "Failed to connect to DigitalOcean Spaces",
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )


os.environ["OPENAI_API_KEY"] = os.environ.get("OPEN_API_KEY")


class CombinedFileProcessingWithMetadataAPI_test(APIView):
    permission_classes = [AllowAny]

    def authenticate_magento_user(self, token):
        """Authenticate with Magento API using the provided bearer token."""
        url = "https://uat.freeracehorse.com/rest/V1/customers/search?searchCriteria"
        headers = {
            "Authorization": f"Bearer {token}",
        }
        try:
            response = requests.get(url, headers=headers, timeout=10)
            if response.status_code == 200:
                data = response.json()
                return True
            else:
                return False
        except requests.RequestException as e:
            return False

    def post(self, request):
        """Post API for RAG based chatbot for retrival and generation"""
        try:
            # magento_token = request.headers.get("Authorization", "").replace("Bearer ", "")
            # if not magento_token or not self.authenticate_magento_user(magento_token):
            #     return Response(
            #         {"Message": "Invalid Authorization Token","status":False, "StatusCode":401},
            #         status=status.HTTP_401_UNAUTHORIZED,
            #     )
            serializer = HorseChatSerializer(data=request.data)

            if serializer.is_valid():
                horse_id = serializer.validated_data.get("horse_id")
                session_id = serializer.validated_data.get("session_id")
                user_input = serializer.validated_data.get("message")
                user_name = serializer.validated_data.get("user_name")
                user_age = serializer.validated_data.get("user_age")
                user_gender = serializer.validated_data.get("user_gender")
                user_id = serializer.validated_data.get("user_id")
                horse_name = serializer.validated_data.get("horse_name").lower()
            else:
                return Response(
                    {
                        "IsSuccess": False,
                        "StatusCode": 400,
                        "message": data_validation,
                        "errors": serializer.errors,
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )

            day_ago = now() - timedelta(hours=24)

            try:
                session = (
                    UserChatHistorySession.objects.filter(
                        user_id=user_id, horse_id=horse_id, timestamp__gte=day_ago
                    )
                    .order_by("-timestamp")
                    .first()
                )
                if not session:
                    session = UserChatHistorySession.objects.create(
                        user_id=user_id, horse_id=horse_id, history=[]
                    )
                # if not session:
                #     raise UserChatHistorySession.DoesNotExist
                chat_history = session.history or []

                if session.is_restriction:
                    return Response(
                        {
                            "IsSuccess": True,
                            "StatusCode": 200,
                            "Response": modify_paraphrase_for_day(),
                            "Restrictfor24hour": True,
                            "session_id": session.session_id,
                        },
                        status=status.HTTP_200_OK,
                    )
            except UserChatHistorySession.DoesNotExist:
                session = UserChatHistorySession.objects.create(
                    user_id=user_id,
                    horse_id=horse_id,
                    session_id=session_id,
                    timestamp=now(),
                )

            try:
                llm = ChatOpenAI(model="gpt-4o-mini")
                embeddings = OpenAIEmbeddings(model="text-embedding-ada-002")
                faiss_index_path = os.path.join(
                    settings.MEDIA_ROOT, "faiss_index", horse_id
                )
                vector_store = FAISS.load_local(
                    faiss_index_path, embeddings, allow_dangerous_deserialization=True
                )
            except Exception as e:
                return Response(
                    {
                        "IsSuccess": False,
                        "StatusCode": 404,
                        "Response": vector_file,
                    },
                    status=status.HTTP_404_NOT_FOUND,
                )

            eastern = pytz.timezone("US/Eastern")
            current_time_eastern = datetime.now(eastern)
            current_hour = current_time_eastern.hour
            current_day = current_time_eastern.strftime("%A")

            if current_day == "Sunday":
                activity = activity_sunday
            elif 5 <= current_hour < 8:
                activity = activity_5_8
            elif 8 <= current_hour < 15:
                activity = activity_8_15
            elif 15 <= current_hour < 18:
                activity = activity_15_18
            else:
                activity = activity_else

            current_id = session.session_id
            session = UserChatHistorySession.objects.get(session_id=current_id)
            chat_history = session.history

            weather_data = fetch_weather_data()
            personality, character, response_behavior = personality_of_horse(horse_name)

            if len(chat_history) > 10:
                chat_history1 = chat_history[-10:]
            else:
                chat_history1 = chat_history

            prompt = ChatPromptTemplate.from_messages(
                [
                    ("system", gpt4omini_prompt),
                    (
                        "human",
                        """user_name: {user_name}
                               activity: {activity}
                               chat_history1: {chat_history1}
                               user_age : {user_age}
                               user_gender :{user_gender}
                               Question: {question}
                               geeting: {geeting}
                               weather_data: {weather_data}
                               horse_name: {horse_name}
                               personality: {personality}
                               character : {character}
                               response_behavior:{response_behavior}
                               current_year : {current_year}""",
                    ),
                ]
            )

            class State(TypedDict):
                question: str
                context: List[Document]
                answer: str

            def retrieve(state: State):
                retrieved_docs = vector_store.similarity_search(state["question"], k=10)
                return {"context": retrieved_docs}

            def generate(state: State):
                docs_content = "\n\n".join(doc.page_content for doc in state["context"])
                messages = prompt.invoke(
                    {
                        "question": state["question"],
                        "context": docs_content,
                        "user_name": user_name,
                        "user_age": user_age,
                        "user_gender": user_gender,
                        "activity": activity,
                        "chat_history1": chat_history1,
                        "geeting": get_greeting(user_name),
                        "weather_data": weather_data,
                        "horse_name": horse_name,
                        "personality": personality,
                        "character": character,
                        "response_behavior": response_behavior,
                        "current_year": current_year,
                    }
                )
                response = llm.invoke(messages)
                return {"answer": response.content}

            graph_builder = StateGraph(State).add_sequence([retrieve, generate])
            graph_builder.add_edge(START, "retrieve")
            graph = graph_builder.compile()
            response = graph.invoke({"question": user_input})
            chat_history.append(user_input)

            chat_history.append(response["answer"])
            session.save()

            return Response(
                {
                    "IsSuccess": True,
                    "StatusCode": 200,
                    "Response": response["answer"],
                    # "Response2": response["answer"],
                    "Restrictfor24hour": False,
                    "session_id": session.session_id,
                },
                status=status.HTTP_200_OK,
            )

        except Exception as error:
            return Response(
                {
                    "IsSuccess": False,
                    "StatusCode": 500,
                    "Response": f"Error: {str(error)}",
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

            ############################################3


RETRIEVAL_K = 15
RERANK_TOP_N = 8


def _format_chat_history(history: list, horse_name: str) -> str:
    """
    Convert flat alternating list → labelled turn pairs.
    ["user msg", "horse msg", ...] → "User: ...\nHorse: ..."

    Keeps the last 12 items (6 full turns) and always keeps an even count
    so User/Horse pairing is never broken.
    """
    tail = history[-12:] if len(history) > 12 else history
    if len(tail) % 2 != 0:
        tail = tail[1:]  # drop first item to restore even pairing

    lines = []
    for i, msg in enumerate(tail):
        role = "User" if i % 2 == 0 else horse_name.capitalize()
        lines.append(f"{role}: {msg}")
    return "\n".join(lines) if lines else ""


def _build_docs_content(context: list) -> str:
    """Group retrieved docs by memory type and format for the prompt."""
    from collections import defaultdict

    if not context:
        return "[NO DATA — no relevant memories found for this question]\n"

    grouped = defaultdict(list)
    for doc in context:
        grouped[doc.metadata.get("memory_type", "general")].append(doc.page_content)

    TYPE_ORDER = [
        "daily_summary",
        "general",
        "btr_show_summary",
        "equipment",
        "humans",
        "facility",
        "horses",
    ]
    TYPE_LABELS = {
        "daily_summary": "Recent Daily Activity",
        "general": "General Knowledge",
        "btr_show_summary": "Show & Competition Memory",
        "equipment": "Equipment & Therapy",
        "humans": "Staff & People",
        "facility": "Stable & Facility",
        "horses": "Horses in the Barn",
    }

    parts = ["KNOWLEDGE BASE:\n"]
    for mtype in TYPE_ORDER:
        chunks = grouped.get(mtype, [])
        if not chunks:
            continue
        parts.append(f"--- {TYPE_LABELS[mtype]} ---")
        parts.append("\n\n".join(chunks))
        parts.append("")
    return "\n".join(parts)


#####test
# class CombinedFileProcessingWithMetadataAPI(APIView):
#     permission_classes = [AllowAny]

#     def post(self, request):
#         try:
#             serializer = HorseChatSerializer(data=request.data)
#             if not serializer.is_valid():
#                 return Response(
#                     {
#                         "IsSuccess": False,
#                         "StatusCode": 400,
#                         "errors": serializer.errors,
#                     },
#                     status=status.HTTP_400_BAD_REQUEST,
#                 )

#             data = serializer.validated_data
#             horse_id = data["horse_id"]
#             user_input = data["message"]
#             user_name = data["user_name"]
#             user_age = data["user_age"]
#             user_gender = data["user_gender"]
#             user_id = data["user_id"]
#             horse_name = data["horse_name"].lower()

#             # -------------------------------
#             # SESSION HANDLING (24 HOURS)
#             # -------------------------------
#             day_ago = now() - timedelta(hours=24)

#             session = UserChatHistorySession.objects.filter(
#                 user_id=user_id,
#                 horse_id=horse_id,
#                 timestamp__gte=day_ago,
#             ).order_by("-timestamp").first()

#             if not session:
#                 session = UserChatHistorySession.objects.create(
#                     user_id=user_id,
#                     horse_id=horse_id,
#                     history=[]
#                 )

#             if session.is_restriction:
#                 return Response(
#                     {
#                         "IsSuccess": True,
#                         "StatusCode": 200,
#                         "Response": "You can chat again after 24 hours.",
#                         "Restrictfor24hour": True,
#                         "session_id": session.session_id,
#                     }
#                 )

#             chat_history = session.history or []

#             # -------------------------------
#             # VECTOR STORE
#             # -------------------------------
#             llm = ChatOpenAI(model="gpt-4o-mini")
#             embeddings = OpenAIEmbeddings(model="text-embedding-ada-002")

#             faiss_index_path = os.path.join(
#                 settings.MEDIA_ROOT, "faiss_index", horse_id
#             )

#             vector_store = FAISS.load_local(
#                 faiss_index_path,
#                 embeddings,
#                 allow_dangerous_deserialization=True
#             )

#             # -------------------------------
#             # TIME / ACTIVITY
#             # -------------------------------
#             eastern = pytz.timezone("US/Eastern")
#             now_est = datetime.now(eastern)
#             hour = now_est.hour
#             day = now_est.strftime("%A")

#             if day == "Sunday":
#                 activity = activity_sunday
#             elif 5 <= hour < 8:
#                 activity = activity_5_8
#             elif 8 <= hour < 15:
#                 activity = activity_8_15
#             elif 15 <= hour < 18:
#                 activity = activity_15_18
#             else:
#                 activity = activity_else

#             # -------------------------------
#             # MEMORY (LAST 10 MESSAGES)
#             # -------------------------------
#             recent_history = chat_history[-10:]

#             # -------------------------------
#             # PROMPT
#             # -------------------------------
#             prompt = ChatPromptTemplate.from_messages([
#                 ("system", gpt4omini_prompt),
#                 ("human", """
# user_name: {user_name}
# user_age: {user_age}
# user_gender: {user_gender}
# horse_name: {horse_name}
# activity: {activity}
# chat_history: {chat_history}
# weather: {weather}
# question: {question}
# """)
#             ])

#             class State(TypedDict):
#                 question: str
#                 context: List[Document]
#                 answer: str

#             def retrieve(state: State):
#                 docs = vector_store.similarity_search(state["question"], k=10)
#                 return {"context": docs}

#             def generate(state: State):
#                 context_text = "\n\n".join(d.page_content for d in state["context"])
#                 messages = prompt.invoke({
#                     "question": state["question"],
#                     "chat_history": recent_history,
#                     "user_name": user_name,
#                     "user_age": user_age,
#                     "user_gender": user_gender,
#                     "horse_name": horse_name,
#                     "activity": activity,
#                     "weather": fetch_weather_data(),
#                 })
#                 response = llm.invoke(messages)
#                 return {"answer": response.content}

#             graph = StateGraph(State)
#             graph.add_sequence([retrieve, generate])
#             graph.add_edge(START, "retrieve")
#             app = graph.compile()

#             result = app.invoke({"question": user_input})
#             answer = result["answer"]

#             # -------------------------------
#             # SAVE HISTORY (CRITICAL FIX)
#             # -------------------------------
#             chat_history.append({
#                 "role": "user",
#                 "content": user_input,
#                 "timestamp": now().isoformat()
#             })
#             chat_history.append({
#                 "role": "assistant",
#                 "content": answer,
#                 "timestamp": now().isoformat()
#             })

#             session.history = chat_history
#             session.save(update_fields=["history"])

#             return Response(
#                 {
#                     "IsSuccess": True,
#                     "StatusCode": 200,
#                     "Response": answer,
#                     "Restrictfor24hour": False,
#                     "session_id": session.session_id,
#                 }
#             )

#         except Exception as e:
#             return Response(
#                 {
#                     "IsSuccess": False,
#                     "StatusCode": 500,
#                     "Response": str(e),
#                 },
#                 status=status.HTTP_500_INTERNAL_SERVER_ERROR,
#             )


class UpdateVectorStore(APIView):
    def post(self, request):
        """POST API for update vectors when the filed are updated in the S3 bucket from admin"""
        try:
            serializer = HorseVectorSerializer(data=request.data)
            if serializer.is_valid():
                horse_id = serializer.validated_data.get("horse_id")
            else:
                return Response(
                    {
                        "IsSuccess": False,
                        "StatusCode": 400,
                        "message": data_validation,
                        "errors": serializer.errors,
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )
            metadata_obj, created = HorseFileMetadataRecord.objects.get_or_create(
                horse_id=horse_id
            )
            s3_client = boto3.client(
                "s3",
                region_name=os.environ.get("DO_REGION"),
                endpoint_url=os.environ.get("DO_ENDPOINT_URL"),
                aws_access_key_id=os.environ.get("DO_ACCESS_KEY"),
                aws_secret_access_key=os.environ.get("DO_SECRET_KEY"),
            )
            s3_bucket_name = os.environ.get("DO_BUCKET_NAME")

            file_key_to_field_mapping = {
                f"horse_documents/{horse_id}/horse_data.docx": "horse_data_last_modified",
                f"horse_documents/{horse_id}/pedigree.pdf": "prdigree_last_modified",
                f"horse_documents/{horse_id}/racing_record.pdf": "racing_record_last_modified",
                f"horse_documents/{horse_id}/bloodline.docx": "bloodline_record_last_modified",
                f"horse_documents/harness_freehorse_data/harness_data.docx": "harness_data_last_modified",
                f"horse_documents/harness_freehorse_data/frehorse_data.docx": "frehorse_data_last_modified",
                f"horse_documents/harness_freehorse_data/barn_people.docx": "barn_people_last_modified",
            }

            last_modified_changed = False

            for file_key, field_name in file_key_to_field_mapping.items():
                try:
                    try:
                        metadata = s3_client.head_object(
                            Bucket=s3_bucket_name, Key=file_key
                        )
                    except Exception as e:
                        return Response(
                            {
                                "IsSuccess": False,
                                "StatusCode": 404,
                                "Response": s3_files_unavailable,
                            },
                            status=status.HTTP_404_NOT_FOUND,
                        )
                    last_modified = metadata["LastModified"]
                    last_modified_str = last_modified.astimezone(pytz.utc).strftime(
                        "%Y-%m-%d %H:%M %Z"
                    )
                    if (
                        field_name == "bloodline_record_last_modified"
                        or field_name == "barn_people_last_modified"
                    ):
                        continue

                    if getattr(metadata_obj, field_name, "") != last_modified_str:
                        last_modified_changed = True
                        setattr(metadata_obj, field_name, last_modified_str)
                except s3_client.exceptions.NoSuchKey:
                    setattr(metadata_obj, field_name, "File not found")
                    continue

            if last_modified_changed:
                combined_text = handle_file_processing(
                    s3_client,
                    s3_bucket_name,
                    list(file_key_to_field_mapping.keys()),
                    horse_id,
                )

                embeddings = OpenAIEmbeddings(model="text-embedding-ada-002")
                index_general_knowledge(
                    text=combined_text.strip(),
                    horse_id=horse_id,
                    embeddings=embeddings,
                )

                # text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=300)
                # docs = [
                #     documentation(
                #         page_content=combined_text.strip(),
                #         metadata={"source": horse_id}
                #     )
                # ]
                # all_splits = text_splitter.split_documents(docs)

                # vector_store = FAISS.from_documents(documents=all_splits, embedding=embeddings)

                # faiss_index_path = os.path.join(settings.MEDIA_ROOT, "faiss_index", horse_id)
                # if os.path.exists(faiss_index_path):
                #     shutil.rmtree(faiss_index_path)
                # os.makedirs(faiss_index_path, exist_ok=True)
                # vector_store.save_local(faiss_index_path)
                metadata_obj.save()
                return Response(
                    {
                        "IsSuccess": True,
                        "StatusCode": 200,
                        "Message": vectors_updated,
                    },
                    status=status.HTTP_200_OK,
                )
            else:
                return Response(
                    {
                        "IsSuccess": True,
                        "StatusCode": 200,
                        "Message": vercotrs_not_updates,
                    },
                    status=status.HTTP_200_OK,
                )

        except Exception as e:
            return Response(
                {
                    "IsSuccess": False,
                    "StatusCode": 500,
                    "Message": file_processing,
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )


### EmailAI

class EmailDayOne(APIView):
    parser_classes = [JSONParser]  

    def post(self, request, format=None):
        data = request.data

        # Validate required fields
        user_profile = data.get("user_profile", {})
        first_name = user_profile.get(
            "first_name", "there"
        )  # Fallback in case it's missing

        # Compose email
        subject = f"Hey {first_name}… it’s me, Echo Sky 🐴"
        body = (
            f"Hey {first_name},\n\n"
            "I noticed you picked me — that means more than you know. "
            "I’ve been through a lot before I got here, but something about you feels calm… familiar.\n\n"
            "I’ll be waiting by the paddock when you log in again. "
            "Maybe we can explore the livestream or just chat for a bit. I’d like that.\n\n"
            "– Echo Sky\n"
            "(Your new horse, your new story)"
        )

        return Response({"subject": subject, "body": body}, status=status.HTTP_200_OK)




@api_view(["POST"])
def generate_email(request):
    try:
        payload = request.data
        day_trigger = payload.get("day_trigger")

        allowed_days = [1, 3, 7, 14, 21, 28, 35, 42, 49, 56]

        # ---------------------------
        # CASE 1: Single integer
        # ---------------------------
        if isinstance(day_trigger, int):
            if day_trigger not in allowed_days:
                return Response(
                    {
                        "success": False,
                        "error": "Invalid day_trigger. Allowed values are 1, 3, 7, 14, 21, 28, 35, 42, 49 or 56.",
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )

            try:
                ai_response = asyncio.run(EmailAI_new(day_trigger))
            except RuntimeError:
                loop = asyncio.get_event_loop()
                ai_response = loop.run_until_complete(EmailAI_new(day_trigger))

            return Response(
                {
                    "success": True,
                    "message": "Email Sent Successfully!",
                    "data": [item["email"] for item in ai_response],
                },
                status=status.HTTP_200_OK,
            )

        # ---------------------------
        # CASE 2: List of days
        # ---------------------------
        elif isinstance(day_trigger, list):
            invalid = [d for d in day_trigger if d not in allowed_days]
            if invalid:
                return Response(
                    {"success": False, "error": f"Invalid values in list: {invalid}"},
                    status=status.HTTP_400_BAD_REQUEST,
                )

            final_output = {}

            for day in day_trigger:
                try:
                    ai_response = asyncio.run(EmailAI_new(day))
                except RuntimeError:
                    loop = asyncio.get_event_loop()
                    ai_response = loop.run_until_complete(EmailAI_new(day))

                emails = [item["email"] for item in ai_response]
                final_output[f"day {day} send email"] = emails

            return Response(
                {
                    "success": True,
                    "message": "Email Sent Successfully!",
                    "data": final_output,
                },
                status=status.HTTP_200_OK,
            )

        else:
            return Response(
                {
                    "success": False,
                    "error": "'day_trigger' must be an integer or list.",
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

    except Exception as e:
        return Response(
            {"success": False, "error": str(e)},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR,
        )



# ---------------------------------------------------
# GLOBAL SINGLETONS (DO NOT RECREATE PER REQUEST)
# ---------------------------------------------------
LLM = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0.7,
)

EMBEDDINGS = OpenAIEmbeddings(
    model="text-embedding-ada-002"
)
class CombinedFileProcessingWithMetadataAPI_agent(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        """Horse personality RAG chatbot"""

        try:
            serializer = HorseChatSerializer(data=request.data)

            if not serializer.is_valid():
                return Response(
                    {
                        "IsSuccess": False,
                        "StatusCode": 400,
                        "message": data_validation,
                        "errors": serializer.errors,
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )

            data = serializer.validated_data

            horse_id = data.get("horse_id")
            session_id = data.get("session_id")
            user_input = data.get("message")
            user_name = data.get("user_name")
            user_age = data.get("user_age")
            user_gender = data.get("user_gender")
            user_id = data.get("user_id")
            horse_name = data.get("horse_name", "").lower()

            # ---------------------------------------------------
            # 2. Session Management
            # ---------------------------------------------------
            day_ago = now() - timedelta(hours=24)

            session = (
                UserChatHistorySession.objects.filter(
                    user_id=user_id,
                    horse_id=horse_id,
                    timestamp__gte=day_ago
                )
                .order_by("-timestamp")
                .first()
            )

            if not session:
                session = UserChatHistorySession.objects.create(
                    user_id=user_id,
                    horse_id=horse_id,
                    history=[]
                )
            # chat_history = session.history or []
            
            if session.is_restriction:
                return Response(
                    {
                        "IsSuccess": True,
                        "StatusCode": 200,
                        "Response": modify_paraphrase_for_day(),
                        "Restrictfor24hour": True,
                        "session_id": session.session_id,
                    },
                    status=status.HTTP_200_OK,
                )

            chat_history = session.history or []

            logger.info(f"[USER INPUT] {user_input}")

            try:
                build_memory_context(
                    user_input=user_input,
                    daily_fetcher=lambda: get_horse_daily_summary(horse_id),
                    embeddings=EMBEDDINGS,
                    horse_id=horse_id,
                )
            except Exception as exc:
                logger.exception(f"[MEMORY BUILD ERROR] {exc}")


            qdrant_available = check_qdrant_available(horse_id)

            eastern = pytz.timezone("US/Eastern")
            current_time = datetime.now(eastern)

            activity = _get_activity(
                current_time.strftime("%A"),
                current_time.hour,
            )

            weather_data = fetch_weather_data()

            logger.info(f"[WEATHER] {weather_data}")

            personality, character, response_behavior = (
                personality_of_horse(horse_name)
            )

            initial_state: HorseState = {
                "user_input": user_input,
                "horse_id": horse_id,
                "horse_name": horse_name,
                "user_name": user_name,
                "user_age": user_age,
                "user_gender": user_gender,
                "user_id": user_id,
                "chat_history": chat_history,
                "session_id": session.session_id,

                # Global singletons
                "llm": LLM,
                "embeddings": EMBEDDINGS,

                "activity": activity,
                "weather_data": weather_data,
                "personality": personality,
                "character": character,
                "response_behavior": response_behavior,
                "qdrant_available": qdrant_available,

                # Guardrail
                "guardrail_bucket": "",
                "canned_response": "",
                "skip_retrieval": False,

                # Intent
                "rewritten_query": "",
                "intent": "conversation",
                "memory_types": [],
                "force_daily": False,
                "resolved_date": None,

                # Retrieval / generation
                "context": [],
                "answer": "",

                # Evaluation
                "quality_score": 1.0,
                "quality_reason": "",
                "needs_retry": False,
                "expanded_context": [],
            }

            if not qdrant_available:
                answer = (
                    f"Hey {user_name}! No stored memories for "
                    f"{horse_name} yet. Once the knowledge base "
                    f"is set up I'll have plenty to share!"
                )
            else:
                try:
                    result = GRAPH.invoke(initial_state)

                    answer = result.get("answer") or (
                        f"Something went sideways in my brain, "
                        f"{user_name} — give me a sec!"
                    )

                    logger.info(
                        f"[GRAPH DONE] "
                        f"bucket={result.get('guardrail_bucket')} | "
                        f"skip={result.get('skip_retrieval')} | "
                        f"quality={result.get('quality_score', 'N/A')} | "
                        f"retry={result.get('needs_retry')} | "
                        f"horse={horse_name}({horse_id})"
                    )

                except Exception as exc:
                    logger.exception(f"[GRAPH ERROR] {exc}")

                    answer = (
                        f"Something went sideways in my brain, "
                        f"{user_name} — give me a sec!"
                    )

            current_pair = [user_input, answer]

            if chat_history[-2:] != current_pair:
                chat_history.extend(current_pair)

                session.history = chat_history
                session.save(update_fields=["history"])

            else:
                logger.info(
                    "[HISTORY] Duplicate turn — skipping save"
                )

            logger.info(
                f"[RESPONSE] "
                f"horse={horse_name}({horse_id}) | "
                f"user={user_id} | "
                f"answer_len={len(answer)}"
            )

            return Response(
                {
                    "IsSuccess": True,
                    "StatusCode": 200,
                    "Response": answer,
                    "Restrictfor24hour": False,
                    "session_id": session.session_id,
                },
                status=status.HTTP_200_OK,
            )

        except Exception as error:
            logger.exception(f"[VIEW ERROR] {error}")

            return Response(
                {
                    "IsSuccess": False,
                    "StatusCode": 500,
                    "Response": "Internal server error.",
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )
            
# class CombinedFileProcessingWithMetadataAPI_agent(APIView):
#     permission_classes = [AllowAny]

#     def post(self, request):
#         """Horse personality RAG chatbot — LangGraph + LangChain 1.x with guardrail + quality retry."""
#         try:

#             serializer = HorseChatSerializer(data=request.data)
#             if not serializer.is_valid():
#                 return Response(
#                     {
#                         "IsSuccess": False,
#                         "StatusCode": 400,
#                         "message": data_validation,
#                         "errors": serializer.errors,
#                     },
#                     status=status.HTTP_400_BAD_REQUEST,
#                 )

#             d = serializer.validated_data
#             horse_id = d.get("horse_id")
#             session_id = d.get("session_id")
#             user_input = d.get("message")
#             user_name = d.get("user_name")
#             user_age = d.get("user_age")
#             user_gender = d.get("user_gender")
#             user_id = d.get("user_id")
#             horse_name = d.get("horse_name").lower()

#             # ── 2. Session management ───────────────────────────────────────
#             day_ago = now() - timedelta(hours=24)
#             try:
#                 session = (
#                     UserChatHistorySession.objects.filter(
#                         user_id=user_id, horse_id=horse_id, timestamp__gte=day_ago
#                     )
#                     .order_by("-timestamp")
#                     .first()
#                 )
#                 if not session:
#                     session = UserChatHistorySession.objects.create(
#                         user_id=user_id, horse_id=horse_id, history=[]
#                     )
#                 chat_history = session.history or []

#                 if session.is_restriction:
#                     return Response(
#                         {
#                             "IsSuccess": True,
#                             "StatusCode": 200,
#                             "Response": modify_paraphrase_for_day(),
#                             "Restrictfor24hour": True,
#                             "session_id": session.session_id,
#                         },
#                         status=status.HTTP_200_OK,
#                     )
#             except UserChatHistorySession.DoesNotExist:
#                 session = UserChatHistorySession.objects.create(
#                     user_id=user_id,
#                     horse_id=horse_id,
#                     session_id=session_id,
#                     timestamp=now(),
#                 )
#                 chat_history = []

#             # ── 3. LLM + embeddings ─────────────────────────────────────────
#             try:
#                 llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.7)
#                 embeddings = OpenAIEmbeddings(model="text-embedding-ada-002")
#             except Exception as exc:
#                 logger.error(f"[LLM INIT] Failed: {exc}")
#                 return Response(
#                     {
#                         "IsSuccess": False,
#                         "StatusCode": 503,
#                         "Response": "AI service temporarily unavailable.",
#                     },
#                     status=status.HTTP_503_SERVICE_UNAVAILABLE,
#                 )

#             # ── 4. Background DB → Qdrant sync ──────────────────────────────
#             build_memory_context(
#                 user_input=user_input,
#                 daily_fetcher=lambda: get_horse_daily_summary(horse_id),
#                 embeddings=embeddings,
#                 horse_id=horse_id,
#             )
#             logger.info(f"User Input: {user_input}")
#             # ── 5. Qdrant availability ──────────────────────────────────────
#             qdrant_available = check_qdrant_available(horse_id)

#             # ── 6. Activity / time context ──────────────────────────────────
#             eastern = pytz.timezone("US/Eastern")
#             current_time = datetime.now(eastern)
#             activity = _get_activity(current_time.strftime("%A"), current_time.hour)

#             # ── 7. Re-read session after async sync ─────────────────────────
#             session = UserChatHistorySession.objects.get(session_id=session.session_id)
#             chat_history = session.history or []

#             weather_data = fetch_weather_data()
#             logger.info(f"Weather Data: {weather_data}")
#             personality, character, response_behavior = personality_of_horse(horse_name)

#             # ── 8. Build initial graph state ────────────────────────────────
#             initial_state: HorseState = {
#                 "user_input": user_input,
#                 "horse_id": horse_id,
#                 "horse_name": horse_name,
#                 "user_name": user_name,
#                 "user_age": user_age,
#                 "user_gender": user_gender,
#                 "user_id": user_id,
#                 "chat_history": chat_history,
#                 "session_id": session.session_id,
#                 "llm": llm,
#                 "embeddings": embeddings,
#                 "activity": activity,
#                 "weather_data": weather_data,
#                 "personality": personality,
#                 "character": character,
#                 "response_behavior": response_behavior,
#                 "qdrant_available": qdrant_available,
#                 # Guardrail
#                 "guardrail_bucket": "",
#                 "canned_response": "",
#                 "skip_retrieval": False,
#                 # Intent
#                 "rewritten_query": "",
#                 "intent": "conversation",
#                 "memory_types": [],
#                 "force_daily": False,
#                 "resolved_date": None,
#                 # Retrieval / generation
#                 "context": [],
#                 "answer": "",
#                 # Evaluation
#                 "quality_score": 1.0,
#                 "quality_reason": "",
#                 "needs_retry": False,
#                 "expanded_context": [],
#             }

#             # ── 9. Run LangGraph ────────────────────────────────────────────
#             if not qdrant_available:
#                 answer = (
#                     f"Hey {user_name}! No stored memories for {horse_name} yet. "
#                     "Once the knowledge base is set up I'll have plenty to share!"
#                 )
#             else:
#                 try:
#                     result = GRAPH.invoke(initial_state)
#                     answer = result.get("answer") or (
#                         f"Something went sideways in my brain, {user_name} — give me a sec!"
#                     )
#                     logger.info(
#                         f"[GRAPH DONE] bucket={result.get('guardrail_bucket')} | "
#                         f"skip={result.get('skip_retrieval')} | "
#                         f"quality={result.get('quality_score','N/A')} | "
#                         f"retry={result.get('needs_retry')} | "
#                         f"horse={horse_name}({horse_id})"
#                     )
#                 except Exception as exc:
#                     logger.error(f"[GRAPH] Unexpected error: {exc}")
#                     answer = f"Something went sideways in my brain, {user_name} — give me a sec!"

#             # ── 10. Persist history ─────────────────────────────────────────
#             last_pair = chat_history[-2:] if len(chat_history) >= 2 else []
#             if last_pair != [user_input, answer]:
#                 chat_history.extend([user_input, answer])
#                 session.history = chat_history
#                 session.save()
#             else:
#                 logger.info("[HISTORY] Duplicate turn — skipping save")

#             logger.info(
#                 f"[RESPONSE] horse={horse_name}({horse_id}) | user={user_id} | "
#                 f"answer_len={len(answer)} | ----- generated response ({answer})"
#             )

#             return Response(
#                 {
#                     "IsSuccess": True,
#                     "StatusCode": 200,
#                     "Response": answer,
#                     "Restrictfor24hour": False,
#                     "session_id": session.session_id,
#                 },
#                 status=status.HTTP_200_OK,
#             )

#         except Exception as error:
#             logger.exception(f"[VIEW] Unhandled error: {error}")
#             return Response(
#                 {
#                     "IsSuccess": False,
#                     "StatusCode": 500,
#                     "Response": f"Error: {str(error)}",
#                 },
#                 status=status.HTTP_500_INTERNAL_SERVER_ERROR,
#             )
