
from __future__ import annotations
import json
import os
import uuid
import math
import logging
import hashlib
import threading
from datetime import date, datetime, timedelta, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Optional

import dateparser
import mysql.connector

from .qdrant_conn import _get_client

logger = logging.getLogger("ChatbotAPI")

# ─────────────────────────────────────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────────────────────────────────────

COLLECTION    = "horses_memory"
VECTOR_SIZE   = 1536
EMBED_MODEL   = "text-embedding-ada-002"
CHUNK_SIZE    = 800
CHUNK_OVERLAP = 100
RETRIEVAL_K   = 15
RERANK_TOP_N  = 8

_MEMORY_JSON_FILES = {
    "facility":  "Memories_Data/facility_memory_data.json",
    "equipment": "Memories_Data/equipment_details.json",
    "humans":    "Memories_Data/human_recognition_details.json",
    "horses":    "Memories_Data/horse_traits_memory.json",
}

CANDIDATE_MEMORY_TYPES = [
    "general",
    "facility",
    "equipment",
    "humans",
    "horses",
    "btr_show_summary",
    "daily_summary",
]

# Minimal fallback – avoids flooding retrieval with irrelevant types
DEFAULT_FALLBACK_TYPES = ["general", "daily_summary"]

INTENT_TO_TYPES = {
    "daily_activity":   ["daily_summary"],
    "show_competition": ["btr_show_summary"],
    "facility":         ["facility"],
    "equipment":        ["equipment"],
    "staff_people":     ["humans"],
    "other_horses":     ["horses"],
    "general_horse":    ["general"],
    "conversation":     ["general", "daily_summary"],
    "mixed":            CANDIDATE_MEMORY_TYPES,
}

# ─────────────────────────────────────────────────────────────────────────────
# Date extraction
# ─────────────────────────────────────────────────────────────────────────────

def extract_date_from_query(query: str) -> Optional[dict]:
    """
    Returns:
        {"type": "exact",  "date": date_object}   – specific day requested
        {"type": "recent"}                          – "lately / this week / recent"
        None                                        – no temporal signal
    """
    import re
    q = query.lower().strip()

    parsed = dateparser.parse(
        q,
        settings={"PREFER_DATES_FROM": "past", "RELATIVE_BASE": datetime.now()},
    )
    if parsed:
        return {"type": "exact", "date": parsed.date()}

    match = re.search(r"(\d+)\s+days?\s+ago", q)
    if match:
        days = int(match.group(1))
        return {"type": "exact", "date": datetime.now().date() - timedelta(days=days)}

    if any(k in q for k in ["recent", "lately", "this week", "last week"]):
        return {"type": "recent"}

    return None


# ─────────────────────────────────────────────────────────────────────────────
# Combined rewrite + intent  (single LLM call)
# ─────────────────────────────────────────────────────────────────────────────

_REWRITE_AND_INTENT_PROMPT = """
You are a query processor for a horse AI memory retrieval system.

Given the user query, return ONLY a valid JSON object with exactly these keys:
{
  "rewritten_query": "<improved query optimised for semantic vector search>",
  "intent": "<intent_value>",
  "memory_types": ["type1", "type2"]
}

──────────────────────────────────────────
REWRITE RULES
- Keep the original meaning exactly
- Make implicit context explicit (e.g. "what did you eat" → "what food did the horse eat recently")
- Use domain vocabulary (stable, paddock, therapy, gallop, farrier, etc.)
- Output a single query string — no question marks needed
- Never answer the question; only rewrite it

──────────────────────────────────────────
INTENT VALUES & MEMORY TYPES

"daily_activity"   → ["daily_summary"]
"show_competition" → ["btr_show_summary"]
"facility"         → ["facility"]
"equipment"        → ["equipment"]
"staff_people"     → ["humans"]
"other_horses"     → ["horses"]
"general_horse"    → ["general"]
"conversation"     → ["general", "daily_summary"]
"mixed"            → list all relevant types

──────────────────────────────────────────
CLASSIFICATION RULES (priority order)

1. TEMPORAL — highest priority
   If query contains: last, recent, today, yesterday, lately, this week,
   what did you do, what happened, any updates → ALWAYS include "daily_summary"
   If combined with another domain → intent="mixed", include both types

2. DOMAIN-SPECIFIC
   Equipment / tools → ["equipment"]
   Facility / barn / paddock → ["facility"]
   Staff / trainer / vet → ["humans"]
   Other horses / barn mates → ["horses"]
   Shows / events / competitions / videos → ["btr_show_summary"]

3. CONVERSATIONAL / VAGUE
   Hi, hello, how are you, what are you doing, tell me something
   → intent="conversation", memory_types=["general","daily_summary"]

4. FOOD / ROUTINE / PERSONAL HABITS
   What did you eat, your routine, your day
   → intent="daily_activity", memory_types=["daily_summary"]
   NEVER classify food/routine as "other_horses"

5. MULTI-DOMAIN
   → intent="mixed", include ALL relevant types

6. FALLBACK (if truly unsure)
   → intent="conversation", memory_types=["general","daily_summary"]

──────────────────────────────────────────
STRICT OUTPUT RULES
- Output ONLY the JSON object
- No explanation, no markdown, no extra text

──────────────────────────────────────────
EXAMPLES

Input: "hi"
Output: {"rewritten_query":"greeting from user","intent":"conversation","memory_types":["general","daily_summary"]}

Input: "what did you do today"
Output: {"rewritten_query":"horse daily activity and routine today","intent":"daily_activity","memory_types":["daily_summary"]}

Input: "what equipment did you use last"
Output: {"rewritten_query":"therapy and training equipment horse used recently","intent":"mixed","memory_types":["daily_summary","equipment"]}

Input: "tell me about your barn and the staff"
Output: {"rewritten_query":"horse stable barn facility layout and staff members","intent":"mixed","memory_types":["facility","humans"]}

Input: "how did you do in the last show"
Output: {"rewritten_query":"horse show competition performance results recent","intent":"show_competition","memory_types":["btr_show_summary"]}

Input: "who are your friends in the barn"
Output: {"rewritten_query":"horse stable mates companions other horses in barn","intent":"other_horses","memory_types":["horses"]}
""".strip()


def rewrite_and_classify(query: str, llm) -> dict:
    """
    Single LLM call that returns:
        {
            "rewritten_query": str,
            "intent":          str,
            "memory_types":    [str, ...]
        }
    Falls back gracefully on any error.
    """
    from langchain_core.messages import SystemMessage, HumanMessage

    fallback = {
        "rewritten_query": query,
        "intent": "conversation",
        "memory_types": DEFAULT_FALLBACK_TYPES,
    }
    try:
        resp = llm.invoke([
            SystemMessage(content=_REWRITE_AND_INTENT_PROMPT),
            HumanMessage(content=query),
        ])

        raw = resp.content.strip().replace("```json", "").replace("```", "").strip()
        result = json.loads(raw)

        rewritten = result.get("rewritten_query", "").strip()
        if not isinstance(rewritten, str) or len(rewritten) < 3:
            rewritten = query
        result["rewritten_query"] = rewritten

        valid_types = [t for t in result.get("memory_types", []) if t in CANDIDATE_MEMORY_TYPES]
        result["memory_types"] = valid_types if valid_types else DEFAULT_FALLBACK_TYPES

        if result.get("intent") not in INTENT_TO_TYPES:
            result["intent"] = "conversation"

        logger.info(
            f"[REWRITE+INTENT] original='{query[:50]}' "
            f"→ rewritten='{rewritten[:50]}' "
            f"| intent={result['intent']} | types={result['memory_types']}"
        )
        return result

    except Exception as e:
        logger.warning(f"[REWRITE+INTENT] Failed ({e}), using fallback")
        return fallback


# ─────────────────────────────────────────────────────────────────────────────
# Reranker  (with type+date prefix so signal survives truncation)
# ─────────────────────────────────────────────────────────────────────────────

_RERANK_SYSTEM_PROMPT = """
You are a relevance reranker for a horse-AI memory retrieval system.

Each chunk is prefixed with [memory_type | date] so you know its category and recency.

Given a user question and numbered chunks, return a JSON array of chunk indices
sorted from MOST relevant to LEAST relevant.

Rules:
- Prefer chunks that directly answer the question
- Prefer recent daily_summary chunks for time-based questions ("today","recently","last week")
- Prefer show_summary chunks for competition / performance questions
- Rank [NO DATA] or clearly off-topic chunks last
- Output ONLY the JSON array of integers. Nothing else. Example: [2, 0, 4, 1, 3]
""".strip()


def rerank_docs(query: str, docs: list, llm_client, top_n: int = RERANK_TOP_N) -> list:
    """
    Rerank retrieved Document objects.
    Sends a [memory_type|date] prefix + 300-char body per chunk so the
    reranker always sees type and date even when content is long.
    Falls back to original order on any error.
    """
    from langchain_core.messages import SystemMessage, HumanMessage
    if len(docs) <= 1:
        return docs[:top_n]

    def _chunk_snippet(doc, idx: int) -> str:
        mtype = doc.metadata.get("memory_type", "general")
        adate = doc.metadata.get("activity_date", "") or ""
        prefix = f"[{mtype}|{adate}]" if adate else f"[{mtype}]"
        body = doc.page_content[:300].replace("\n", " ")
        return f"[{idx}] {prefix} {body}"

    chunks_text = "\n\n".join(_chunk_snippet(doc, i) for i, doc in enumerate(docs))
    prompt = f"Question: {query}\n\nChunks:\n{chunks_text}"

    try:
        resp = llm_client.invoke([
            SystemMessage(content=_RERANK_SYSTEM_PROMPT),
            HumanMessage(content=prompt),
        ])
        raw = resp.content.strip().replace("```json", "").replace("```", "").strip()
        ranking = json.loads(raw)

        valid_ranking = [i for i in ranking if isinstance(i, int) and 0 <= i < len(docs)]
        seen = set(valid_ranking)
        for i in range(len(docs)):
            if i not in seen:
                valid_ranking.append(i)

        reranked = [docs[i] for i in valid_ranking[:top_n]]
        logger.info(f"[RERANK] {len(docs)} → top {len(reranked)} | order={valid_ranking[:top_n]}")
        return reranked

    except Exception as e:
        logger.warning(f"[RERANK] Failed ({e}), returning top-{top_n} by score")
        return docs[:top_n]


# ─────────────────────────────────────────────────────────────────────────────
# Scoring helpers
# ─────────────────────────────────────────────────────────────────────────────

def compute_time_decay(timestamp: float, decay_days: int = 15) -> float:
    """Exponential decay: recent = strong, old = fades."""
    now_ts = datetime.now(timezone.utc).timestamp()
    age_days = (now_ts - timestamp) / 86_400
    if age_days <= 0:
        return 1.0
    return math.exp(-age_days / decay_days)


# ─────────────────────────────────────────────────────────────────────────────
# Chunking
# ─────────────────────────────────────────────────────────────────────────────

def _chunk_text(text: str, chunk_size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> list:
    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
    chunks, current = [], ""
    for para in paragraphs:
        if len(current) + len(para) + 2 > chunk_size:
            if current:
                chunks.append(current.strip())
            current = current[-overlap:] + "\n\n" + para if current else para
        else:
            current = (current + "\n\n" + para).strip()
    if current:
        chunks.append(current.strip())
    logger.info(f"[MEMORY] Chunked into {len(chunks)} chunk(s)")
    return chunks if chunks else [text]


# ─────────────────────────────────────────────────────────────────────────────
# Point ID (deterministic)
# ─────────────────────────────────────────────────────────────────────────────

def generate_point_id(horse_id, memory_type, source, idx):
    raw = f"{horse_id}_{memory_type}_{source}_{idx}"
    return hashlib.md5(raw.encode()).hexdigest()


# ─────────────────────────────────────────────────────────────────────────────
# Upsert
# ─────────────────────────────────────────────────────────────────────────────

def _upsert_chunks(
    client,
    chunks,
    horse_id,
    memory_type,
    source,
    embeddings_inst,
    timestamp=None,
    importance=1.0,
    extra_payload=None,
):
    from qdrant_client.models import PointStruct

    if not chunks:
        return

    vectors = embeddings_inst.embed_documents(chunks)
    points = []
    for i, (chunk, vec) in enumerate(zip(chunks, vectors)):
        payload = {
            "horse_id":    str(horse_id),
            "memory_type": memory_type,
            "source":      source,
            "text":        chunk,
            "timestamp":   timestamp,
            "importance":  importance,
        }
        if extra_payload:
            payload.update(extra_payload)

        points.append(
            PointStruct(
                id=generate_point_id(horse_id, memory_type, source, i),
                vector=vec,
                payload=payload,
            )
        )

    client.upsert(collection_name=COLLECTION, points=points)
    logger.info(
        f"[QDRANT] Upserted {len(points)} points | "
        f"horse={horse_id} | type={memory_type} | source={source}"
    )


# ─────────────────────────────────────────────────────────────────────────────
# Core retrieval  (fixed date handling + null-timestamp penalty + retry)
# ─────────────────────────────────────────────────────────────────────────────

def retrieve_from_qdrant(
    query: str,
    horse_id,
    embeddings,
    k: int = RETRIEVAL_K,
    memory_types: Optional[list] = None,
    force_daily: bool = False,
    target_date: Optional[date] = None,      # must be a date object or None
) -> list:
    """
    Retrieve top-k chunks from Qdrant.

    target_date must be a date object (not the raw dict from extract_date_from_query).
    Unwrap before calling:
        raw = extract_date_from_query(question)
        target_date = raw["date"] if raw and raw["type"] == "exact" else None
    """
    from langchain_core.documents import Document
    from qdrant_client.models import Filter, FieldCondition, MatchValue, MatchAny

    client = _get_client()

    try:
        query_vector = embeddings.embed_query(query)
    except Exception as e:
        logger.error(f"[RETRIEVE] Embed query failed: {e}")
        return []

    # ── Primary filter ──────────────────────────────────────────────────────
    must_conditions = [
        FieldCondition(key="horse_id", match=MatchValue(value=str(horse_id)))
    ]

    if target_date is not None:
        target_str = target_date.strftime("%Y-%m-%d")
        must_conditions.append(
            FieldCondition(key="activity_date", match=MatchValue(value=target_str))
        )

    if memory_types:
        must_conditions.append(
            FieldCondition(key="memory_type", match=MatchAny(any=memory_types))
        )

    try:
        results = client.query_points(
            collection_name=COLLECTION,
            query=query_vector,
            query_filter=Filter(must=must_conditions),
            limit=k,
            with_payload=True,
        )
        hits = list(results.points)
    except Exception as e:
        logger.error(f"[RETRIEVE] Qdrant query failed: {e}")
        return []

    # ── Zero-result retry: expand to all types ──────────────────────────────
    if not hits and memory_types:
        logger.info(f"[RETRIEVE] Zero results for types={memory_types}, retrying with all types")
        try:
            fallback_conditions = [
                FieldCondition(key="horse_id", match=MatchValue(value=str(horse_id)))
            ]
            if target_date is not None:
                fallback_conditions.append(
                    FieldCondition(key="activity_date", match=MatchValue(value=target_str))
                )
            results = client.query_points(
                collection_name=COLLECTION,
                query=query_vector,
                query_filter=Filter(must=fallback_conditions),
                limit=k,
                with_payload=True,
            )
            hits = list(results.points)
        except Exception as e:
            logger.error(f"[RETRIEVE] Fallback query failed: {e}")

    # ── Force-include recent daily summaries when intent is daily_activity ──
    daily_hits = []

    if force_daily and target_date is None:
        try:
            daily_results = client.query_points(
                collection_name=COLLECTION,
                query=query_vector,
                query_filter=Filter(must=[
                    FieldCondition(key="horse_id", match=MatchValue(value=str(horse_id))),
                    FieldCondition(key="memory_type", match=MatchValue(value="daily_summary")),
                ]),
                limit=5,
                with_payload=True,
            )
            daily_hits = list(daily_results.points)
        except Exception as e:
            logger.warning(f"[RETRIEVE] Force-daily fetch failed: {e}")

    # Merge, dedup by point id
    seen_ids = {h.id for h in hits}
    for dh in daily_hits:
        if dh.id not in seen_ids:
            hits.append(dh)
            seen_ids.add(dh.id)

    # ── Score each hit ──────────────────────────────────────────────────────
    now_ts = datetime.now(timezone.utc).timestamp()
    docs = []

    for hit in hits:
        payload    = hit.payload or {}
        base_score = hit.score
        timestamp  = payload.get("timestamp")
        importance = float(payload.get("importance", 1.0))
        mem_type   = payload.get("memory_type", "")

        # FIX: null timestamp is penalised, not rewarded
        if timestamp is None:
            time_weight = 0.5
        else:
            time_weight = compute_time_decay(timestamp)

        recency_bonus = 0.0
        if mem_type == "daily_summary" and timestamp is not None:
            age_days = (now_ts - timestamp) / 86_400
            if age_days <= 1:
                recency_bonus = 0.25   # today / yesterday
            elif age_days <= 7:
                recency_bonus = 0.15   # this week
            elif age_days <= 30:
                recency_bonus = 0.05

        final_score = (
            base_score * (0.55 + 0.25 * time_weight + 0.20 * min(importance, 3.0))
            + recency_bonus
        )

        docs.append(
            Document(
                page_content=payload.get("text", ""),
                metadata={
                    "score":               final_score,
                    "base_score":          base_score,
                    "memory_type":         mem_type,
                    "source":              payload.get("source"),
                    "activity_date":       payload.get("activity_date"),
                    "activity_date_label": payload.get("activity_date_label"),
                    "video_id":            payload.get("video_id", ""),
                    "show_id":             payload.get("show_id", ""),
                    "video_heading":       payload.get("video_heading", ""),
                },
            )
        )

    docs.sort(key=lambda d: d.metadata["score"], reverse=True)

    # Content-hash dedup
    seen_hashes: set = set()
    unique_docs = []
    for doc in docs:
        h = hashlib.md5(doc.page_content.encode()).hexdigest()
        if h not in seen_hashes:
            seen_hashes.add(h)
            unique_docs.append(doc)

    logger.info(
        f"[RETRIEVE] {len(unique_docs)} unique docs | horse={horse_id} | "
        f"types={memory_types or 'all'} | force_daily={force_daily} | q='{query[:80]}'"
    )
    return unique_docs


# ─────────────────────────────────────────────────────────────────────────────
# Async DB → Qdrant sync  (fire-and-forget, no longer blocks requests)
# ─────────────────────────────────────────────────────────────────────────────

def _run_sync_in_background(horse_id, btr_fetcher, daily_fetcher, embeddings):
    """Background thread target — silently syncs DB → Qdrant."""
    try:
        btr_rows   = btr_fetcher()   if btr_fetcher   else []
        daily_rows = daily_fetcher() if daily_fetcher else []
        if embeddings and horse_id:
            ensure_summaries_indexed(
                horse_id=horse_id,
                btr_rows=btr_rows,
                daily_rows=daily_rows,
                embeddings=embeddings,
            )
    except Exception:
        logger.exception("[SYNC BG] Failed")


def build_memory_context(
    user_input: str = "",
    btr_fetcher=None,
    daily_fetcher=None,
    embeddings=None,
    horse_id=None,
):
    """
    Fire-and-forget: syncs MySQL summaries into Qdrant in a daemon thread
    so the request pipeline is NOT blocked.
    Returns ("", "") for interface compatibility.
    """
    t = threading.Thread(
        target=_run_sync_in_background,
        args=(horse_id, btr_fetcher, daily_fetcher, embeddings),
        daemon=True,
    )
    t.start()
    logger.info(f"[SYNC BG] Launched background sync thread | horse={horse_id}")
    return "", ""


# ─────────────────────────────────────────────────────────────────────────────
# ensure_summaries_indexed  (unchanged logic, kept for completeness)
# ─────────────────────────────────────────────────────────────────────────────

def ensure_summaries_indexed(horse_id, btr_rows, daily_rows, embeddings):
    from qdrant_client.models import Filter, FieldCondition, MatchValue

    client = _get_client()

    def already_indexed(source: str) -> bool:
        try:
            res = client.count(
                collection_name=COLLECTION,
                count_filter=Filter(must=[
                    FieldCondition(key="horse_id", match=MatchValue(value=str(horse_id))),
                    FieldCondition(key="source",   match=MatchValue(value=source)),
                ]),
                exact=True,
            )
            return res.count > 0
        except Exception:
            return False

    for row in btr_rows:
        if not row.get("memory_summary"):
            continue
        source = f"show_{row['id']}"
        if already_indexed(source):
            continue

        full_text = (
            f"Show: {row.get('video_heading', '')}\n\n"
            f"{row.get('memory_summary', '')}\n\n"
            f"Key Points:\n{row.get('summary_key_points', '')}"
        ).strip()

        _upsert_chunks(
            client=client,
            chunks=_chunk_text(full_text),
            horse_id=horse_id,
            memory_type="btr_show_summary",
            source=source,
            embeddings_inst=embeddings,
            timestamp=datetime.now(timezone.utc).timestamp(),
            importance=1.0,
            extra_payload={
                "show_id":       str(row["id"]),
                "video_id":      str(row.get("video_show_id", "") or row.get("id", "")),
                "video_heading": str(row.get("video_heading", "")),
            },
        )

    for row in daily_rows:
        if not row.get("memory_summary"):
            continue
        date_str = str(row.get("created_at"))[:10]
        source   = f"daily_{date_str}"
        if already_indexed(source):
            continue

        try:
            dt = datetime.strptime(date_str, "%Y-%m-%d").replace(tzinfo=timezone.utc)
            ts = dt.timestamp()
            date_label = dt.strftime("%A, %d %B %Y")
        except Exception:
            ts = datetime.now(timezone.utc).timestamp()
            date_label = date_str

        headed_text = f"[Daily Activity — {date_label}]\n\n{row['memory_summary']}"

        _upsert_chunks(
            client=client,
            chunks=_chunk_text(headed_text),
            horse_id=horse_id,
            memory_type="daily_summary",
            source=source,
            embeddings_inst=embeddings,
            timestamp=ts,
            importance=1.5,
            extra_payload={
                "activity_date":       date_str,
                "activity_date_label": date_label,
                "video_id":            str(row.get("id", "")),
            },
        )


# ─────────────────────────────────────────────────────────────────────────────
# Indexing helpers (unchanged)
# ─────────────────────────────────────────────────────────────────────────────

_JSON_TO_TEXT_PROMPT = """
You are a memory encoder for an AI horse-personality chatbot.
You receive structured JSON data about a racing stable. It may cover:
  - Facility layout, buildings, zones, paths and distances
  - Equipment items, their purpose, and therapeutic usage
  - Staff members — roles, schedules, personalities, relationships to horses
  - Individual horse traits — physical, behavioural, quirks, personality tags

Transform this JSON into clear, richly detailed natural-language paragraphs
that a horse named {horse_name} could plausibly know or talk about from its
perspective as a resident of this stable.

Rules:
  - Write in third-person descriptive prose. No Q&A format.
  - Be specific: include names, dimensions, colours, schedules, personality notes.
  - Group related facts into coherent paragraphs with a short plain-text heading.
  - Do NOT invent facts. Only describe what is in the JSON.
  - Output plain text only — no JSON, no markdown tables, no bullet lists.
  - Aim for 300 to 600 words per major section.
""".strip()


def _load_json_file(base_dir, relative_path):
    full_path = os.path.join(base_dir, relative_path)
    if not os.path.exists(full_path):
        logger.warning(f"[MEMORY] NOT FOUND: {full_path}")
        return None
    try:
        with open(full_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        logger.exception(f"[MEMORY] Failed to parse: {relative_path}")
        return None


def _convert_json_to_text(open_ai_client, section_name, json_data, horse_name):
    response = open_ai_client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": _JSON_TO_TEXT_PROMPT.format(horse_name=horse_name)},
            {"role": "user",   "content": f"Section: {section_name}\n\nJSON data:\n{json.dumps(json_data, indent=2)}"},
        ],
        max_tokens=1500,
    )
    result = response.choices[0].message.content.strip()
    logger.info(f"[MEMORY] Converted | section={section_name} | {len(result)} chars")
    return result


def index_json_memories(open_ai_client, embeddings, horse_id, horse_name, faiss_index_path, base_dir):
    client = _get_client()
    for section_name, relative_path in _MEMORY_JSON_FILES.items():
        json_data = _load_json_file(base_dir, relative_path)
        if json_data is None:
            continue

        if section_name == "horses":
            horses_list = json_data.get("horses", [])
            matched = [h for h in horses_list if h.get("name", "").lower() == horse_name.lower()]
            json_data = {
                "this_horse": matched[0] if matched else {},
                "stable_mates": [
                    {"name": h["name"], "personality_tags": h.get("personality_tags", []),
                     "behavioral_profile": h.get("behavioral_profile", {})}
                    for h in horses_list if h.get("name", "").lower() != horse_name.lower()
                ],
            }

        natural_text = _convert_json_to_text(open_ai_client, section_name, json_data, horse_name)
        _upsert_chunks(
            client=client, chunks=_chunk_text(natural_text),
            horse_id=horse_id, memory_type=section_name,
            source=f"memory_json_{section_name}", embeddings_inst=embeddings,
        )


def index_general_knowledge(text: str, horse_id: str, embeddings):
    client = _get_client()
    chunks = _chunk_text(text)
    _upsert_chunks(client=client, chunks=chunks, horse_id=horse_id,
                   memory_type="general", source="kb_document", embeddings_inst=embeddings)


def index_show_summary(horse_id, show_id, video_id, video_heading, memory_summary, summary_key_points, embeddings):
    client = _get_client()
    full_text = f"Show: {video_heading}\n\n{memory_summary}\n\nKey Points:\n{summary_key_points}".strip()
    _upsert_chunks(
        client=client, chunks=_chunk_text(full_text),
        horse_id=horse_id, memory_type="btr_show_summary", source=f"show_{show_id}",
        embeddings_inst=embeddings,
        extra_payload={"show_id": str(show_id), "video_id": str(video_id), "video_heading": video_heading},
    )


def index_daily_summary(horse_id, date_str, summary_text, embeddings, video_id=""):
    client = _get_client()
    try:
        dt = datetime.strptime(date_str, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        ts = dt.timestamp()
        date_label = dt.strftime("%A, %d %B %Y")
    except Exception:
        ts = datetime.now(timezone.utc).timestamp()
        date_label = date_str

    headed_text = f"[Daily Activity — {date_label}]\n\n{summary_text}"
    _upsert_chunks(
        client=client, chunks=_chunk_text(headed_text),
        horse_id=horse_id, memory_type="daily_summary", source=f"daily_{date_str}",
        embeddings_inst=embeddings, timestamp=ts,
        extra_payload={"activity_date": date_str, "activity_date_label": date_label,
                       "video_id": str(video_id) if video_id else ""},
    )


# ─────────────────────────────────────────────────────────────────────────────
# MySQL helpers
# ─────────────────────────────────────────────────────────────────────────────

def _get_db_connection():
    return mysql.connector.connect(
        host="192.168.0.3", port=3306,
        user="exceed_magento", password="2lKmg$4uSe",
        database="freeracehorse_development",
    )


def get_btr_show_summary(horse_id):
    conn = _get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute(
        """SELECT id, product_id, video_url, video_show_id, video_heading,
                  memory_summary, summary_key_points
           FROM exceedequine_video_management_system
           WHERE memory_summary IS NOT NULL AND product_id = %s
           ORDER BY id DESC LIMIT 20""",
        (str(horse_id),),
    )
    rows = cursor.fetchall()
    cursor.close(); conn.close()
    return rows


def get_horse_daily_summary(horse_id):
    conn = _get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute(
        """SELECT id, video_url, video_title, created_at, memory_summary, horse_id
           FROM exceedequine_ai_education_video
           WHERE horse_id = %s ORDER BY created_at DESC""",
        (horse_id,),
    )
    rows = cursor.fetchall()
    cursor.close(); conn.close()
    return rows


# ─────────────────────────────────────────────────────────────────────────────
# Cleanup helper
# ─────────────────────────────────────────────────────────────────────────────

def cleanup_old_memories(horse_id, days=30):
    from qdrant_client.models import Filter, FieldCondition, Range, MatchValue
    client = _get_client()
    cutoff = datetime.now(timezone.utc).timestamp() - (days * 86_400)
    client.delete(
        collection_name=COLLECTION,
        points_selector=Filter(must=[
            FieldCondition(key="horse_id",  match=MatchValue(value=str(horse_id))),
            FieldCondition(key="timestamp", range=Range(lt=cutoff)),
        ]),
    )
    logger.info(f"[CLEANUP] Deleted memories older than {days} days | horse={horse_id}")