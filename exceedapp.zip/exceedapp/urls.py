from django.urls import path
from .views import (
    UploadHorseDocuments,
    UploadHarnessDocuments,
    UpdateVectorStore,
    generate_email,
    CombinedFileProcessingWithMetadataAPI_agent,
)

urlpatterns = [
    path('upload/', UploadHorseDocuments.as_view(), name='upload'),
    path('upload_harness/', UploadHarnessDocuments.as_view(), name='upload_harness'),
    path('ragchatbot/', CombinedFileProcessingWithMetadataAPI_agent.as_view(), name='ragchatbot'),
    path('update_vector/', UpdateVectorStore.as_view(), name='update_vector'),
    path('generate_email/', generate_email, name='generate_email'),
    # path('chat/', CombinedFileProcessingWithMetadataAPI.as_view(), name='chat'),

]
