import os
import threading
import logging

logger = logging.getLogger(__name__)

# Use the same path only if you run embedded mode (not needed for Docker server)
QDRANT_PATH = "/var/www/html/aiml/ExceedEquine-TKCS-ML/exceedproject/qdrant_storage"

COLLECTION = "horses_memory"

VECTOR_SIZE = 1536  # text-embedding-ada-002

QDRANT_HOST = os.environ.get("QDRANT_HOST", "localhost")
QDRANT_PORT = int(os.environ.get("QDRANT_PORT", 6333))

_qdrant_client = None
_qdrant_client_lock = threading.Lock()


def _get_client():
    global _qdrant_client

    if _qdrant_client:
        return _qdrant_client

    with _qdrant_client_lock:
        if _qdrant_client:
            return _qdrant_client

        from qdrant_client import QdrantClient
        from qdrant_client.models import Distance, VectorParams

        logger.info("[QDRANT] Connecting to Qdrant server...")

        client = QdrantClient(
            host=QDRANT_HOST,
            port=QDRANT_PORT,
            timeout=60,
        )

        collections = client.get_collections().collections
        existing = [c.name for c in collections]

        if COLLECTION not in existing:
            logger.info(f"[QDRANT] Creating collection: {COLLECTION}")

            client.create_collection(
                collection_name=COLLECTION,
                vectors_config=VectorParams(
                    size=VECTOR_SIZE,
                    distance=Distance.COSINE,
                ),
            )

            # Create payload index (important for filtering by horse_id)
            client.create_payload_index(
                collection_name=COLLECTION,
                field_name="horse_id",
                field_schema="keyword",
            )

            logger.info(f"[QDRANT] Collection '{COLLECTION}' created")

        else:
            logger.info(f"[QDRANT] Using existing collection '{COLLECTION}'")

        _qdrant_client = client
        return _qdrant_client
