from __future__ import annotations
 
import hashlib
import json
import logging
import math
import os
import re
import threading
from collections import defaultdict
from datetime import date, datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

import dateparser
import mysql.connector
 
from pydantic import ConfigDict
 
from langchain_core.callbacks import CallbackManagerForRetrieverRun
from langchain_core.documents import Document
from langchain_core.output_parsers import JsonOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.retrievers import BaseRetriever
 
from langchain.retrievers import ContextualCompressionRetriever
from langchain.retrievers.document_compressors import LLMListwiseRerank
 
from langchain_text_splitters import RecursiveCharacterTextSplitter   
from langchain_openai import ChatOpenAI, OpenAIEmbeddings              
from langchain_qdrant import QdrantVectorStore                         
 
from qdrant_client.models import (
    FieldCondition,
    Filter,
    MatchAny,
    MatchValue,
    Range,
)
from qdrant_client import models
from .qdrant_conn import _get_client
from .prompt import GUARDRAIL_HUMAN, GUARDRAIL_SYSTEM,_EVAL_SYSTEM,_INTENT_SYSTEM,_JSON_TO_TEXT_PROMPT

from dotenv import load_dotenv
load_dotenv()

logger = logging.getLogger("ChatbotAPI")

COLLECTION   = "horses_memory"
VECTOR_SIZE  = 1536
EMBED_MODEL  = "text-embedding-ada-002"
 
DAILY_CHUNK_SIZE    = 4000
DAILY_CHUNK_OVERLAP = 0
 
CHUNK_SIZE    = 800
CHUNK_OVERLAP = 100
 
RETRIEVAL_K  = 10
RERANK_TOP_N = 8

QUALITY_THRESHOLD = 0.75          
EXPANDED_RETRIEVAL_K = 20         
EXPANDED_RERANK_TOP_N = 12    

_MEMORY_JSON_FILES: Dict[str, str] = {
    "facility":  "Memories_Data/facility_memory_data.json",
    "equipment": "Memories_Data/equipment_details.json",
    "humans":    "Memories_Data/human_recognition_details.json",
    "horses":    "Memories_Data/horse_traits_memory.json",
}
 
CANDIDATE_MEMORY_TYPES: List[str] = [
    "general", "facility", "equipment", "humans",
    "horses", "daily_summary",
]
Daily_MEMORY_TYPES = ["daily_summary"]
 
DEFAULT_FALLBACK_TYPES: List[str] = ["general", "daily_summary"]


INTENT_TO_TYPES: Dict[str, List[str]] = {
    "daily_activity":   ["daily_summary"],
    # "show_competition": ["btr_show_summary"],
    "weather_current":  [],                   # no Qdrant, answered from API
    "weather_past":     ["daily_summary"],    # Qdrant daily summary for the date
    "facility":         ["facility"],
    "equipment":        ["equipment"],
    "staff_people":     ["humans"],
    "other_horses":     ["horses"],
    "general_horse":    ["general"],
    "conversation":     ["general", "daily_summary"],
    "mixed":            CANDIDATE_MEMORY_TYPES,
}
_TYPE_ORDER: List[str] = [
    "daily_summary", "general",
    "equipment", "humans", "facility", "horses",
]
 
_TYPE_LABELS: Dict[str, str] = {
    "daily_summary":    "Recent Daily Activity",
    "general":          "General Knowledge",
    # "btr_show_summary": "Show & Competition Memory",
    "equipment":        "Equipment & Therapy",
    "humans":           "Staff & People",
    "facility":         "Stable & Facility",
    "horses":           "Horses in the Barn",
}
 
CANNED_BUCKETS = {"greeting", "horse_general", "challenge", "gibberish", "off_topic"}

# Standard splitter — show summaries, JSON knowledge, general text
_standard_splitter = RecursiveCharacterTextSplitter(
    chunk_size=CHUNK_SIZE,
    chunk_overlap=CHUNK_OVERLAP,
    separators=["\n\n", "\n", ". ", " ", ""],
    length_function=len,
)
 
# Daily splitter — very large window so one date = one Document
_daily_splitter = RecursiveCharacterTextSplitter(
    chunk_size=DAILY_CHUNK_SIZE,
    chunk_overlap=DAILY_CHUNK_OVERLAP,
    separators=["\n\n", "\n", ". ", " ", ""],
    length_function=len,
)
 
 
def split_text(text: str, daily: bool = False) -> List[str]:
    """Return chunks using the appropriate LC splitter."""
    splitter = _daily_splitter if daily else _standard_splitter
    chunks   = splitter.split_text(text)
    logger.debug(f"[SPLIT] {'daily' if daily else 'standard'} → {len(chunks)} chunk(s)")
    return chunks if chunks else [text]
 
def _get_vector_store(embeddings: OpenAIEmbeddings) -> QdrantVectorStore:
    """
    Wrap the existing Qdrant collection in a LangChain QdrantVectorStore.
    content_payload_key="text" maps the Qdrant "text" payload field to
    Document.page_content.  All other payload fields become metadata automatically.
    """
    return QdrantVectorStore(
        client=_get_client(),
        collection_name=COLLECTION,
        embedding=embeddings,
        content_payload_key="text",
        metadata_payload_key="metadata"
        # metadata_payload_key=None,
    )
 
def _make_point_id(horse_id: Any, memory_type: str, source: str, idx: int) -> str:
    raw = f"{horse_id}_{memory_type}_{source}_{idx}"
    return hashlib.md5(raw.encode()).hexdigest()
 
def _upsert_docs(
    chunks: List[str],
    horse_id: Any,
    memory_type: str,
    source: str,
    embeddings: OpenAIEmbeddings,
    timestamp: Optional[float] = None,
    importance: float = 1.0,
    extra_meta: Optional[Dict[str, Any]] = None,
) -> None:
    if not chunks:
        return

    client = _get_client()
    vectors = embeddings.embed_documents(chunks)

    points = []
    for i, (chunk, vector) in enumerate(zip(chunks, vectors)):
        payload: Dict[str, Any] = {
            "text":        chunk,
            "horse_id":    str(horse_id),
            "memory_type": memory_type,
            "source":      source,
            "importance":  float(importance),
        }
        if timestamp is not None:
            payload["timestamp"] = float(timestamp)

        if extra_meta:
            for k, v in extra_meta.items():
                if k is not None and v is not None:
                    payload[str(k)] = v

        points.append(models.PointStruct(
            id=_make_point_id(horse_id, memory_type, source, i),
            vector=vector,
            payload=payload,
        ))

    client.upsert(collection_name=COLLECTION, points=points)
    logger.info(
        f"[QDRANT] Upserted {len(chunks)} doc(s) | "
        f"horse={horse_id} | type={memory_type} | source={source}"
    )

def resolve_query_dates(query: str) -> List[date]:
    """
    Dynamically extract ALL dates from query using dateparser on
    individual tokens — no hardcoded N-date regex patterns.
    """
    q   = query.lower().strip()
    now = datetime.now(timezone.utc)
    found: List[date] = []

    # ── ISO dates (2026-04-13) ────────────────────────────────────────────────
    for m in re.finditer(r"\b(\d{4}-\d{2}-\d{2})\b", q):
        try:
            found.append(datetime.strptime(m.group(), "%Y-%m-%d").date())
        except Exception:
            pass
    if found:
        return sorted(set(found))

    # ── "X days ago" ──────────────────────────────────────────────────────────
    for m in re.finditer(r"(\d+)\s+days?\s+ago", q):
        found.append((now - timedelta(days=int(m.group(1)))).date())
    if found:
        return sorted(set(found))

    # ── Vague recency → no pinned dates ───────────────────────────────────────
    vague = {"recent", "lately", "this week", "last week", "recently"}
    if any(w in q for w in vague):
        return []

    # ── Dynamic: find month name(s) in query, then collect ALL nearby day numbers
    month_map = {
        "january": 1, "february": 2, "march": 3,    "april": 4,
        "may": 5,     "june": 6,     "july": 7,     "august": 8,
        "september": 9, "october": 10, "november": 11, "december": 12,
    }
    month_pattern = "|".join(month_map.keys())

    # Find all months mentioned
    months_found = re.findall(rf"\b({month_pattern})\b", q)

    if months_found:
        # Collect ALL day numbers in the entire query (e.g. "13, 14 and 15" → [13,14,15])
        day_numbers = re.findall(r"\b(\d{1,2})(?:st|nd|rd|th)?\b", q)
        # Filter to valid day values only (1-31)
        day_numbers = [d for d in day_numbers if 1 <= int(d) <= 31]

        # Use the first (or only) month found; if multiple months, pair each day with nearest month
        for day in day_numbers:
            month = months_found[0]   # default: first month mentioned
            try:
                parsed = dateparser.parse(
                    f"{day} {month}",
                    settings={"PREFER_DATES_FROM": "past", "RELATIVE_BASE": now},
                )
                if parsed:
                    found.append(parsed.date())
            except Exception:
                pass

    if found:
        return sorted(set(found))

    # ── Named relative dates (yesterday, today, last Monday…) ─────────────────
    relative_matches = re.findall(
        r"\b(yesterday|today|last (?:monday|tuesday|wednesday|thursday|friday|saturday|sunday))\b",
        q,
    )
    for phrase in relative_matches:
        try:
            parsed = dateparser.parse(
                phrase,
                settings={"PREFER_DATES_FROM": "past", "RELATIVE_BASE": now},
            )
            if parsed:
                found.append(parsed.date())
        except Exception:
            pass

    if found:
        return sorted(set(found))

    # ── Full-query dateparser fallback (single date) ───────────────────────────
    try:
        parsed = dateparser.parse(
            q,
            settings={
                "PREFER_DATES_FROM": "past",
                "RELATIVE_BASE": now,
                "RETURN_AS_TIMEZONE_AWARE": True,
            },
        )
        if parsed:
            found.append(parsed.date())
    except Exception:
        pass

    return sorted(set(found))


def resolve_query_date(query: str) -> Optional[date]:
    """Returns the earliest date found, for backward compatibility."""
    dates = resolve_query_dates(query)
    return dates[0] if dates else None


def is_recency_query(query: str) -> bool:
    """True when query implies 'recent / ongoing' without pinning to a date."""
    keywords = {
        "recent", "lately", "this week", "last week", "recently",
        "what have you been", "what's new", "any updates", "what did you do",
    }
    return any(k in query.lower() for k in keywords)
 

 
_INTENT_PROMPT = ChatPromptTemplate.from_messages([
    ("system", _INTENT_SYSTEM),
    ("human",  "{query}"),
])
 
def rewrite_and_classify(query: str, llm: ChatOpenAI) -> Dict[str, Any]:
    _fallback: Dict[str, Any] = {
        "rewritten_query": query,
        "intent":          "conversation",
        "memory_types":    DEFAULT_FALLBACK_TYPES,
        "force_daily":     is_recency_query(query),
        "resolved_date":   resolve_query_date(query),
    }

    try:
        chain  = _INTENT_PROMPT | llm | JsonOutputParser()
        result: Dict[str, Any] = chain.invoke({"query": query})

        rw = str(result.get("rewritten_query", "")).strip()
        result["rewritten_query"] = rw if len(rw) >= 3 else query

        valid = [t for t in result.get("memory_types", []) if t in CANDIDATE_MEMORY_TYPES]

        # ── Weather intent: distinguish past-date vs current ──────────────────
        if result.get("intent") == "weather":
            resolved_date = resolve_query_date(query)

            if resolved_date:
                # Past-date weather → needs daily_summary retrieval from Qdrant
                result["intent"]       = "weather_past"
                result["memory_types"] = ["daily_summary"]
                result["force_daily"]  = True
            else:
                # Current/today weather → weather API only, no Qdrant needed
                result["intent"]       = "weather_current"
                result["memory_types"] = []
                result["force_daily"]  = False
        else:
            result["memory_types"] = valid if valid else DEFAULT_FALLBACK_TYPES

        # Guard: unknown intents fall back to conversation
        if result.get("intent") not in {*INTENT_TO_TYPES.keys(), "weather_past", "weather_current"}:
            result["intent"] = "conversation"

        result["force_daily"]   = bool(result.get("force_daily", False)) or is_recency_query(query)
        result["resolved_date"] = resolve_query_date(query)

        logger.info(
            f"[INTENT] q='{query[:50]}' → rw='{result['rewritten_query'][:50]}' "
            f"| intent={result['intent']} | types={result['memory_types']} "
            f"| force_daily={result['force_daily']} | date={result['resolved_date']}"
        )
        return result

    except Exception as exc:
        logger.warning(f"[INTENT] Chain failed ({exc}), using fallback")
        return _fallback
    
# def rewrite_and_classify(query: str, llm: ChatOpenAI) -> Dict[str, Any]:
#     _fallback: Dict[str, Any] = {
#         "rewritten_query": query,
#         "intent":          "conversation",
#         "memory_types":    DEFAULT_FALLBACK_TYPES,
#         "force_daily":     is_recency_query(query),
#         "resolved_date":   resolve_query_date(query),
#     }

#     try:
#         chain  = _INTENT_PROMPT | llm | JsonOutputParser()
#         result: Dict[str, Any] = chain.invoke({"query": query})

#         rw = str(result.get("rewritten_query", "")).strip()
#         result["rewritten_query"] = rw if len(rw) >= 3 else query

#         valid = [t for t in result.get("memory_types", []) if t in CANDIDATE_MEMORY_TYPES]

#         # ── Weather intent never needs Qdrant retrieval ───────────────────────
#         if result.get("intent") == "weather":
#             result["memory_types"] = []
#             result["force_daily"]  = False
#         else:
#             result["memory_types"] = valid if valid else DEFAULT_FALLBACK_TYPES

#         if result.get("intent") not in INTENT_TO_TYPES:
#             result["intent"] = "conversation"

#         result["force_daily"]   = bool(result.get("force_daily", False)) or is_recency_query(query)
#         result["resolved_date"] = resolve_query_date(query)

#         logger.info(
#             f"[INTENT] q='{query[:50]}' → rw='{result['rewritten_query'][:50]}' "
#             f"| intent={result['intent']} | types={result['memory_types']} "
#             f"| force_daily={result['force_daily']} | date={result['resolved_date']}"
#         )
#         return result

#     except Exception as exc:
#         logger.warning(f"[INTENT] Chain failed ({exc}), using fallback")
#         return _fallback

def _score_document(
    doc: Document,
    base_score: float,
    now_ts: float,
    date_str: Optional[str],
) -> Document:
    """Attach final_score to a Document's metadata in-place and return it."""
    meta       = doc.metadata or {}
    timestamp  = meta.get("timestamp")
    importance = float(meta.get("importance", 1.0))
    mem_type   = meta.get("memory_type", "")
 
    # Time decay (null timestamp → penalise with 0.5 weight)
    if timestamp is None:
        time_weight = 0.5
    else:
        age_days    = (now_ts - float(timestamp)) / 86_400
        time_weight = math.exp(-max(age_days, 0.0) / 15.0)
 
    # Recency bonus for daily summaries
    recency_bonus = 0.0
    if mem_type == "daily_summary" and timestamp is not None:
        age_days = (now_ts - float(timestamp)) / 86_400
        if   age_days <= 1:  recency_bonus = 0.30
        elif age_days <= 7:  recency_bonus = 0.15
        elif age_days <= 30: recency_bonus = 0.05
 
    # Date-exact match gets a large bump
    date_bonus  = 0.40 if (date_str and meta.get("activity_date") == date_str) else 0.0
    final_score = (
        base_score * (0.55 + 0.25 * time_weight + 0.20 * min(importance, 3.0))
        + recency_bonus + date_bonus
    )
 
    doc.metadata["score"]      = final_score
    doc.metadata["base_score"] = base_score
    return doc
 
class HorseRetriever(BaseRetriever):
    """
    Four-layer priority retriever backed by QdrantVectorStore.
 
    Pydantic v2 notes (langchain 1.x):
    • model_config = ConfigDict(arbitrary_types_allowed=True) replaces
      the old `class Config: arbitrary_types_allowed = True` syntax.
    • All fields typed as Any are accepted without schema validation.
 
    Layers:
      L1 — date-exact daily_summary  (when resolved_date is set)
      L2 — memory-type filtered semantic search
      L3 — all-types fallback         (only when L1+L2 return nothing)
      L4 — recent daily boost         (force_daily=True, no pinned date)
    """
 
    model_config = ConfigDict(arbitrary_types_allowed=True)
 
    # ── Fields ───────────────────────────────────────────────────────────────
    horse_id:      Any
    embeddings:    Any                    
    memory_types:  List[str]  = []
    force_daily:   bool       = False
    resolved_date: Optional[date] = None
    k:             int        = RETRIEVAL_K
  
    def _store(self) -> QdrantVectorStore:
        return _get_vector_store(self.embeddings)
 
    @staticmethod
    def _build_filter(
        horse_id: Any,
        memory_types: Optional[List[str]] = None,
        date_str: Optional[str] = None,
        memory_type_exact: Optional[str] = None,
    ) -> Filter:
        
        must: list = [
            FieldCondition(key="horse_id", match=MatchValue(value=str(horse_id)))
        ]
        if date_str:
            must.append(FieldCondition(key="activity_date", match=MatchValue(value=date_str)))
        if memory_type_exact:
            must.append(FieldCondition(key="memory_type",   match=MatchValue(value=memory_type_exact)))
        elif memory_types:
            must.append(FieldCondition(key="memory_type",   match=MatchAny(any=memory_types)))
        return Filter(must=must)
 
    def _run_search(
        self,
        store: QdrantVectorStore,
        query: str,
        qdrant_filter: Filter,
        limit: int,
        now_ts: float,
        date_str: Optional[str],
    ) -> List[Document]:
        """Execute one QdrantVectorStore layer and attach scores."""
        try:
            # similarity_search_with_relevance_scores → List[(Document, float)]
            scored: List[tuple] = store.similarity_search_with_relevance_scores(
                query=query, k=limit, filter=qdrant_filter,
            )
        except Exception as exc:
            logger.error(f"[SEARCH] Layer failed: {exc}")
            return []
 
        docs = [_score_document(doc, score, now_ts, date_str) for doc, score in scored]
        docs.sort(key=lambda d: d.metadata.get("score", 0.0), reverse=True)
        return docs
 
    # ── BaseRetriever protocol ────────────────────────────────────────────────
 
    def _get_relevant_documents(
        self,
        query: str,
        *,
        run_manager: CallbackManagerForRetrieverRun,
    ) -> List[Document]:
 
        store    = self._store()
        date_str = self.resolved_date.strftime("%Y-%m-%d") if self.resolved_date else None
        now_ts   = datetime.now(timezone.utc).timestamp()
        seen:    set          = set()   
        hits:    List[Document] = []
 
        def _merge(layer_docs: List[Document], tag: str) -> None:
            added = 0
            for d in layer_docs:
                h = hashlib.md5(d.page_content.encode()).hexdigest()
                if h not in seen:
                    seen.add(h)
                    hits.append(d)
                    added += 1
            logger.info(f"[RETRIEVE] {tag} → +{added} docs (running total={len(hits)})")
 
        if self.resolved_date:
            l1 = self._run_search(
                store, query,
                self._build_filter(self.horse_id, date_str=date_str, memory_type_exact="daily_summary"),
                limit=5, now_ts=now_ts, date_str=date_str,
            )
            _merge(l1, "L1-date-exact-daily")
 
        l2_kwargs: Dict[str, Any] = {}
        if self.memory_types:
            l2_kwargs["memory_types"] = self.memory_types
        if date_str:
            l2_kwargs["date_str"] = date_str
 
        l2 = self._run_search(
            store, query,
            self._build_filter(self.horse_id, **l2_kwargs),
            limit=self.k, now_ts=now_ts, date_str=date_str,
        )
        _merge(l2, "L2-type-filtered")
 
        if not hits:
            logger.info("[RETRIEVE] L3 fallback: expanding to all types")
            l3_kwargs: Dict[str, Any] = {}
            if date_str:
                l3_kwargs["date_str"] = date_str
            l3 = self._run_search(
                store, query,
                self._build_filter(self.horse_id, **l3_kwargs),
                limit=self.k, now_ts=now_ts, date_str=date_str,
            )
            _merge(l3, "L3-all-types-fallback")
 
        # L4 — recent daily boost (force_daily=True, no pinned date)
        if self.force_daily and not self.resolved_date:
            l4 = self._run_search(
                store, query,
                self._build_filter(self.horse_id, memory_type_exact="daily_summary"),
                limit=5, now_ts=now_ts, date_str=None,
            )
            _merge(l4, "L4-recent-daily-boost")
 
        hits.sort(key=lambda d: d.metadata.get("score", 0.0), reverse=True)

        logger.info(
            f"[RETRIEVE] Final: {len(hits)} unique docs | horse={self.horse_id} | "
            f"resolved_date={self.resolved_date} | force_daily={self.force_daily}"
        )
        return hits
 
def build_retrieval_chain(
    horse_id: Any,
    embeddings: OpenAIEmbeddings,
    llm: ChatOpenAI,
    memory_types: List[str],
    force_daily: bool,
    resolved_date: Optional[date],
    k: int   = RETRIEVAL_K,
    top_n: int = RERANK_TOP_N,
) -> ContextualCompressionRetriever:
    """
    Assemble the retrieval chain:
 
        HorseRetriever (4-layer Qdrant)
            ↓
        LLMListwiseRerank (LC standard listwise compressor)
            ↓
        ContextualCompressionRetriever
 
    Usage in the LangGraph node:
        chain = build_retrieval_chain(...)
        docs  = chain.invoke(rewritten_query)   # → List[Document]
 
    LLMListwiseRerank prompts the LLM to rank all retrieved documents
    against each other and returns the top_n most relevant ones.
    It falls back to original score order on any LLM/parse error.
    """
    base_retriever = HorseRetriever(
        horse_id=horse_id,
        embeddings=embeddings,
        memory_types=memory_types,
        force_daily=force_daily,
        resolved_date=resolved_date,
        k=k,
    )
 
    reranker = LLMListwiseRerank.from_llm(llm=llm, top_n=top_n)
 
    return ContextualCompressionRetriever(
        base_compressor=reranker,
        base_retriever=base_retriever,
    )
 
 
def build_docs_content(
    context: List[Document],
    resolved_date: Optional[date] = None,
    force_daily: bool = False,
) -> str:
    """
    Format retrieved Documents into a knowledge-base string for the prompt.
 
    Hallucination guard:
    • Date-specific miss → inject [NO DATA for <date>] so the LLM cannot
      invent activities for a day that has no stored summary.
    • force_daily miss  → inject a softer "no recent activity" signal.
    """
    if not context:
        if resolved_date:
            readable = resolved_date.strftime("%A, %d %B %Y")
            return (
                f"[NO DATA — no activity summary found for {readable}. "
                f"Do not invent or guess any activities for this date.]\n"
            )
        return "[NO DATA — no relevant memories found for this question]\n"
 
    grouped: Dict[str, List[Document]] = defaultdict(list)
    for doc in context:
        grouped[doc.metadata.get("memory_type", "general")].append(doc)
 
    guard_note = ""
    if resolved_date:
        date_str     = resolved_date.strftime("%Y-%m-%d")
        daily_docs   = grouped.get("daily_summary", [])
        date_matched = any(d.metadata.get("activity_date") == date_str for d in daily_docs)
        if not date_matched:
            readable   = resolved_date.strftime("%A, %d %B %Y")
            guard_note = (
                f"\n[NO DAILY DATA for {readable} — do not invent activities "
                f"for this specific date. Use other knowledge sections if relevant; "
                f"otherwise tell the user honestly.]\n"
            )
    elif force_daily and not grouped.get("daily_summary"):
        guard_note = "\n[NO RECENT DAILY ACTIVITY logged — do not fabricate recent events.]\n"
 
    parts = ["KNOWLEDGE BASE:\n"]
    for mtype in _TYPE_ORDER:
        docs = grouped.get(mtype, [])
        if not docs:
            continue
        parts.append(f"--- {_TYPE_LABELS.get(mtype, mtype)} ---")
        for doc in docs:
            label = doc.metadata.get("activity_date_label", "")
            if mtype == "daily_summary" and label:
                parts.append(f"[{label}]\n{doc.page_content}")
            else:
                parts.append(doc.page_content)
        parts.append("")
 
    if guard_note:
        parts.append(guard_note)
 
    return "\n".join(parts)
 
_GUARDRAIL_PROMPT = ChatPromptTemplate.from_messages([
    ("system", GUARDRAIL_SYSTEM),
    ("human",  GUARDRAIL_HUMAN),
])


def run_guardrail(
    user_message: str,
    horse_name: str,
    user_name: str,
    llm: ChatOpenAI,
) -> Dict[str, Any]:
    """
    Classify the incoming message. Returns:
        bucket          : str   — one of 5 bucket names:
                                  horse_memory, horse_general, greeting,
                                  challenge, gibberish, off_topic
        canned_response : str   — pre-written answer ("" for horse_memory)
        skip_retrieval  : bool  — True when canned_response should be returned directly
    """
    _fallback = {"bucket": "horse_memory", "canned_response": "", "skip_retrieval": False}
    try:
        chain  = _GUARDRAIL_PROMPT | llm | JsonOutputParser()
        result = chain.invoke({
            "horse_name":   horse_name,
            "user_name":    user_name,
            "user_message": user_message,
        })
        bucket = result.get("bucket", "horse_memory")
        canned = str(result.get("canned_response", "")).strip()
        skip   = bucket in CANNED_BUCKETS and bool(canned)
        logger.info(f"[GUARDRAIL] bucket={bucket} | skip={skip} | msg='{user_message[:50]}'")
        return {"bucket": bucket, "canned_response": canned, "skip_retrieval": skip}
    except Exception as exc:
        logger.warning(f"[GUARDRAIL] Failed ({exc}), defaulting to horse_memory")
        return _fallback
    
def fetch_all_daily_chunks_for_date(
    horse_id: Any,
    date_str: str,            
    embeddings: OpenAIEmbeddings,
) -> List[Document]:
    """
    Retrieve EVERY chunk stored for a specific activity_date via Qdrant scroll.
    No k cap — guaranteed completeness for the pinned date.
    Called when resolved_date is set AND memory_types includes "daily_summary".
    """
    client = _get_client()
    qdrant_filter = Filter(must=[
        FieldCondition(key="horse_id",      match=MatchValue(value=str(horse_id))),
        FieldCondition(key="memory_type",   match=MatchValue(value="daily_summary")),
        FieldCondition(key="activity_date", match=MatchValue(value=date_str)),
    ])

    all_points: list = []
    offset = None
    while True:
        result, next_offset = client.scroll(
            collection_name=COLLECTION,
            scroll_filter=qdrant_filter,
            limit=100,
            offset=offset,
            with_payload=True,
            with_vectors=False,
        )
        all_points.extend(result)
        if next_offset is None:
            break
        offset = next_offset

    docs: List[Document] = []
    for point in all_points:
        payload = dict(point.payload or {})
        text    = payload.pop("text", "")
        docs.append(Document(page_content=text, metadata=payload))

    logger.info(
        f"[DAILY-FULL] date={date_str} | horse={horse_id} | fetched {len(docs)} chunk(s)"
    )
    return docs

def fetch_most_recent_daily_summary(
    horse_id: Any,
    embeddings: OpenAIEmbeddings,
) -> List[Document]:
    client = _get_client()
    qdrant_filter = Filter(must=[
        FieldCondition(key="horse_id",    match=MatchValue(value=str(horse_id))),
        FieldCondition(key="memory_type", match=MatchValue(value="daily_summary")),
    ])

    all_points: list = []
    offset = None
    while True:
        result, next_offset = client.scroll(
            collection_name=COLLECTION,
            scroll_filter=qdrant_filter,
            limit=200,
            offset=offset,
            with_payload=True,
            with_vectors=False,
        )
        all_points.extend(result)
        if next_offset is None:
            break
        offset = next_offset

    if not all_points:
        logger.info(f"[DAILY-RECENT] No daily summaries found | horse={horse_id}")
        return []

    def _ts(p) -> float:
        return float((p.payload or {}).get("timestamp", 0))

    all_points.sort(key=_ts, reverse=True)

    most_recent_date = (all_points[0].payload or {}).get("activity_date", "")
    if not most_recent_date:
        logger.warning(f"[DAILY-RECENT] Most recent point has no activity_date | horse={horse_id}")
        return []

    docs: List[Document] = []
    for point in all_points:
        payload = dict(point.payload or {})
        if payload.get("activity_date") == most_recent_date:
            text = payload.pop("text", "")
            if text:  
                docs.append(Document(page_content=text, metadata=payload))

    logger.info(
        f"[DAILY-RECENT] horse={horse_id} | most_recent_date={most_recent_date} | "
        f"chunks={len(docs)}"
    )
    return docs

_EVAL_PROMPT = ChatPromptTemplate.from_messages([
    ("system", _EVAL_SYSTEM),
    ("human", "USER QUESTION: {question}\n\nGENERATED ANSWER: {answer}"),
])

_EVAL_PROMPT = ChatPromptTemplate.from_messages([
    ("system", _EVAL_SYSTEM),
    ("human", """
USER QUESTION: {question}

AUTHORITATIVE RETRIEVED CONTEXT (GROUND TRUTH — USE THIS OVER THE QUESTION IF THEY CONFLICT):
{context}

GENERATED ANSWER:
{answer}
"""),
])

def evaluate_answer_quality(
    question: str,
    answer: str,
    context: str,   
    llm: ChatOpenAI,
) -> Dict[str, Any]:

    _fallback = {
        "score": 0.75,
        "reason": "Evaluator unavailable",
        "is_relevant": True
    }

    try:
        chain = _EVAL_PROMPT | llm | JsonOutputParser()

        result = chain.invoke({
            "question": question,
            "answer": answer,
            "context": context,   
        })

        score = max(
            0.0,
            min(1.0, float(result.get("score", 0.75)))
        )

        result["score"] = score
        result["is_relevant"] = bool(
            result.get(
                "is_relevant",
                score >= QUALITY_THRESHOLD
            )
        )

        logger.info(
            f"[EVAL] score={score:.2f} | "
            f"reason={result.get('reason','')[:80]}"
        )

        return result

    except Exception as exc:
        logger.warning(f"[EVAL] Failed ({exc})")
        return _fallback

def build_expanded_retrieval_chain(
    horse_id: Any,
    embeddings: OpenAIEmbeddings,
    llm: ChatOpenAI,
    resolved_date,
    force_daily: bool,
    k: int    = EXPANDED_RETRIEVAL_K,
    top_n: int = EXPANDED_RERANK_TOP_N,
):
    """All-types expanded retrieval used on retry when score < QUALITY_THRESHOLD."""
    from .chat_integration import build_retrieval_chain  
    return build_retrieval_chain(
        horse_id=horse_id,
        embeddings=embeddings,
        llm=llm,
        memory_types=CANDIDATE_MEMORY_TYPES,
        force_daily=force_daily,
        resolved_date=resolved_date,
        k=k,
        top_n=top_n,
    )

def build_memory_context(
    user_input: str = "",
    daily_fetcher=None,
    embeddings: Optional[OpenAIEmbeddings] = None,
    horse_id: Optional[Any] = None,
) -> tuple:
    """
    Sync MySQL → Qdrant BEFORE returning so retrieval always sees fresh data.
    Uses join(timeout=5) — blocks at most 5 seconds, never hangs the request.
    """
    def _run() -> None:
        try:
            # btr_rows   = btr_fetcher()   if btr_fetcher   else []
            daily_rows = daily_fetcher() if daily_fetcher else []
            if embeddings is not None and horse_id is not None:
                ensure_summaries_indexed(
                    horse_id=horse_id,
                    daily_rows=daily_rows,
                    embeddings=embeddings,
                )
        except Exception:
            logger.exception("[SYNC BG] Failed")

    t = threading.Thread(target=_run, daemon=True)
    t.start()

   
    t.join(timeout=5.0)

    if t.is_alive():
        logger.warning(f"[SYNC BG] Still running after timeout, continuing | horse={horse_id}")
    else:
        logger.info(f"[SYNC BG] Completed before timeout | horse={horse_id}")

    return "", ""
 

def _safe_str(value: Any, fallback: str = "") -> str:
    if value is None:
        return fallback
    s = str(value).strip()
    return fallback if s.lower() == "none" else s
 
 
def _already_indexed(horse_id: Any, source: str) -> bool:
    """Check whether a source is already present in Qdrant for this horse."""
    try:
        client = _get_client()
        return client.count(
            collection_name=COLLECTION,
            count_filter=Filter(must=[
                FieldCondition(key="horse_id", match=MatchValue(value=str(horse_id))),
                FieldCondition(key="source",   match=MatchValue(value=source)),
            ]),
            exact=True,
        ).count > 0
    except Exception:
        return False
 
 
def ensure_summaries_indexed(
    horse_id: Any,
    daily_rows: list,
    embeddings: OpenAIEmbeddings,
) -> None:
    """
    Sync MySQL rows → Qdrant.
 
    Daily summaries stored as TWO documents per date:
      • source = "daily_<date>"     — full narrative (mapped_summary)
      • source = "daily_<date>_kp"  — key facts     (summary_key_points)
 
    Both share activity_date so date-exact filters return both.
    """
    
    for row in daily_rows:
        if not row.get("mapped_summary"):
            continue
 
        created_at = row.get("created_at")
        if isinstance(created_at, datetime):
            date_str = created_at.strftime("%Y-%m-%d")
        else:
            date_str = str(created_at)[:10] if created_at else datetime.now(timezone.utc).strftime("%Y-%m-%d")
 
        try:
            dt         = datetime.strptime(date_str, "%Y-%m-%d").replace(tzinfo=timezone.utc)
            ts         = dt.timestamp()
            date_label = dt.strftime("%A, %d %B %Y")
        except Exception:
            ts         = datetime.now(timezone.utc).timestamp()
            date_label = date_str
            logger.warning(f"[SYNC] Bad date_str='{date_str}' | horse={horse_id}")
 
        common_meta = {
            "activity_date":       date_str,
            "activity_date_label": date_label,
            "video_id":            _safe_str(row.get("id")),
        }
 
        # ── A: Narrative chunk (mapped_summary) ───────────────────────────────
        source_narrative = f"daily_{date_str}"
        if not _already_indexed(horse_id, source_narrative):
            mapped_summary = _safe_str(row.get("mapped_summary"))
            headed_text    = f"[Daily Activity — {date_label}]\n\n{mapped_summary}"
            _upsert_docs(
                chunks=split_text(headed_text, daily=True),
                horse_id=horse_id,
                memory_type="daily_summary",
                source=source_narrative,
                embeddings=embeddings,
                timestamp=ts,
                importance=1.8,
                extra_meta={**common_meta, "chunk_role": "narrative"},
            )
            logger.info(f"[SYNC] Indexed narrative | horse={horse_id} | date={date_str}")
 
        # ── B: Key-points chunk (summary_key_points) ──────────────────────────
        source_kp  = f"daily_{date_str}_kp"
        key_points = _safe_str(row.get("summary_key_points"))
        if key_points and not _already_indexed(horse_id, source_kp):
            kp_text = f"[Key Points — {date_label}]\n\n{key_points}"
            _upsert_docs(
                chunks=[kp_text],   # single chunk, do not split
                horse_id=horse_id,
                memory_type="daily_summary",
                source=source_kp,
                embeddings=embeddings,
                timestamp=ts,
                importance=2.2,
                extra_meta={
                    **common_meta,
                    "chunk_role": "key_points",
                },
            )
            logger.info(f"[SYNC] Indexed key-points | horse={horse_id} | date={date_str}")
 

def _load_json_file(base_dir: str, relative_path: str) -> Optional[Any]:
    full_path = os.path.join(base_dir, relative_path)
    if not os.path.exists(full_path):
        logger.warning(f"[MEMORY] NOT FOUND: {full_path}")
        return None
    try:
        with open(full_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        logger.exception(f"[MEMORY] Failed to parse: {relative_path}")
        return None
 
 
def _convert_json_to_text(openai_client: Any, section_name: str, json_data: Any, horse_name: str) -> str:
    response = openai_client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": _JSON_TO_TEXT_PROMPT.format(horse_name=horse_name)},
            {"role": "user",   "content": f"Section: {section_name}\n\nJSON:\n{json.dumps(json_data, indent=2)}"},
        ],
        max_tokens=1500,
    )
    text = response.choices[0].message.content.strip()
    logger.info(f"[MEMORY] Converted JSON | section={section_name} | {len(text)} chars")
    return text
 
 
def index_json_memories(
    openai_client: Any, embeddings: OpenAIEmbeddings,
    horse_id: Any, horse_name: str, base_dir: str,
) -> None:
    for section_name, relative_path in _MEMORY_JSON_FILES.items():
        json_data = _load_json_file(base_dir, relative_path)
        if json_data is None:
            continue
        if section_name == "horses":
            horses_list = json_data.get("horses", [])
            matched     = [h for h in horses_list if h.get("name", "").lower() == horse_name.lower()]
            json_data   = {
                "this_horse":   matched[0] if matched else {},
                "stable_mates": [
                    {"name": h["name"],
                     "personality_tags":   h.get("personality_tags", []),
                     "behavioral_profile": h.get("behavioral_profile", {})}
                    for h in horses_list if h.get("name", "").lower() != horse_name.lower()
                ],
            }
        text = _convert_json_to_text(openai_client, section_name, json_data, horse_name)
        _upsert_docs(
            chunks=split_text(text), horse_id=horse_id,
            memory_type=section_name, source=f"memory_json_{section_name}",
            embeddings=embeddings,
        )
 
 
def index_general_knowledge(text: str, horse_id: Any, embeddings: OpenAIEmbeddings) -> None:
    _upsert_docs(chunks=split_text(text), horse_id=horse_id,
                 memory_type="general", source="kb_document", embeddings=embeddings)
 
 
def index_daily_summary(
    horse_id: Any,
    date_str: str,
    summary_text: str,
    embeddings: OpenAIEmbeddings,
    video_id: Any = "",
    key_points: str = "",
) -> None:

    try:
        dt = datetime.strptime(date_str, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        ts = dt.timestamp()
        date_label = dt.strftime("%A, %d %B %Y")
    except Exception:
        ts = datetime.now(timezone.utc).timestamp()
        date_label = date_str

    common_meta = {
        "activity_date": date_str,
        "activity_date_label": date_label,
        "video_id": str(video_id) if video_id else "",
    }
    narrative_source = f"daily_{date_str}"

    if not _already_indexed(horse_id, narrative_source):

        narrative_text = (
            f"[Daily Activity — {date_label}]\n\n"
            f"{summary_text}"
        )

        _upsert_docs(
            chunks=split_text(narrative_text, daily=True),
            horse_id=horse_id,
            memory_type="daily_summary",
            source=narrative_source,
            embeddings=embeddings,
            timestamp=ts,
            importance=1.8,
            extra_meta={
                **common_meta,
                "chunk_role": "narrative"
            },
        )

    if key_points:

        kp_source = f"daily_{date_str}_kp"

        if not _already_indexed(horse_id, kp_source):

            kp_text = (
                f"[Key Points — {date_label}]\n\n"
                f"{key_points}"
            )

            # intentionally single chunk (no split)
            _upsert_docs(
                chunks=[kp_text],
                horse_id=horse_id,
                memory_type="daily_summary",   # same memory type
                source=kp_source,
                embeddings=embeddings,
                timestamp=ts,
                importance=2.2,
                extra_meta={
                    **common_meta,
                    "chunk_role": "key_points"
                },
            )
 
def _get_db_connection():
    return mysql.connector.connect(
        host=os.getenv("DB_HOST_NAME"),
        port=int(os.getenv("DB_PORT", 3306)),
        user=os.getenv("DB_USER"),
        password=os.getenv("DB_PASSWORD"),
        database=os.getenv("DB_NAME"),
    )
    
 
def get_horse_daily_summary(horse_id: Any) -> list:
    conn = _get_db_connection(); cursor = conn.cursor(dictionary=True)
    cursor.execute(
        "SELECT id, video_url, video_title, created_at, updated_at, memory_summary, mapped_summary,summary_key_points, horse_id"
        " FROM exceedequine_ai_education_video"
        " WHERE horse_id = %s ORDER BY created_at DESC",
        (horse_id,),
    )
    rows = cursor.fetchall(); cursor.close(); conn.close(); return rows

 
def check_qdrant_available(horse_id: Any) -> bool:
    try:
        count = _get_client().count(
            collection_name=COLLECTION,
            count_filter=Filter(must=[
                FieldCondition(key="horse_id", match=MatchValue(value=str(horse_id)))
            ]),
            exact=False,
        ).count
        logger.info(f"[QDRANT] Points for horse '{horse_id}': {count}")
        return count > 0
    except Exception as exc:
        logger.error(f"[QDRANT] Check failed: {exc}"); return False
 
 
def cleanup_old_memories(horse_id: Any, days: int = 30) -> None:
    cutoff = datetime.now(timezone.utc).timestamp() - (days * 86_400)
    _get_client().delete(
        collection_name=COLLECTION,
        points_selector=Filter(must=[
            FieldCondition(key="horse_id",  match=MatchValue(value=str(horse_id))),
            FieldCondition(key="timestamp", range=Range(lt=cutoff)),
        ]),
    )
    logger.info(f"[CLEANUP] Deleted memories older than {days} days | horse={horse_id}")
 
 
 
 