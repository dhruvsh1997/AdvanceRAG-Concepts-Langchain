import os
from openai import OpenAI
import random
import boto3
import json
import pdfplumber
from io import BytesIO
import requests
from django.utils.timezone import now, timedelta
from .models import WeatherData
from .message import WEATHER_API_FAILURE, INVALID_API_RESPONSE, NETWORK_ERROR, UNEXPECTED_ERROR
import yaml
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI 
# from .chat_memory import index_json_memories       
from .memory_integration import index_general_knowledge,index_json_memories
from langchain_openai import OpenAIEmbeddings
from django.conf import settings
 
from docx import Document
from .prompt import (generate_horse_facts_qa_prompt,
                    modify_paraphrase_prompt,
                    modify_paraphrase_for_day_prompt,
                    horse_latest_racing_record_prompt,
                    responses,
                    racing_record_explaination_prompt,
                    fastest_race_prompt,fastest_winning_race_prompt,
                    life_record_total_earning_prompt,
                    dynamic_question_fromracing_record_prompt)
from datetime import datetime
import random
from dotenv import load_dotenv
load_dotenv()
current_year = datetime.now().year

open_ai_client = OpenAI(api_key=os.environ.get("OPEN_API_KEY"))

def generate_horse_facts_qa(file_content):
    """
    Generates a question-and-answer format based on factual information about a horse for storing in a vector database.
    """
    chat_completion = open_ai_client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {
                "role": "system",
                "content": generate_horse_facts_qa_prompt,
            },
            {
                "role": "user",
                "content": f"""
                    Here is the documant for specific horse: {file_content}
                    Transform factual information of this content into a question-and-answer format as described above.
                """,
            },
        ],
    )
    response_content = chat_completion.choices[0].message.content
    return response_content

def modify_paraphrase():
    """Generating dynamic responses after the 6th to 9th chat messages."""
    chat_completion = open_ai_client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {
                "role": "system",
                "content": modify_paraphrase_prompt,
            }
        ],
    )
    response_content = chat_completion.choices[0].message.content
    return response_content

def modify_paraphrase_for_day():
    """Generating dynamic responses after the 9 message every time after 9th message till 24 hour"""
    chat_completion = open_ai_client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {
                "role": "system",
                "content": modify_paraphrase_for_day_prompt,
            }
        ],
    )
    response_content = chat_completion.choices[0].message.content
    return response_content

def horse_latest_racing_record(horse_data):
    """Generating the dynamic record of the horse for the latest race."""
    chat_completion = open_ai_client.chat.completions.create(
    model="gpt-4o",
    messages=[
        {
            "role": "system",
            "content": horse_latest_racing_record_prompt,
        },
        {
            "role": "user",
            "content": f"""
            Explain the horse racing record data with a focus on dates
                explain each row which contains racing records:
                provide details of first row of racing record and every row document.
            here is the horse racing record data : {horse_data}
                manly focus on the date month and year.
                provide the deails of the first row of the provided data
                And mention on the top of that document that this is the latest race done by the Me.
                also add some of the details that will mention in the top of this first row with seperate heading **Primary details about Me**
                First row will be mension with heading **My Latest Race Record / Latest Race Done by Me / Latest Completed Race**
                Response Format:
                    **Primary details about Me:**
                        - My Color:
                        - My Last Trainer:
                        - My Total Earnings:
                        - Career Race Record of Myself:
                        - Yearling Sales Price:
                    **My Latest Race Record / Latest Race Done by Me / Latest Completed Race**
                        - Race Date:
                        - Race Class:
                            - Track:
                            - Post Position:
                            - 1/4 Mile Position:
                            - 1/2 Mile Position:
                            - 3/4 Mile Position:
                            - Stretch Position:
                            - Final Position
                            - Driver:
                            - Final Time:
                            - Final Quarter Time:
                            - Driver:
                            - Race Purse:
                    About My Latest Race / Summary of My Latest Race:
                    The latest race was held at (Track Name) on (Race Date). I started from post position (Post Position) and was in (1/4 Mile Position) at the 1/4 mile mark, (1/2 Mile Position) at the 1/2 mile mark, and (3/4 Mile Position) at the 3/4 mile mark. As the race progressed, I reached (Stretch Position) before finishing in (Final Position). I was driven by (Driver Name) and completed the race in (Final Time), with a final quarter time of (Final Quarter Time). The total race purse for this event was (Race Purse).
            """,
        },
    ],
    )
    response_content = chat_completion.choices[0].message.content
    return response_content

def racing_record_explaination(horse_data):
    """Generating the dynamic record of the horse for each racing record and explain each record for store in vector db"""
    chat_completion = open_ai_client.chat.completions.create(
    model="gpt-4o",
    messages=[
        {
            "role": "system",
            "content": racing_record_explaination_prompt,
        },
        {
            "role": "user",
            "content": f"""
            Analyze the horse racing record data and provide detailed insights for each row.
            The dataset {horse_data} contains multiple records of a horse's race performance on different dates. Each row represents a specific race, including details such as race class, date, track, post position, race segment positions, final position, final time, Quarter time and the driver's name.
            For each row, generate an output in the following format:

            Response Format:
            Details of race class (Race Class Name) on (Race Date) at (Track Name)
                -Race Date: (Date of the race)
                -Race Class: (Race class name)
                    -Track: (Track name)
                    -Post Position: (Starting position)
                    -1/4 Mile Position: (Rank)(Position at 1/4 mile)
                    -1/2 Mile Position: (Rank) (Position at 1/2 mile)
                    -3/4 Mile Position: (Rank) (Position at 3/4 mile)
                    -Stretch Position: (Rank) (Position in the stretch)
                    -Final Position: (Final placement)
                    -Driver: (Driver's name)
                    -Final Time: (Total race time)
                    -Final Quarter Time: (Time for the last quarter mile)
                    -Race Purse: (Total prize money for the race)
            Race Summary for date (Race Date):
            On (Race Date), the race (Race Class Name) took place at (Track Name). The horse started in post position (Post Position) and was at position (1/4 Mile Position) at the 1/4 mile mark, (1/2 Mile Position) at the 1/2 mile mark, and (3/4 Mile Position) at the 3/4 mile mark. As the race progressed, the horse was in (Stretch Position) before finishing in (Final Position). The race was driven by (Driver's Name), completing the race in (Final Time), with a final quarter time of (Final Quarter Time). The total race purse was (Race Purse).
            Ensure that each race record is properly analyzed and formatted without generic headings like "Row 1," "Row 2," etc. Instead, use descriptive headings based on the race class, date, and track.
            """,
        },
    ],
    )
    response_content = chat_completion.choices[0].message.content
    return response_content

def life_record_total_earning(data):
    """function that determing the lowest time or fastest race from all the records"""
    chat_completion = open_ai_client.chat.completions.create(
    model="gpt-4o",
    messages=[
        {
            "role": "system",
            "content": life_record_total_earning_prompt,
        },
        {
            "role": "user",
            "content": f"""
            Horse racing record data: {data}
            current_year : {current_year}

            """,
        },
    ],
    )
    response_content = chat_completion.choices[0].message.content
    return response_content


def formatted_racing_record(horse_data):
    """Function that calles the horse_latest_racing_record and racing_record_explaination to cobine the data for store in vector db"""
    max_length = 1000
    substrings = []
    start = 0
    while start < len(horse_data):
        end = min(start + max_length, len(horse_data))
        if end < len(horse_data) and horse_data[end] != "\n":
            newline_pos = horse_data.rfind("\n", start, end)
            if newline_pos != -1:
                end = newline_pos

        substrings.append(horse_data[start:end].strip())
        start = end + 1
    data = ""
    for index, string in enumerate(substrings):
        if index == 0:
            data += "\n" + life_record_total_earning(string[:510]) + "\n" + "\n"
            data += "\n" + horse_latest_racing_record(string[:510]) + "\n" + "\n"
        data += "\n" + racing_record_explaination(string)
    return data


def get_random_response():
    """Find the randon response from responses"""
    return random.choice(responses)


def dynamic_question_fromracing_record(data):
    """Create dynamic racing quetions and its answer from racing records"""
    chat_completion = open_ai_client.chat.completions.create(
    model="gpt-4o",
    messages=[
        {
            "role": "system",
            "content": dynamic_question_fromracing_record_prompt,
        },
        {
            "role": "user",
            "content": f"""
            Horse racing record data: {data}

            """,
        },
    ],
    )
    response_content = chat_completion.choices[0].message.content
    return response_content



def fastest_race(data):
    """function that determing the lowest time or fastest race from all the records"""
    chat_completion = open_ai_client.chat.completions.create(
    model="gpt-4o",
    messages=[
        {
            "role": "system",
            "content": fastest_race_prompt,
        },
        {
            "role": "user",
            "content": f"""
            Horse racing record data: {data}

            """,
        },
    ],
    )
    response_content = chat_completion.choices[0].message.content
    return response_content

def fastest_winning_race(data):
    """Function to determine the fastest winning race based on the lowest final time."""
    chat_completion = open_ai_client.chat.completions.create(
        model="o3-mini",
        messages=[
            {
                "role": "system",
                "content": fastest_winning_race_prompt,
            },
            {
                "role": "user",
                "content": f"""
                Here is the horse racing record data: {data}

                Identify and extract the fastest winning race record based on the lowest final time among all 1st-place finishes. Format the response as specified.
                """,
            },
        ],
    )
    return chat_completion.choices[0].message.content


# def handle_file_processing(s3_client, s3_bucket_name, file_keys, horse_id,horse_name=None):
#     """
#     Handle file processing and text extraction for multiple files.
#     """
#     combined_text = ""
#     try:
#         for file_key in file_keys:
#             txt_key = (
#                 file_key.replace(".pdf", ".txt")
#                 .replace(".docx", ".txt")
#                 .replace(f"horse_documents/{horse_id}/", f"horse_documents/{horse_id}/text_file/")
#             )
#             obj = s3_client.get_object(Bucket=s3_bucket_name, Key=file_key)
#             file_bytes = BytesIO(obj['Body'].read())

#             if file_key.endswith(".pdf"):
#                 with pdfplumber.open(file_bytes) as pdf:
#                     file_text = "\n".join([page.extract_text() or "" for page in pdf.pages])
#             elif file_key.endswith(".docx"):
#                 document = Document(file_bytes)
#                 file_text = "\n".join([paragraph.text for paragraph in document.paragraphs])
#             else:
#                 raise ValueError(f"Unsupported file format for {file_key}")
#             s3_client.put_object(
#                 Bucket=s3_bucket_name,
#                 Key=txt_key,
#                 Body=file_text.encode('utf-8'),
#                 ContentType="text/plain",
#             )
#             if "horse_data" in file_key and "harness_freehorse_data" not in file_key:
#                 summarize_text = generate_horse_facts_qa(file_text)
#                 combined_text += summarize_text + "\n"
#             combined_text += file_text + "\n"
#             if "racing_record.pdf" in file_key:
#                 racing_data_record = formatted_racing_record(file_text) + "\n"
#                 combined_text += racing_data_record + "\n"
#                 dynamic_question = dynamic_question_fromracing_record(racing_data_record)
#                 fastest_race_race = fastest_race(racing_data_record)
#                 fastest_winning_race_race = fastest_winning_race(racing_data_record)
#                 combined_text += fastest_race_race + "\n" + fastest_winning_race_race + "\n"+ dynamic_question + "\n"
                
#         open_ai_client   = OpenAI()                   
#         embeddings_inst  = OpenAIEmbeddings(model="text-embedding-ada-002")
#         faiss_index_path = os.path.join(settings.MEDIA_ROOT, "faiss_index", horse_id)
 
#         index_json_memories(
#             open_ai_client   = open_ai_client,
#             embeddings       = embeddings_inst,
#             horse_id         = horse_id,
#             horse_name       = horse_name,
#             faiss_index_path = faiss_index_path,
#             base_dir         = settings.BASE_DIR,
#         )
#         return combined_text.strip()
#     except Exception as file_error:
#         raise ValueError(f"Error processing files: {str(file_error)}")
    
def handle_file_processing(s3_client, s3_bucket_name, file_keys, horse_id, horse_name=None):
    """
    Handle file processing and text extraction for multiple files.
    """
    combined_text = ""
    try:
        for file_key in file_keys:
            txt_key = (
                file_key.replace(".pdf", ".txt")
                .replace(".docx", ".txt")
                .replace(f"horse_documents/{horse_id}/", f"horse_documents/{horse_id}/text_file/")
            )
            obj = s3_client.get_object(Bucket=s3_bucket_name, Key=file_key)
            file_bytes = BytesIO(obj['Body'].read())
 
            if file_key.endswith(".pdf"):
                with pdfplumber.open(file_bytes) as pdf:
                    file_text = "\n".join([page.extract_text() or "" for page in pdf.pages])
            elif file_key.endswith(".docx"):
                document = Document(file_bytes)
                file_text = "\n".join([paragraph.text for paragraph in document.paragraphs])
            else:
                raise ValueError(f"Unsupported file format for {file_key}")
 
            s3_client.put_object(
                Bucket=s3_bucket_name,
                Key=txt_key,
                Body=file_text.encode('utf-8'),
                ContentType="text/plain",
            )
 
            if "horse_data" in file_key and "harness_freehorse_data" not in file_key:
                summarize_text = generate_horse_facts_qa(file_text)
                combined_text += summarize_text + "\n"
 
            combined_text += file_text + "\n"
 
            if "racing_record.pdf" in file_key:
                racing_data_record = formatted_racing_record(file_text) + "\n"
                combined_text += racing_data_record + "\n"
                dynamic_question = dynamic_question_fromracing_record(racing_data_record)
                fastest_race_race = fastest_race(racing_data_record)
                fastest_winning_race_race = fastest_winning_race(racing_data_record)
                combined_text += (
                    fastest_race_race + "\n"
                    + fastest_winning_race_race + "\n"
                    + dynamic_question + "\n"
                )
 
        open_ai_client  = OpenAI()
        embeddings_inst = OpenAIEmbeddings(model="text-embedding-ada-002")
 
        # ── CHANGE 1 ──────────────────────────────────────────────────────────
        # Index the PDF/DOCX combined text into Qdrant as memory_type='general'
        # This replaces the old FAISS.from_texts() / FAISS.save_local() block.
        # The text is chunked and stored under horse_id so retrieve_from_qdrant()
        # can filter it alongside facility/equipment/humans/horses layers.
        index_general_knowledge(
            text       = combined_text.strip(),
            horse_id   = horse_id,
            embeddings = embeddings_inst,
        )
        # ─────────────────────────────────────────────────────────────────────
 
        # ── CHANGE 2 ──────────────────────────────────────────────────────────
        # faiss_index_path is now passed as "" — the Qdrant version ignores it.
        # Everything else in this call is identical to what you had before.
        index_json_memories(
            open_ai_client   = open_ai_client,
            embeddings       = embeddings_inst,
            horse_id         = horse_id,
            horse_name       = horse_name,
            faiss_index_path = "",       
            base_dir         = settings.BASE_DIR,
        )
        # ─────────────────────────────────────────────────────────────────────
 
        return combined_text.strip()
 
    except Exception as file_error:
        raise ValueError(f"Error processing files: {str(file_error)}")
 
# def get_aws_credentials():
#     """Fetch AWS credentials from AWS Secrets Manager."""
#     secret_name = os.environ.get("SECRET_NAME")
#     region_name=os.environ.get("AWS_REGION")
#     session = boto3.session.Session()
#     client = session.client(service_name="secretsmanager", region_name=region_name)
#     response = client.get_secret_value(SecretId=secret_name)
#     secret_data = json.loads(response["SecretString"])
#     return secret_data["access_key"], secret_data["secret_key"]


def get_greeting(user_name):
    """function for get random greeting"""
    greetings = [
        f"Hi {user_name}, how are you today?",
        f"Hey {user_name}, hope you're having a great day!",
        f"Hello {user_name}, how’s everything going?",
        f"Hi {user_name}, nice to see you! How’s your day?",
        f"Hey there, {user_name}! What’s up?",
        f"Hello {user_name}, how’s your day treating you?",
        f"Hi {user_name}, hope you’re doing well today!",
        f"Hey {user_name}, what’s new with you?",
        f"Good to see you, {user_name}! How’s life?",
        f"Hey {user_name}, how’s your day going so far?",
        f"Hello {user_name}, what’s on your mind today?",
        f"Hey {user_name}, anything exciting happening today?",
        f"Hello {user_name}, hope today’s treating you well!",
        f"Hi {user_name}, what have you been up to?",
        f"Hey {user_name}, sending good vibes your way!",
        f"Hello {user_name}, how’s everything with you?",
        f"Hi {user_name}, great to see you again!",
        f"Hey {user_name}, hope your day is going fantastic!",
        f"Hello {user_name}, let’s make today awesome!",
        f"Hi {user_name}, what’s something good that happened today?",
        f"Hey {user_name}, what’s the latest with you?",
        f"Hello {user_name}, hope you're having a wonderful day!",
        f"Hi {user_name}, how’s your mood today?"
    ]
    return random.choice(greetings)



def describe_temperature(temp_kelvin):
    temp_celsius = int(int(temp_kelvin) - 273.15)
    responses = {
        "freezing": [
            "It's freezing cold! Stay warm and safe.",
            "This freezing weather is brutal—bundle up!",
            "Freezing temperatures today, better stay indoors!",
            "The air is freezing, like stepping into an icebox!",
            "So freezing cold that even your breath turns to frost!",
            "Freezing conditions outside—layer up properly!"
        ],
        "very_cold": [
                "It's very cold outside, dress accordingly!",
                "The very cold wind will chill you to the bone!",
                "Stepping outside? It's very cold, so wear extra layers!",
                "A very cold day—gloves and a scarf are a must!",
                "Very cold weather calls for a cozy blanket and hot drink!",
                "This very cold air will have you shivering in seconds!",
                "It's very cold—your breath turns into mist instantly!",
                "A very cold day like this demands thick winter gear!",
                "That very cold breeze feels like ice against your skin!",
                "Brave the very cold weather with a thick coat and boots!",
                "It’s very cold, even my hands are freezing in my pockets!",
                "This very cold morning is best spent under a warm blanket!",
                "Icy winds today—it’s very cold, so layer up!",
                "Your nose will turn red in this very cold air!",
                "The ground is frozen solid—it’s very cold outside!",
                "Very cold weather like this makes you appreciate hot soup!",
                "It's so very cold that even the trees look frozen!",
                "If you step outside, this very cold air will greet you instantly!",
                "Very cold days like this make you want to stay indoors!",
                "The very cold wind is howling—stay warm out there!"
        ],
        "chilly": [
                "It's quite chilly today, better grab a jacket!",
                "This chilly breeze takes a jacket for me and yourself!",
                "A chilly day like this calls for a warm cup.",
                "Chilly weather is perfect for a light sweater!",
                "The air is chilly, but not too harsh.",
                "Chilly temperatures today—stay comfortable!",
                "It's chilly outside—better keep your hands warm!",
                "The chilly wind makes it feel colder than it is!",
                "Feeling chilly? A hoodie or sweater should help!",
                "Chilly air today—perfect weather for a cozy evening.",
                "A slightly chilly day, but still nice for a walk!",
                "The chilly breeze will wake you up instantly!",
                "It’s chilly, but nothing a warm drink can't fix!",
                "A crisp and chilly morning—fresh air at its best!",
                "This chilly weather makes you appreciate a blanket!",
                "Brrr! That chilly breeze is sneaky—wear layers!",
                "Chilly air today, but at least it's not freezing!",
                "A chilly and fresh day—great for a morning jog!",
        ],
        "cool": [
                "It's cool and refreshing outside, enjoy it!",
                "Cool weather like this is perfect for a brisk walk.",
                "Feeling the cool breeze? A light sweater should do.",
                "A cool day with just the right amount of crisp air.",
                "A lovely cool breeze makes this day feel fresh!",
                "It’s a bit cool outside, but nothing too chilly.",
                "Cool temperatures make it ideal for an evening stroll!",
                "A crisp and cool morning—fresh air at its best!",
                "Not too cold, not too warm—just the right balance!",
                "The air is fresh and cool, making everything feel nice.",
                "Nice cool weather today—great for a little workout!",
                "Cool and pleasant outside, no need for heavy layers.",
                "A refreshing cool breeze, making the day feel fresh and light!",
                "This weather is just cool enough to be enjoyable!"
        ],
        "mild": [
                "It's nice outside, perfect for some fresh air!",
                "A nice and pleasant day ahead, enjoy it!",
                "Nice weather today—no need for heavy clothing.",
                "A beautifully nice day, great for outdoor activities!",
                "The weather feels just right—neither too hot nor too cold!",
                "With this nice weather, it's a great day for a stroll.",
                "Such nice weather today—perfect for being outdoors!",
                "It’s a nice day with a gentle breeze, great for a walk!",
                "The sky is clear, and the weather is just nice and cozy!",
                "A day like this, with such nice weather, is meant to be enjoyed!",
                "This nice weather makes everything feel calm and refreshing!",
                "A pleasantly nice day—great for some outdoor relaxation!",
                "With weather this nice, it's hard to stay indoors!",
                "A perfect balance of sunshine and breeze—such nice weather!",
                "A nice and easygoing day, perfect for a light adventure!"
        ],
        "warm": [
            "It's warm and pleasant outside, enjoy the sunshine!",
            "A warm day like this is great for outdoor adventures!",
            "Warm temperatures today—stay hydrated!",
            "Feeling the warm air? Perfect day to step outside!",
            "This warm weather is great for a picnic!",
            "A warm breeze makes the day feel even better."
        ],
        "hot": [
            "It's hot outside, better keep yourself cool!",
            "Hot temperatures today—don't forget your sunscreen!",
            "A hot and sunny day—perfect for a cold drink!",
            "Feeling the hot air? Better find some shade!",
            "This hot weather calls for ice cream!",
            "It's so hot that even the pavement feels warm!"
        ],
        "very_hot": [
            "It's very hot outside, stay in the shade if possible!",
            "A very hot day—stay cool and hydrated!",
            "This very hot weather might make you sweat instantly!",
            "Feeling the very hot air? Better avoid the sun!",
            "A very hot afternoon, perfect for staying indoors with AC!",
            "This very hot day feels like summer at its peak!"
        ],
        "extreme": [
            "It's extremely hot outside, be cautious!",
            "Extreme heat today—avoid staying out for long!",
            "This extreme heat makes everything feel like an oven!",
            "Stepping outside? The extreme heat is no joke!",
            "With this extreme heat, dehydration is a real risk!",
            "Extreme hot weather—find shade and drink lots of water!"
        ]
    }

    if temp_celsius < -10:
        return random.choice(responses["freezing"])
    elif -10 <= temp_celsius <= -2:
        return random.choice(responses["very_cold"])
    elif -1 <= temp_celsius <= 10:
        return random.choice(responses["chilly"])
    elif 11 <= temp_celsius <= 15:
        return random.choice(responses["cool"])
    elif 16 <= temp_celsius <= 23:
        return random.choice(responses["mild"])
    elif 24 <= temp_celsius <= 29:
        return random.choice(responses["warm"])
    elif 30 <= temp_celsius <= 33:
        return random.choice(responses["hot"])
    elif 34 <= temp_celsius <= 36:
        return random.choice(responses["very_hot"])
    else:
        return random.choice(responses["extreme"])


def fetch_weather_data(latitude=39, longitude=-75.5):
    """
    Fetch weather data for the given latitude and longitude.
    If data exists and was updated within the last hour, return it.
    Otherwise, fetch new data from OpenWeatherMap API and update the database.
    Handle API failures gracefully.
    """
    weather_api = os.environ.get("WEATHER_API")
    api_url = f"https://api.openweathermap.org/data/2.5/weather?lat={latitude}&lon={longitude}&appid={weather_api}"
    
    try:
        weather_entry = WeatherData.objects.filter(latitude=latitude, longitude=longitude).order_by('-timestamp').first()
        if weather_entry and (now() - weather_entry.timestamp < timedelta(hours=1)):
            temp_descriptions = describe_temperature(int(weather_entry.temp))
            return {
                "weather_id": weather_entry.weather_id,
                "main": weather_entry.main,
                "description": weather_entry.description,
                "general conversational descriptions of temperature": temp_descriptions,
            }
        
        response = requests.get(api_url)
        if response.status_code != 200:
            return {"error": WEATHER_API_FAILURE, "status_code": response.status_code}
        
        data = response.json()
        if "weather" not in data or "main" not in data:
            return {"error": INVALID_API_RESPONSE}
        
        weather_id = data['weather'][0]['id']
        main = data['weather'][0]['main']
        description = data['weather'][0]['description']
        temp = data['main']['temp']
        humidity = data['main']['humidity']
        latitude = data['coord']['lat']
        longitude = data['coord']['lon']
        
        weather_entry = WeatherData.objects.create(
            weather_id=weather_id,
            main=main,
            description=description,
            temp=temp,
            humidity=humidity,
            latitude=latitude,
            longitude=longitude,
            timestamp=now()
        )
        temp_descriptions = describe_temperature(temp)
        return {
            "weather_id": weather_entry.weather_id,
            "main": weather_entry.main,
            "description": weather_entry.description,
            "general conversational descriptions of temperature": temp_descriptions,
        }
    
    except requests.exceptions.RequestException as e:
        return {"error": NETWORK_ERROR}
    except Exception as e:
        return {"error": UNEXPECTED_ERROR}


###################################

def get_horse_info_from_yaml( horse_id):

    current_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(current_dir, "horse_personality.yaml")
    with open(file_path, "r", encoding="utf-8") as f:
        horses = yaml.safe_load(f)
    for horse in horses:
        if horse.get('horse_id') == horse_id:
            # Extract only the required fields
            return {
                "name": horse.get("name"),
                "personality": horse.get("personality"),
                "character": horse.get("character"),
                "response_behavior": horse.get("response_behavior")
            }
    return {"error": f"Horse with ID '{horse_id}' not found."}

def process_payload(payload):
    user_data = payload.get("user", {})
    horse_id = user_data.get("horse_id")
    if horse_id:
        return get_horse_info_from_yaml(horse_id)
    else:
        return {"error": "No horse_id found in payload."}

def StructureJsonPrompt(payload):
    current_dir = os.path.dirname(os.path.abspath(__file__))
    file_path_message_rules = os.path.join(current_dir, "message_rules.yaml")
    with open(file_path_message_rules, "r", encoding="utf-8") as f:
        rules = yaml.safe_load(f)
    file_path_message_req = os.path.join(current_dir, "message_requirements.yaml") 
    with open(file_path_message_req, "r", encoding="utf-8") as file:
        requirements = yaml.safe_load(file)

    horse_profile = process_payload(payload)

    prompt = f"""
    <message_rules : 
    {rules["message_rules"]["description"],
    rules["message_rules"]["requirements"],
    rules["message_rules"]["tone_guidelines"]}/>

    ### Backend payload Input (USER): {payload}
    ### Horse Profile: {horse_profile}

    <message_requirements:
    {requirements["message_requirements"]["description"],
    requirements["message_requirements"]["content_structure"]}>

    ### Goal:
    Build emotional connection, encourage discovery, drive return visits.
    {requirements["message_requirements"]["content_structure"][7]["Demographic_tone"]}
    Keep the tone casual and friendly. Sound human, not formal. Avoid spammy or scam-like phrasing.

    Return the output in JSON format:
    {{ "subject": "...", "body": "..." }}
    """
    return prompt

def EmailAI(magento_payload):
    prompt_build = StructureJsonPrompt(magento_payload)
    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", """You are an AI writing as a horse on FreeRaceHorse.com.
            Write a **warm, story-like, emotionally engaging message** to a new user."""), 
            ("human", "{input}")
        ]
    )
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.7)
    formatted_prompt = prompt.invoke({"input": f"{prompt_build}"})
    response = llm.invoke(formatted_prompt)
    return response.content