from django.db import models
import uuid
from django.utils.timezone import now

class UserChatHistorySession(models.Model):
    session_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    user_id = models.IntegerField()
    history = models.JSONField(default=list, blank=True, null=True)
    timestamp = models.DateTimeField(default=now)
    is_restriction = models.BooleanField(default=False)
    horse_id = models.CharField(max_length=100)
    is_partial_restriction = models.BooleanField(default=False)


    def __str__(self):
        return f"{self.user_id} - {self.session_id}"


class SessionChatbot(models.Model):
    session_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    history = models.JSONField(default=list, blank=True, null=True)

    def __str__(self):
        return str(self.session_id)


class HorseFileMetadata(models.Model):
    horse_id = models.CharField(max_length=100,unique=True)
    last_modified_file = models.TextField()
    last_modified_fixed_file = models.TextField()
    def __str__(self):
        return f"Horse ID: {self.horse_id}, Last Modified File: {self.last_modified_file}"


class HorseFileMetadataRecord(models.Model):
    horse_id = models.CharField(max_length=100,unique=True)
    horse_data_last_modified = models.TextField()
    prdigree_last_modified = models.TextField()
    racing_record_last_modified = models.TextField()
    harness_data_last_modified = models.TextField()
    frehorse_data_last_modified = models.TextField()

    def __str__(self):
        return str(self.horse_id)



class WeatherData(models.Model):
    weather_id = models.IntegerField()
    main = models.CharField(max_length=100)
    description = models.CharField(max_length=255)
    temp = models.FloatField()
    humidity = models.IntegerField()
    latitude = models.FloatField()
    longitude = models.FloatField()
    timestamp = models.DateTimeField(default=now)

    def __str__(self):
        return f"{self.main} - {self.description} ({self.latitude}, {self.longitude})"


