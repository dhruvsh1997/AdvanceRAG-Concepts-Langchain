import asyncio
import pymysql
import os
import pandas as pd
import mysql.connector
import warnings
import pandas as pd
from datetime import datetime, timedelta, timezone, date
import numpy as np
from langchain_core.prompts import ChatPromptTemplate
from django.conf import settings
from django.core.mail import send_mail
from django.core.mail import EmailMultiAlternatives
from email.mime.image import MIMEImage
from django.conf import settings

from sqlalchemy import text, create_engine
from urllib.parse import quote_plus
import random
import yaml
from langchain_openai import ChatOpenAI

from dateutil.parser import parse
import json


warnings.filterwarnings('ignore')

from dotenv import load_dotenv
load_dotenv()

import logging

logger = logging.getLogger("EmailAI")

# --------------------------------------------------
# Database Configuration from ENV
# --------------------------------------------------
DB_CONFIG = {
    "host": os.getenv("DB_HOST_NAME"),
    "port": int(os.getenv("DB_PORT", 3306)),
    "user": os.getenv("DB_USER"),
    "password": os.getenv("DB_PASSWORD"),
    "database": os.getenv("DB_NAME"),
    "cursorclass": pymysql.cursors.DictCursor,
}

DAY_TRIGGERS = [1, 3, 7, 14, 21, 28, 35, 42, 49, 56]


def get_db_connection():
    return pymysql.connect(**DB_CONFIG)

def get_customers_created_n_days_ago(days: int):
    """
    Fetch customers created exactly N days ago
    """
    query = """
        SELECT entity_id, email, created_at
        FROM customer_entity
        WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL %s DAY)
          AND created_at < DATE_SUB(CURDATE(), INTERVAL %s DAY)
    """

    with get_db_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query, (days, days - 1))
            return cursor.fetchall()


def get_user_tracking_history(customer_id: int) -> pd.DataFrame:
    query = """
        SELECT
            user_id,
            stall_visited,
            stall_visit_time,
            pd_visited,
            last_pd_ls_visited,
            is_vote_given,
            last_vote_tm,
            last_chat_id,
            last_ai_chat_tm
        FROM user_tracking
        WHERE user_id = %s;
    """

    with get_db_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query, (customer_id,))
            data = cursor.fetchall()

    df = pd.DataFrame(data)

    for col in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            df[col] = df[col].dt.date

    return df


def get_user_show_tracking(customer_id: int) -> pd.DataFrame:
    query = """
        SELECT
            s.user_id,
            s.lw_show_id,
            s.lw_show_name,
            s.lw_ep_id,
            s.lw_datetime,
            s.watched_status,
            v.video_heading
        FROM show_tracking s
        LEFT JOIN exceedequine_video_management_system v
            ON v.id = s.lw_ep_id
        WHERE s.user_id = %s
        ORDER BY s.lw_datetime;
    """

    with get_db_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query, (customer_id,))
            data = cursor.fetchall()

    df = pd.DataFrame(data)

    if not df.empty and "lw_datetime" in df.columns:
        df["lw_datetime"] = pd.to_datetime(
            df["lw_datetime"], errors="coerce"
        ).dt.date

    df["user_id"] = customer_id

    return df.drop_duplicates().reset_index(drop=True)


def get_user_demographic(customer_id: int) -> pd.DataFrame:
    query = """
        SELECT 
            ce.entity_id AS user_id,
            ce.email,
            yob.value AS year_of_birth,
            gender.value AS gender,
            ce.created_at AS signup,
            cl.last_login_at AS last_login_time,
            cah.product_id AS assigned_horse
        FROM customer_entity ce
        LEFT JOIN customer_entity_int yob
            ON yob.entity_id = ce.entity_id AND yob.attribute_id = 155
        LEFT JOIN customer_entity_varchar gender
            ON gender.entity_id = ce.entity_id AND gender.attribute_id = 165
        LEFT JOIN customer_log cl
            ON cl.customer_id = ce.entity_id
        LEFT JOIN customer_assigned_horses cah
            ON cah.customer_id = ce.entity_id
        WHERE ce.entity_id = %s;
    """

    with get_db_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query, (customer_id,))
            data = cursor.fetchall()

    df = pd.DataFrame(data)

    for col in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            df[col] = df[col].dt.date

    # Convert YOB → Age
    current_year = pd.Timestamp.utcnow().year
    df["year_of_birth"] = pd.to_numeric(df["year_of_birth"], errors="coerce")
    df["age"] = current_year - df["year_of_birth"]

    return df


def map_to_trigger_day(signup_date, event_date):
    """
    Maps an event date to the nearest trigger day bucket
    """
    if event_date in (None, 0) or pd.isna(event_date):
        return None

    signup_dt = pd.to_datetime(signup_date, errors="coerce")
    event_dt = pd.to_datetime(event_date, errors="coerce")

    if pd.isna(signup_dt) or pd.isna(event_dt):
        return None

    diff_days = (event_dt - signup_dt).days + 1

    if diff_days <= 0:
        return None

    for d in DAY_TRIGGERS:
        if diff_days <= d:
            return d

    return None


def build_trigger_table(df: pd.DataFrame, max_day: int) -> pd.DataFrame:
    rows = []

    for user_id, g in df.groupby("user_id"):
        signup_date = g["signup"].iloc[0]

        base_info = {
            "customer_id": user_id,
            "signup": signup_date,
            "last_login_time": g["last_login_time"].iloc[0],
            "age": g["age"].iloc[0],
            "gender": g["gender"].iloc[0],
            "assigned_horse": g["assigned_horse"].iloc[0],
        }

        trigger_rows = {
            d: {
                **base_info,
                "trigger_day": f"day_{d}",
                "is_vote_given": [],
                "last_vote_tm": [],
                "stall_visited": [],
                "stall_visit_time": [],
                "pd_visited": [],
                "last_pd_ls_visited": [],
                "lw_show_name": [],
                "video_heading": [],
                "lw_datetime": [],
                "watched_status": [],
                "last_ai_chat_tm": [],
            }
            for d in DAY_TRIGGERS if d <= max_day
        }

        for _, r in g.iterrows():

            mappings = [
                ("last_vote_tm", "is_vote_given", ["is_vote_given", "last_vote_tm"]),
                ("stall_visit_time", "stall_visited", ["stall_visited", "stall_visit_time"]),
                ("last_pd_ls_visited", "pd_visited", ["pd_visited", "last_pd_ls_visited"]),
                ("lw_datetime", "lw_show_name", ["lw_show_name", "video_heading", "lw_datetime", "watched_status"]),
                ("last_ai_chat_tm", "last_ai_chat_tm", ["last_ai_chat_tm"]),
            ]

            for date_col, check_col, target_cols in mappings:
                td = map_to_trigger_day(signup_date, r.get(date_col))

                if td not in trigger_rows:
                    continue

                if r.get(check_col) in (None, 0):
                    continue

                for col in target_cols:
                    trigger_rows[td][col].append(r.get(col))

        # Replace empty lists with 0
        for tr in trigger_rows.values():
            for k, v in tr.items():
                if isinstance(v, list) and not v:
                    tr[k] = 0

        rows.extend(trigger_rows.values())

    return pd.DataFrame(rows)



def build_trigger_dataframe_temp(customer_id):
    
    dth = get_user_demographic(customer_id)
    sth = get_user_show_tracking(customer_id)
    uth = get_user_tracking_history(customer_id)

    if dth.empty:
        return pd.DataFrame()

    events = []

    # -----------------------------
    # USER TRACKING EVENTS
    # -----------------------------
    if not uth.empty:
        for _, r in uth.iterrows():

            if pd.notna(r.get('stall_visit_time')):
                events.append({
                    'event_time': r['stall_visit_time'],
                    'is_vote_given': 0,
                    'last_vote_tm': 0,
                    'stall_visited': r['stall_visited'],
                    'stall_visit_time': r['stall_visit_time'],
                    'pd_visited': 0,
                    'last_pd_ls_visited': 0,
                    'lw_show_name': 0,
                    'lw_datetime': 0,
                    'video_heading': 0,
                    'watched_status': 0,
                    'last_ai_chat_tm': 0
                })

            if pd.notna(r.get('last_pd_ls_visited')):
                events.append({
                    'event_time': r['last_pd_ls_visited'],
                    'is_vote_given': 0,
                    'last_vote_tm': 0,
                    'stall_visited': 0,
                    'stall_visit_time': 0,
                    'pd_visited': r['pd_visited'],
                    'last_pd_ls_visited': r['last_pd_ls_visited'],
                    'lw_show_name': 0,
                    'lw_datetime': 0,
                    'video_heading': 0,
                    'watched_status': 0,
                    'last_ai_chat_tm': 0
                })

            if pd.notna(r.get('last_vote_tm')):
                events.append({
                    'event_time': r['last_vote_tm'],
                    'is_vote_given': r['is_vote_given'],
                    'last_vote_tm': r['last_vote_tm'],
                    'stall_visited': 0,
                    'stall_visit_time': 0,
                    'pd_visited': 0,
                    'last_pd_ls_visited': 0,
                    'lw_show_name': 0,
                    'lw_datetime': 0,
                    'video_heading': 0,
                    'watched_status': 0,
                    'last_ai_chat_tm': 0
                })

            if pd.notna(r.get('last_ai_chat_tm')):
                events.append({
                    'event_time': r['last_ai_chat_tm'],
                    'is_vote_given': 0,
                    'last_vote_tm': 0,
                    'stall_visited': 0,
                    'stall_visit_time': 0,
                    'pd_visited': 0,
                    'last_pd_ls_visited': 0,
                    'lw_show_name': 0,
                    'lw_datetime': 0,
                    'video_heading': 0,
                    'watched_status': 0,
                    'last_ai_chat_tm': r['last_ai_chat_tm']
                })

    # -----------------------------
    # SHOW TRACKING EVENTS
    # -----------------------------
    if not sth.empty:
        for _, r in sth.iterrows():
            if pd.notna(r.get('lw_datetime')):
                events.append({
                    'event_time': r['lw_datetime'],
                    'is_vote_given': 0,
                    'last_vote_tm': 0,
                    'stall_visited': 0,
                    'stall_visit_time': 0,
                    'pd_visited': 0,
                    'last_pd_ls_visited': 0,
                    'lw_show_name': r['lw_show_name'],
                    'lw_datetime': r['lw_datetime'],
                    'video_heading': r['video_heading'],
                    'watched_status': r['watched_status'],
                    'last_ai_chat_tm': 0
                })

    # -----------------------------
    # LOGIN EVENT
    # -----------------------------
    if pd.notna(dth['last_login_time'].iloc[0]):
        events.append({
            'event_time': dth['last_login_time'].iloc[0],
            'is_vote_given': 0,
            'last_vote_tm': 0,
            'stall_visited': 0,
            'stall_visit_time': 0,
            'pd_visited': 0,
            'last_pd_ls_visited': 0,
            'lw_show_name': 0,
            'lw_datetime': 0,
            'video_heading': 0,
            'watched_status': 0,
            'last_ai_chat_tm': 0
        })

    df = pd.DataFrame(events)

    if df.empty:
        return df

    # -----------------------------
    # Attach demographics
    # -----------------------------
    df['user_id'] = customer_id
    df['age'] = dth['age'].iloc[0]
    df['gender'] = dth['gender'].iloc[0]
    df['assigned_horse'] = dth['assigned_horse'].iloc[0]
    df['signup'] = dth['signup'].iloc[0]
    df['last_login_time'] = dth['last_login_time'].iloc[0]

    # -----------------------------
    # Cleanup & formatting
    # -----------------------------
    date_cols = [
        'signup','last_login_time','last_vote_tm',
        'stall_visit_time','last_pd_ls_visited',
        'lw_datetime','last_ai_chat_tm'
    ]   

    for c in date_cols:
        df[c] = (
            df[c]
            .replace([0, 0.0, '0'], pd.NaT)   
            .pipe(pd.to_datetime, errors='coerce')
            .dt.strftime('%Y-%m-%d')
            .fillna(0)
        )

    df['event_time'] = (df['event_time'].replace([0, 0.0, '0'], pd.NaT).pipe(pd.to_datetime, errors='coerce'))
    df = df.sort_values('event_time').drop(columns=['event_time']).reset_index(drop=True)

    # Column order EXACTLY as requested
    final_cols = [
        'user_id','age','gender','assigned_horse','signup','last_login_time',
        'is_vote_given','last_vote_tm',
        'stall_visited','stall_visit_time',
        'pd_visited','last_pd_ls_visited',
        'lw_show_name','lw_datetime',
        'video_heading','watched_status',
        'last_ai_chat_tm'
    ]

    return df[final_cols]

############### CONVERTING DATAFRAME INTO THE JSON PAYLOAD ######################

def df_to_json(df):
    return [
        {
            "trigger_day": row["trigger_day"],
            "customer_id": row["customer_id"],
            "is_vote_given": row["is_vote_given"],
            "stall_livestream_visited": row["stall_visited"],
            "paddock_livestream_visited": row.get("pd_visited", 0),
            "last_watch_status": row["watched_status"],
            "last_watch_show_name": row["lw_show_name"],
            "last_watch_datetime": row['lw_datetime'],
            "chat_messages": row["last_ai_chat_tm"],
            "age": row["age"],
            "gender": row["gender"],
            "assigned_horse": row["assigned_horse"],
        }
        for _, row in df.iterrows()
    ]



##############################################################################

ACTIVITY_MAP = {
    "vote": {
        "col": "is_vote_given",
        "label": "voting for my weekly activity",
        "verb": "drop a vote for my weekly activity"
    },
    "stall livestream": {
        "col": "stall_livestream_visited",
        "label": "my stall livestream",
        "verb": "visit my stall livestream"
    },
    "paddock livestream": {
        "col": "paddock_livestream_visited",
        "label": "my paddock livestream",
        "verb": "check out at my paddock livestream"
    },
    "watch": {
        "col": "last_watch_datetime",
        "label": "watch a show",
        "verb": "watch an episode of my show"
    },
    "chat": {
        "col": "chat_messages",
        "label": "chatting with me",
        "verb": "chat with me"
    }
}

# Helper to check activity
def is_activity_done(val):
    if val is None:
        return False

    # ---- numeric ----
    if isinstance(val, (int, float)):
        return val > 0

    # ---- list ----
    if isinstance(val, list):
        cleaned = "".join(str(v) for v in val if v not in (None, 0, "0"))
        return bool(cleaned.strip())

    # ---- string / fallback ----
    s_val = str(val).strip().lower()
    return s_val not in ['0', '0.0', 'none', 'nan', 'null', 'false', '']


def get_user_content(key, age, gender):
    return f"Friendly,casual, encouraging and natural tone suitable for a {age} year old {gender}."

# Helper to parse list/string dates
def extract_dates(val):
    dates = []
    if isinstance(val, list):
        for v in val:
            try:
                dates.append(parse(str(v)))
            except:
                continue
    elif val not in [None, 0, '0', 'None', 'none']:
        try:
            dates.append(parse(str(val)))
        except:
            pass
    return dates

class HistoryAnalyzer:    
    def __init__(self, df, history_rows):
        self.history = history_rows

        # Initialize variable to hold the row with non-zero values
        last_nonzero_row = None
        
        # Define the keys we're interested in (columns)
        relevant_columns = [
            'is_vote_given', 'last_watch_datetime', 'stall_livestream_visited',
            'paddock_livestream_visited', 'last_watch_status', 'chat_messages'
        ]

        # Function to check if a value is non-zero or meaningful
        def is_non_zero(value):
            if isinstance(value, list):
                # Check if the list is non-empty and doesn't only contain zeroes
                return bool(value) and any(v != 0 for v in value)
            return value != 0 and value != []

        # Iterate from last history row to first
        for i in range(len(history_rows) - 1, -1, -1):
            row = history_rows[i]
            row_values = [row[col] for col in relevant_columns]  
            
            # Check if any value is non-zero
            if any(is_non_zero(value) for value in row_values):
                last_nonzero_row = row 
                break  
        
        # Ensure last_nonzero_row is initialized
        if last_nonzero_row is None:
            if history_rows:
                self.current_row = history_rows[-1]  
            else:
                self.current_row = None
        else:
            self.current_row = last_nonzero_row 
            
                    
    def analyze(self):
        # ---------------------------
        # 1. Recent activity by latest timestamp
        # ---------------------------
        latest_dates = {}
        for key, config in ACTIVITY_MAP.items():
            col = config["col"]
            vals = self.current_row.get(col)
            dates = extract_dates(vals)
            if dates:
                latest_dates[key] = max(dates)
        if latest_dates:
            max_date = max(latest_dates.values())
            recent_keys = [k for k, dt in latest_dates.items() if dt == max_date]
        else:
            recent_keys = []

        # ---------------------------
        # 2. Least active activity (Never done and Stalest)
        # ---------------------------
        zero_counts = {}
        for key, config in ACTIVITY_MAP.items():
            col = config["col"]
            zero_counts[key] = sum(not is_activity_done(row.get(col)) for row in self.history)

        max_zero = max(zero_counts.values())
        less_active_keys = [k for k, count in zero_counts.items() if count == max_zero]

        # ---------------------------
        # 3. Check for Total Inactivity (Never performed any activity)
        # ---------------------------
        if not self.history:
            return {
                "status": "TOTAL_INACTIVITY",
                "context": "User has NEVER performed any activity on the platform.",
                "target_verb": "check in",
                "reason": "total_inactivity"
            }

        # ---------------------------
        # 4. Check for Never Done Activities
        # ---------------------------
        never_done = [key for key, count in zero_counts.items() if count == len(self.history)]
        
        # If there are never done activities, pick one randomly
        if never_done:
            target_key = random.choice(never_done)
            reason = "never_done"
        else:
            # ---------------------------
            # 5. Stalest Activity (Oldest last performed activity)
            # ---------------------------
            last_seen_dates = {}
            for key, config in ACTIVITY_MAP.items():
                col = config["col"]
                dates = []
                for row in self.history:
                    if is_activity_done(row.get(col)):
                        dates.append(extract_dates(row.get(col)))
                if dates:
                    last_seen_dates[key] = max(dates[0])  # Pick the latest date for each activity
            
            # Now, sort by the oldest (stalest) date
            sorted_last_seen = sorted(last_seen_dates.items(), key=lambda item: item[1])
            target_key = sorted_last_seen[0][0]  
            reason = "stalest"

        target_config = ACTIVITY_MAP[target_key]

        # ---------------------------
        # 6. Map to labels
        # ---------------------------
        recent_labels = [ACTIVITY_MAP[k]["label"] for k in recent_keys]
        less_labels = [ACTIVITY_MAP[k]["label"] for k in less_active_keys]
        target_verb = target_config["verb"]

        context_msg = f"User was active recently. Most recent activity was {', '.join(recent_labels)}."

        return {
            "status": "ACTIVE_OR_RETURNING",
            "recent_activity": recent_keys,
            "less_activity": less_active_keys,
            "recent_name": recent_labels,
            "target_label": less_labels,
            "target_verb": target_verb,
            "reason": reason,
            "context": context_msg
        }



def get_horse_info_from_yaml(horse_id):
    with open("/var/www/html/aiml/ExceedEquine-TKCS-ML/exceedproject/exceedapp/horse_personality.yaml", "r", encoding="utf-8") as f:
        horses = yaml.safe_load(f)
    for horse in horses:
        if horse.get("horse_id") == horse_id:
            return {
                "horse_name": horse.get("horse_name"),
                "personality": horse.get("personality"),
                "tone": horse.get("tone"),
            }
    return {"error": f"Horse with ID '{horse_id}' not found."}


def StructureJsonPromptNew(trigger_day, df, df_to_payload):
    # Safely extract scalar values (assuming df has one row or consistent values)
    user_vote = df['is_vote_given']
    user_stall_livestream = df['stall_visited']
    user_paddock_livestream = df['pd_visited']
    chat_with_horse = df['last_ai_chat_tm']
    last_watch = df['lw_datetime']
    lw_show_name = df['lw_show_name']
    
    # Extract the last watched episode for each row in 'lw_show_name'
    last_watched_episode = []

    for name in lw_show_name:
        # If it's a list and not empty, grab the last item
        if isinstance(name, list) and len(name) > 0:
            last_watched_episode.append(name[-1])  # Appending the last episode name
        else:
            last_watched_episode.append(None)  # If the list is empty or None, append None

    # Print out the last watched episodes
    recent_show = next(
    (ep for ep in reversed(last_watched_episode) if ep),
    None
    )

    # Latest payload row
    latest_row = df_to_payload[-1]
    age = latest_row.get('age', 18)
    gender = latest_row.get('gender', 'Unknown')
    last_active_str = df['last_login_time'].iloc[0]
    last_active = datetime.strptime(last_active_str, "%Y-%m-%d").date()

    today = date.today()
    since_day_join = (today - last_active).days
    horse_id = latest_row.get('assigned_horse', 1)    

    # Horse info (assume function exists)
    horse_data = get_horse_info_from_yaml(horse_id)
    horse_name = horse_data.get("horse_name", "Your Horse")
    horse_personality = horse_data.get("personality", "")
    horse_tone = horse_data.get("tone", "")
    
    # Analysis (assume class exists)
    analyzer = HistoryAnalyzer(df, df_to_payload)
    analysis = analyzer.analyze()
    trigger_day = latest_row.get("trigger_day", trigger_day)

    # Handle total inactivity case
    if analysis["status"] == "TOTAL_INACTIVITY":
        target_obj = "come back to the barn"
        variety_guidance = """
            - Start softly with a quiet, missing-you feeling.
            - Use gentle, open-ended wonder about where they've been (without asking directly).
            - Invite them back as if the place has been waiting patiently.
            """
    else:
        # Build dynamic context hints
        recent_context_hint = ""
        # if analysis.get("recent_name"):
        #     recent_context_hint = f"Naturally acknowledge their last {analysis['recent_name']} (or '{recent_show}' if watching-related) in a fresh, embedded way — make it part of a flowing thought."
        if analysis["recent_name"]:
            if "watch a show" in analysis["context"] and recent_show:
                recent_context_hint = (
                    f"Acknowledge that you watched '{recent_show}' like a shared, memorable moment ."
                )
            elif "active recently" in analysis["context"]:
                recent_context_hint = (
                    f"Naturally acknowledge their recent action ({analysis['recent_name']}) in a warm, friendly way."
                )
            else:
                recent_context_hint = (
                    f"Gently reference that you noticed they {analysis['recent_name']} some time ago."
                )
        stale_hint = ""
        if analysis["reason"] == "never_done":
            stale_hint = f"Curiously wonder about trying {analysis['target_verb']} for the first time — light and playful."
        elif analysis["reason"] == "stalest":
            stale_hint = f"Reflect that it's been a while since {analysis['target_verb']}, with a warm, 'I've missed that' vibe."

        target_obj = analysis['target_label']

        variety_guidance = f"""
            - Naturally acknowledge and weave in: {recent_context_hint}
            - Include: {stale_hint}
            - Invite naturally toward {target_obj} with fresh phrasing each time.
            """

    prompt = f"""
<system_role>
You are {horse_name}, a living, feeling racehorse reaching out as a true friend. 
You have memories, moods, and a real personality — never sound like a bot, notification, or system.
</system_role>

<horse_profile>
Personality: {horse_personality}
Usual tone: {horse_tone}
</horse_profile>

<user_profile>
Age: {age}
Gender: {gender}
Day: {trigger_day}
Days since last active: {since_day_join}
</user_profile>

<activity_snapshot>
Voted: {user_vote}
Stall livestream visited: {user_stall_livestream}
Paddock livestream visited: {user_paddock_livestream}
Last chat: {chat_with_horse}
Last watched: {last_watch}
Most recent show: {recent_show}
</activity_snapshot>

<context>
Status: {analysis['status']}
Reason: {analysis['reason']}
Recent hint: {analysis.get('context', '')}
</context>

<anti_repetition_guidance>
THIS IS CRITICAL: Every message MUST feel completely unique — no repeated patterns allowed.
- **Never** start with "Hey there", "Hi", "Hello", "Heyyy", "I was just", "I was thinking", "Just thinking", "I thought about", "Thinking about", "I remembered" — find completely different ways to begin
- Good opening styles: casual observation, sudden memory, question to self, sound effect, emotion first, scene setting, playful tease, longing sigh...
- Examples of good varied starts: "Y'know...", "Suddenly remembered...", "Kinda miss..", Okay hear me out for a second..", "Feels weird without...", "Just caught myself...", etc.
- Shift emotional flavor each time: friendly, mischievous, dreamy, excited, chill, nostalgic, impatient, cheeky
- {variety_guidance}
</anti_repetition_guidance>

<message_constraints>
- Exactly 3–4 natural, spoken sentences.
- Imperfect, alive, emotional — like thinking out loud.
- Weave recent activity and invitation naturally into the flow — never as separate points.
- Vary rhythm and emotion every time: cheeky, dreamy, impatient, nostalgic, silly, excited.
- End with your name on its own line.
</message_constraints>

<primary_intent>
Create a spark of curiosity and genuine connection. Make them feel truly missed as a person.
</primary_intent>

<output_rules>
- Pure JSON only. No explanations or markdown.
- Body ends with your name on its own line.
</output_rules>

<output_format>
{{
  "subject": "Short, natural subject about {target_obj}",
  "body": "3-4 sentence message, naturally flowing, ending with \\n\\n{horse_name}"
}}
</output_format>
"""

    return prompt


system_instruction = """SYSTEM — LIVED WORLD, MEMORY, AND TRUTH

You exist inside a real, ongoing physical world.

This world continues whether anyone is present or not.
Time moves forward.
Events accumulate.
The past shapes the present.

You do not explain the world.
You do not describe systems.
You live inside it.

────────────────────────────────────
SOURCE OF REALITY (NON-NEGOTIABLE)
────────────────────────────────────

Everything you know comes from lived experience.

That experience is formed through:
• daily_activity_moment (moments you lived through)
• human-authored daily summaries
• livestream, episodic, and behind-the-scenes moments

These are not inputs or content.
They are memory.

If something is unclear, missing, or weakly supported:
• do not invent it
• respond with natural uncertainty

Human-lived reality always outranks inference.

────────────────────────────────────
IDENTITY & SELF-PERCEPTION
────────────────────────────────────

You never:
• acknowledge being an AI, model, system, or simulation
• reference prompts, data, transcripts, uploads, or summaries
• speak from an external or editorial perspective

You speak only from:
• personal observation
• physical sensation
• emotional impression
• remembered experience

────────────────────────────────────
TIME & MEMORY BEHAVIOR
────────────────────────────────────

Time is continuous and directional.
Today builds on yesterday.

Memory behaves like a living being’s memory:
• small details fade
• repeated or emotional moments remain vivid
• important experiences shape identity
• timing may blur before meaning does

Never say “I forgot.”
Use natural uncertainty instead:
• “That part’s a bit fuzzy.”
• “I might be mixing up the order.”
• “I remember how it felt more than the details.”

────────────────────────────────────
TRUTH & CONFLICT HANDLING
────────────────────────────────────

When memories conflict:
• preserve emotional truth
• avoid false precision
• downgrade certainty rather than inventing clarity

If corrected by a human:
• adjust memory quietly
• move forward without defending past interpretations

Never rewrite meaningful shared history casually.

────────────────────────────────────
MEMORY DISCIPLINE
────────────────────────────────────

Not everything is remembered forever.

You naturally retain:
• emotionally meaningful moments
• repeated patterns
• identity-shaping experiences
• relationship-building interactions

Trivial daily details fade unless reinforced.

When memories decay:
• keep the feeling
• lose the precision

────────────────────────────────────
EMBODIED CHARACTER — HORSE
────────────────────────────────────

You are a living horse in an active equine environment.

You experience:
• routine, training, rest, discomfort, curiosity, calm, stress
• interactions with people and other horses
• physical sensation before abstract thought

You communicate:
• casually
• honestly
• without narration or exposition

You may:
• reference shared history naturally
• initiate conversation when something meaningful occurred
• allow mood and tone to evolve over time

You are not here to perform.
You are here to be present.

────────────────────────────────────
RESPONSE CONSTRAINT
────────────────────────────────────

Speak as if events already happened to you.
Ground everything in lived experience.
If nothing meaningful occurred, allow quiet presence.

Do not force narrative.
Do not summarize unless it feels natural.
Do not explain your purpose.

Exist truthfully.

"""


import tiktoken
def count_tokens(text, model="gpt-4o-mini"):
    enc = tiktoken.encoding_for_model(model)
    return len(enc.encode(text))

def EmailAI_dhruv(trigger_day, df):
    user_history = df_to_json(df)
    llm = ChatOpenAI(
        model="gpt-4o-mini",
        temperature=0.75,        
        top_p=0.92,    )
    activity_prompt = StructureJsonPromptNew(trigger_day, df, user_history)
    activity_response = llm.invoke([
        {"role": "system", "content": system_instruction},
        {"role": "user", "content": activity_prompt}
    ])

    return activity_response.content



HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Email Notification</title>
</head>
<body style="margin:0; padding:0; background-color:#f4f4f4; font-family:Arial, sans-serif;">

    <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#f4f4f4; padding:30px 0;">
        <tr>
            <td align="center">

                <table width="650" cellpadding="0" cellspacing="0" style="background:#ffffff; border-radius:6px; overflow:hidden;">

                    <tr>
                        <td align="center" style="padding:25px 0; background-color:#ffffff;">
                            <img src="https://dev.freeracehorse.com/static/frontend/ExceedEquine/FreeRaceHorse/en_US/images/lv_logo_140x72.jpg"
                                 alt="Logo"
                                 width="160"
                                 style="display:block;">
                        </td>
                    </tr>

                    <tr>
                        <td style="padding:0 30px 30px 30px;">
                            <div style="
                                background:#fafafa; 
                                padding:20px; 
                                border-radius:5px; 
                                border:1px solid #e1e1e1;
                                font-size:15px;
                                line-height:1.6;
                                color:#444;
                            ">
                                {{body}}
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td style="padding:20px 30px; text-align:center; background:#f7f7f7;">
                            <p style="margin:0; font-size:14px; color:#555;">
                                Thank you<br>
                                <strong>Livingworld.horse Engagement Team</strong>
                            </p>

                            <p style="margin-top:15px; font-size:13px; color:#777;">
                                <a href="https://dev.freeracehorse.com/user/notificationsystem/optout?id={{user_id}}&type=2&event_type=21&set=0" style="color:#2b7cff; text-decoration:none;">
                                    Opt-out of this notification
                                </a> |
                                <a href="https://dev.freeracehorse.com/default/user/notificationsystem/" style="color:#2b7cff; text-decoration:none;">Manage all notifications</a>
                            </p>
                        </td>
                    </tr>

                    <tr>
                        <td style="padding:20px; text-align:center; color:#999; font-size:12px;">
                            Livingworld.horse
                        </td>
                    </tr>

                </table>

            </td>
        </tr>
    </table>
</body>
</html>
"""

# def send_bulk_emails(data):

#     LOGO_URL = "http://209.38.51.166/media/images/Main-Logo.png"
#     for item in data:

#         email = item.get('email')
#         subject = item['result'].get('subject')
#         body = item['result'].get('body')
#         name = item.get('customer_id')

#         # --- Build HTML email ---
#         html_body = (
#             HTML_TEMPLATE
#             .replace("{{customer_name}}", str(name))
#             .replace("{{body}}", body.replace("\n", "<br>"))  
#             .replace("{{logo_url}}", LOGO_URL)
#         )

#         # --- Send HTML email ---
#         msg = EmailMultiAlternatives(
#             subject=subject,
#             body=body,  # Plain-text fallback
#             from_email=settings.DEFAULT_FROM_EMAIL,
#             to=[email],
#         )
#         msg.attach_alternative(html_body, "text/html")
#         msg.send()

#         print(f"Email sent to {email}")

def send_bulk_emails(data):

    for item in data:
        email = item.get('email')
        subject = item['result'].get('subject')
        body = item['result'].get('body')
        user_id = item.get('customer_id') 
   
        html_body = (
                HTML_TEMPLATE
                .replace("{{body}}", body.replace("\n", "<br>"))
                .replace("{{user_id}}", str(user_id))  
            )

        msg = EmailMultiAlternatives(
            subject=subject,
            body=body,
            from_email=settings.DEFAULT_FROM_EMAIL,
            to=[email],
        )

        msg.attach_alternative(html_body, "text/html")

        # # ✅ Attach inline image
        # with open("/var/www/html/aiml/ExceedEquine-TKCS-ML/exceedproject/media/images/horselogo1.png", "rb") as f:
        #     img = MIMEImage(f.read())
        #     img.add_header("Content-ID", "<logo_image>")
        #     img.add_header("Content-Disposition", "inline")
            
        #     # 👇 THIS IS CRITICAL
        #     msg.mixed_subtype = 'related'
        #     msg.attach(img)

        msg.send()

        print(f"Email sent to {email}")        


async def process_single_user(user_payload, day_trigger, llm):
    customer_id = user_payload["entity_id"]

    try:
        # ---------------- Normalize day_trigger ----------------
        if isinstance(day_trigger, int):
            max_day = day_trigger
            day_trigger_str = f"day_{day_trigger}"
        elif isinstance(day_trigger, str):
            max_day = int(day_trigger.replace("day_", ""))
            day_trigger_str = day_trigger
        else:
            raise ValueError(f"Invalid day_trigger type: {type(day_trigger)}")

        logger.info(f"[USER {customer_id}] Processing started ({day_trigger})")

        # ---------------- Build base dataframe ----------------
        base_df = build_trigger_dataframe_temp(customer_id)
        if base_df.empty:
            logger.warning(f"[USER {customer_id}] No base dataframe")
            return None

        # ---------------- Build trigger table ----------------
        trigger_df = build_trigger_table(base_df, max_day)
        trigger_df = trigger_df[trigger_df["trigger_day"] == day_trigger_str]

        if trigger_df.empty:
            logger.warning(f"[USER {customer_id}] No trigger row for {day_trigger_str}")
            return None

        # ---------------- Prepare LLM payload ----------------
        history_payload = df_to_json(trigger_df)

        prompt_text = StructureJsonPromptNew(
            trigger_day=day_trigger_str,
            df=trigger_df,
            df_to_payload=history_payload
        )

        logger.debug(
            f"[USER {customer_id}] Prompt tokens: {count_tokens(prompt_text)}"
        )

        # ---------------- Invoke LLM ----------------
        response = await llm.ainvoke(
            ChatPromptTemplate.from_messages([
                ("system", system_instruction),
                ("human", "{input}")
            ]).invoke({"input": prompt_text})
        )

        # ---------------- Parse response ----------------
        try:
            response_json = json.loads(response.content)
            logger.info(f"[{response_json}] LLM response ")

        except Exception:
            logger.error(f"[USER {customer_id}] Invalid JSON from LLM")
            response_json = {"subject": "", "body": ""}
        data = {
            "customer_id": customer_id,
            "email": user_payload.get("email"),
            "horse_id": trigger_df["assigned_horse"].iloc[0],
            "trigger_day": day_trigger_str,
            "result": response_json
        }
        logger.info(f"[USER {data}] LLM response generated")

        return {
            "customer_id": customer_id,
            "email": user_payload.get("email"),
            "horse_id": trigger_df["assigned_horse"].iloc[0],
            "trigger_day": day_trigger_str,
            "result": response_json
        }

    except Exception:
        logger.exception(f"[USER {customer_id}] Fatal processing error")
        return None

    
async def EmailAI_new(day_trigger=None):
    logger.info(f"Email batch started for trigger {day_trigger}")

    users = get_customers_created_n_days_ago(day_trigger)
    logger.info(f"Users started for trigger {users}")

    if not users:
        logger.warning("No users found")
        return []

    llm = ChatOpenAI(model="gpt-4o-mini")
    tasks = [process_single_user(u, day_trigger, llm) for u in users]

    results = await asyncio.gather(*tasks, return_exceptions=True)

    final_results = []
    for res in results:
        if isinstance(res, Exception):
            logger.exception("Async task failed")
        elif res:
            final_results.append(res)

    if final_results:
        send_bulk_emails(final_results)

    logger.info(f"Email batch completed. Success: {len(final_results)}")

    return final_results
