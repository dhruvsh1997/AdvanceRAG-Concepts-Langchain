import os, sys, django

PROJECT_ROOT = "/var/www/html/aiml/ExceedEquine-TKCS-ML/exceedproject"  # ← add /exceedproject
sys.path.insert(0, PROJECT_ROOT)
sys.path.insert(0, "/var/www/html/aiml/ExceedEquine-TKCS-ML")  # ← also add parent
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "exceedproject.settings")
django.setup()

import logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("indexer")

from openai import OpenAI
from langchain_openai import OpenAIEmbeddings
from exceedapp.memory_integration import (
    _load_json_file, _convert_json_to_text, _chunk_text, _upsert_chunks,
    _MEMORY_JSON_FILES, COLLECTION, get_btr_show_summary, get_horse_daily_summary,
)
from exceedapp.qdrant_conn import _get_client
from collections import Counter

MEMORIES_BASE = "/var/www/html/aiml/ExceedEquine-TKCS-ML/exceedproject"

# ── Update this map with correct horse_id → name ────────────────────────────
HORSE_MAP = {
    "2": "Good Deal",
    "3": "Abel de Vie",
    "4": "Ruffian",
    "5": "Minette",
    "6": "Third Pillar",
    "7": "Sweet Flowers",
    "8": "My Special Event",
}

# ── 1. INDEX JSON MEMORIES ───────────────────────────────────────────────────
def index_json(open_ai_client, embeddings, horse_id, horse_name):
    client = _get_client()
    logger.info(f"[JSON] Indexing horse={horse_id} ({horse_name})")

    for section_name, relative_path in _MEMORY_JSON_FILES.items():
        json_data = _load_json_file(MEMORIES_BASE, relative_path)
        if json_data is None:
            continue

        if section_name == "horses":
            horses_list = json_data.get("horses", [])
            matched = [h for h in horses_list
                       if h.get("name", "").lower() == horse_name.lower()]
            json_data = {
                "this_horse": matched[0] if matched else {},
                "stable_mates": [
                    {
                        "name": h["name"],
                        "personality_tags": h.get("personality_tags", []),
                        "behavioral_profile": h.get("behavioral_profile", {}),
                    }
                    for h in horses_list
                    if h.get("name", "").lower() != horse_name.lower()
                ],
            }

        natural_text = _convert_json_to_text(
            open_ai_client=open_ai_client,
            section_name=section_name,
            json_data=json_data,
            horse_name=horse_name,
        )

        _upsert_chunks(
            client=client,
            chunks=_chunk_text(natural_text),
            horse_id=str(horse_id),
            memory_type=section_name,
            source=f"memory_json_{section_name}",
            embeddings_inst=embeddings,
        )
        logger.info(f"  ✓ {section_name} done")


# ── 2. INDEX SHOW SUMMARIES ──────────────────────────────────────────────────
def index_shows(embeddings, horse_id):
    client = _get_client()
    rows = get_btr_show_summary(horse_id)
    logger.info(f"[SHOWS] horse={horse_id} | {len(rows)} rows found")

    for row in rows:
        show_id       = str(row.get("id", ""))
        video_heading = (row.get("video_heading") or "Show Summary").strip()
        memory_summary= (row.get("memory_summary") or "").strip()
        key_points    = (row.get("summary_key_points") or "").strip()

        if not memory_summary:
            continue

        full_text = (
            f"Show: {video_heading}\n\n"
            f"{memory_summary}\n\n"
            f"Key Points:\n{key_points}"
        ).strip()

        _upsert_chunks(
            client=client,
            chunks=_chunk_text(full_text),
            horse_id=str(horse_id),
            memory_type="btr_show_summary",
            source=f"show_{show_id}",
            embeddings_inst=embeddings,
        )
        logger.info(f"  ✓ show_id={show_id} indexed")


# ── 3. INDEX DAILY SUMMARIES ─────────────────────────────────────────────────
def index_daily(embeddings, horse_id):
    client = _get_client()
    rows = get_horse_daily_summary(horse_id)
    logger.info(f"[DAILY] horse={horse_id} | {len(rows)} rows found")

    for row in rows:
        daily_id     = str(row.get("id", ""))
        date_str     = str(row.get("created_at", daily_id))
        summary_text = (row.get("memory_summary") or row.get("summary") or "").strip()

        if not summary_text:
            continue

        _upsert_chunks(
            client=client,
            chunks=_chunk_text(summary_text),
            horse_id=str(horse_id),
            memory_type="daily_summary",
            source=f"daily_{date_str}",
            embeddings_inst=embeddings,
        )
        logger.info(f"  ✓ daily_id={daily_id} indexed")


# ── SUMMARY REPORT ───────────────────────────────────────────────────────────
def print_summary():
    from qdrant_client.models import Filter, FieldCondition, MatchValue
    qclient = _get_client()

    logger.info("\n" + "="*60)
    logger.info("FINAL SUMMARY")
    logger.info("="*60)

    for horse_id, horse_name in HORSE_MAP.items():
        results = qclient.scroll(
            collection_name=COLLECTION,
            scroll_filter=Filter(must=[
                FieldCondition(key="horse_id", match=MatchValue(value=str(horse_id)))
            ]),
            limit=500,
            with_payload=True,
            with_vectors=False,
        )
        counter = Counter(p.payload.get("memory_type") for p in results[0])
        logger.info(f"  horse {horse_id} ({horse_name}): {dict(counter)}")

    logger.info("="*60)


# ── MAIN ─────────────────────────────────────────────────────────────────────
def main():
    if not os.environ.get("OPENAI_API_KEY"):
        print("ERROR: export OPENAI_API_KEY=sk-...")
        sys.exit(1)

    open_ai_client = OpenAI()
    embeddings     = OpenAIEmbeddings(model="text-embedding-ada-002")

    for horse_id, horse_name in HORSE_MAP.items():
        logger.info(f"\n{'='*50}")
        logger.info(f"Processing horse_id={horse_id} | {horse_name}")
        logger.info(f"{'='*50}")
        try:
            index_json(open_ai_client, embeddings, horse_id, horse_name)
        except Exception as e:
            logger.error(f"[JSON] Failed for {horse_name}: {e}")
        try:
            index_shows(embeddings, horse_id)
        except Exception as e:
            logger.error(f"[SHOWS] Failed for {horse_name}: {e}")
        try:
            index_daily(embeddings, horse_id)
        except Exception as e:
            logger.error(f"[DAILY] Failed for {horse_name}: {e}")

    print_summary()


if __name__ == "__main__":
    main()