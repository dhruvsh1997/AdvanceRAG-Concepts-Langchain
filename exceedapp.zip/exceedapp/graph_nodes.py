import hashlib
import logging
from typing_extensions import List, TypedDict

from langgraph.graph import StateGraph, START
from langchain_core.documents import Document

from .chat_integration import QUALITY_THRESHOLD, RERANK_TOP_N, RETRIEVAL_K, build_docs_content, build_expanded_retrieval_chain, build_retrieval_chain, evaluate_answer_quality, fetch_all_daily_chunks_for_date, fetch_most_recent_daily_summary, resolve_query_dates, rewrite_and_classify, run_guardrail
from .graph_helpers import (
    HorseState,
    _run_generate,
    _build_date_hint,
    _openai_error_answer,
    _classify_weather_intent,
    _route_after_guardrail,
    _route_after_evaluate,
    _GENERATE_PROMPT,
    _GENERATE_RETRY_PROMPT,
)


logger = logging.getLogger("ChatbotAPI")


def node_guardrail(state: HorseState) -> dict:
    user_input = state["user_input"]

    # ── REMOVED: old keyword shortcut that was catching past-date weather ─────
    # No more "weather" in user_input.lower() check here.
    # _classify_weather_intent handles ALL weather routing via LLM.

    # ── Step 1: LLM classifies weather intent ─────────────────────────────────
    weather_intent = _classify_weather_intent(user_input, state["llm"])
    logger.info(
        f"[GUARDRAIL] weather_intent={weather_intent} | msg='{user_input[:50]}'"
    )

    if weather_intent["is_weather"]:

        # ── Future weather → off_topic canned response ────────────────────────
        if weather_intent["is_future"]:
            result = run_guardrail(
                user_message=user_input,
                horse_name=state["horse_name"],
                user_name=state["user_name"],
                llm=state["llm"],
            )
            return {
                "guardrail_bucket": "off_topic",
                "canned_response": result["canned_response"],
                "skip_retrieval": True,
                "answer": result["canned_response"],
            }

        # ── Past date → try daily summary first ───────────────────────────────
        if weather_intent["is_past_date"]:
            resolved_dates = resolve_query_dates(user_input)
            past_date = resolved_dates[0] if resolved_dates else None

            if past_date:
                date_str = past_date.strftime("%Y-%m-%d")
                readable = past_date.strftime("%A, %d %B %Y")
                daily_docs = fetch_all_daily_chunks_for_date(
                    horse_id=state["horse_id"],
                    date_str=date_str,
                    embeddings=state["embeddings"],
                )

                if daily_docs:
                    context_text = "\n\n".join(d.page_content for d in daily_docs)

                    from langchain_core.output_parsers import StrOutputParser
                    from langchain_core.prompts import ChatPromptTemplate

                    _past_weather_prompt = ChatPromptTemplate.from_messages(
                        [
                            (
                                "system",
                                (
                                    "You are {horse_name}, a funny horse with a Jim Carrey personality.\n"
                                    "The user is asking about weather on {readable_date}.\n"
                                    "Below is everything logged in the daily summary for that date.\n\n"
                                    "DAILY SUMMARY:\n{context}\n\n"
                                    "If the summary contains any weather-related information "
                                    "(conditions, temperature, rain, sun, wind, how it felt outside, etc.), "
                                    "answer the user's question using only that information.\n"
                                    "If the summary contains NO weather information at all, "
                                    "say honestly and humorously that you have no weather notes for that day.\n"
                                    "Max 2 sentences. Do not use the word 'Whoa'."
                                ),
                            ),
                            ("human", "{user_message}"),
                        ]
                    )
                    try:
                        chain = _past_weather_prompt | state["llm"] | StrOutputParser()
                        answer = chain.invoke(
                            {
                                "horse_name": state["horse_name"],
                                "readable_date": readable,
                                "context": context_text,
                                "user_message": user_input,
                            }
                        )
                        logger.info(
                            f"[GUARDRAIL] past-date weather answered from daily summary | "
                            f"date={date_str} | docs={len(daily_docs)} | horse={state['horse_id']}"
                        )
                        return {
                            "guardrail_bucket": "weather",
                            "canned_response": answer,
                            "skip_retrieval": True,
                            "answer": answer,
                        }
                    except Exception as exc:
                        logger.warning(f"[GUARDRAIL:past-weather] LLM failed ({exc})")

                # No daily docs at all for that date
                try:
                    from langchain_core.output_parsers import StrOutputParser
                    from langchain_core.prompts import ChatPromptTemplate

                    _no_data_prompt = ChatPromptTemplate.from_messages(
                        [
                            (
                                "system",
                                (
                                    "You are {horse_name}, a funny horse with a Jim Carrey personality. "
                                    "Tell the user you have no notes logged for {readable_date} at all. "
                                    "Be funny and in character. Max 1-2 sentences. Do not use 'Whoa'."
                                ),
                            ),
                            ("human", "{user_message}"),
                        ]
                    )
                    chain = _no_data_prompt | state["llm"] | StrOutputParser()
                    answer = chain.invoke(
                        {
                            "horse_name": state["horse_name"],
                            "readable_date": readable,
                            "user_message": user_input,
                        }
                    )
                except Exception:
                    answer = (
                        f"I've got nothing logged for {readable} — "
                        f"I must have been too busy galloping to take notes!"
                    )
                logger.info(
                    f"[GUARDRAIL] past-date weather — no daily docs | "
                    f"date={date_str} | horse={state['horse_id']}"
                )
                return {
                    "guardrail_bucket": "weather",
                    "canned_response": answer,
                    "skip_retrieval": True,
                    "answer": answer,
                }

        # ── Current/today weather → weather API ───────────────────────────────
        from langchain_core.output_parsers import StrOutputParser
        from langchain_core.prompts import ChatPromptTemplate

        _weather_prompt = ChatPromptTemplate.from_messages(
            [
                (
                    "system",
                    (
                        "You are {horse_name}, a funny horse with a Jim Carrey personality. "
                        "The user asked about current weather. Here is today's weather data: {weather_data}\n"
                        "Respond humorously in 1-2 sentences. Do not use the word 'Whoa'."
                    ),
                ),
                ("human", "{user_message}"),
            ]
        )
        try:
            chain = _weather_prompt | state["llm"] | StrOutputParser()
            answer = chain.invoke(
                {
                    "horse_name": state["horse_name"],
                    "weather_data": state["weather_data"],
                    "user_message": user_input,
                }
            )
            logger.info(
                f"[GUARDRAIL] current weather from API | horse={state['horse_id']}"
            )
            return {
                "guardrail_bucket": "weather",
                "canned_response": answer,
                "skip_retrieval": True,
                "answer": answer,
            }
        except Exception as exc:
            logger.warning(f"[GUARDRAIL:weather] LLM failed ({exc}), falling through")
            return {
                "guardrail_bucket": "horse_memory",
                "canned_response": "",
                "skip_retrieval": False,
                "answer": "",
            }

    # ── Not a weather query → normal guardrail classification ─────────────────
    result = run_guardrail(
        user_message=user_input,
        horse_name=state["horse_name"],
        user_name=state["user_name"],
        llm=state["llm"],
    )
    bucket = result["bucket"]
    canned = result["canned_response"]
    skip = result["skip_retrieval"]
    return {
        "guardrail_bucket": bucket,
        "canned_response": canned,
        "skip_retrieval": skip,
        "answer": canned if skip else "",
    }


def node_intent_resolve(state: HorseState) -> dict:
    rci = rewrite_and_classify(state["user_input"], state["llm"])
    logger.info(
        f"[NODE:intent_resolve] intent={rci['intent']} | "
        f"types={rci['memory_types']} | force_daily={rci['force_daily']} | "
        f"resolved_date={rci['resolved_date']} | horse={state['horse_id']}"
    )
    return {
        "rewritten_query": rci["rewritten_query"],
        "intent": rci["intent"],
        "memory_types": rci["memory_types"],
        "force_daily": rci["force_daily"],
        "resolved_date": rci["resolved_date"],
    }
    
def node_retrieve(state: HorseState) -> dict:
    # ── Weather is answered from state["weather_data"], not Qdrant ────────────
    # if state.get("intent") == "weather":
    #     logger.info(f"[NODE:retrieve] intent=weather → skipping Qdrant | horse={state['horse_id']}")
    #     return {"context": []}
    if state.get("intent") == "weather_current":
        logger.info(
            f"[NODE:retrieve] intent=weather_current → skipping Qdrant | horse={state['horse_id']}"
        )
        return {"context": []}

    if not state["qdrant_available"]:
        logger.warning(
            f"[NODE:retrieve] Qdrant unavailable | horse={state['horse_id']}"
        )
        return {"context": []}

    resolved_date = state.get("resolved_date")
    memory_types = state.get("memory_types", [])
    is_daily_q = "daily_summary" in memory_types

    docs: List[Document] = []
    seen: set = set()

    def _merge(new_docs: List[Document], tag: str) -> None:
        added = 0
        for d in new_docs:
            h = hashlib.md5(d.page_content.encode()).hexdigest()
            if h not in seen:
                seen.add(h)
                docs.append(d)
                added += 1
        logger.info(f"[RETRIEVE] {tag} → +{added} (total={len(docs)})")

    all_dates = resolve_query_dates(state["user_input"])
    if len(all_dates) > 1:
        date_list = all_dates
        logger.info(f"[NODE:retrieve] Multi-date query detected: {date_list}")
    elif resolved_date:
        date_list = [resolved_date]
    else:
        date_list = []

    if is_daily_q and date_list:
        for d in date_list:
            date_str = d.strftime("%Y-%m-%d")
            daily_chunks = fetch_all_daily_chunks_for_date(
                horse_id=state["horse_id"],
                date_str=date_str,
                embeddings=state["embeddings"],
            )
            _merge(daily_chunks, f"FULL-DATE-daily({date_str})")

    try:
        chain = build_retrieval_chain(
            horse_id=state["horse_id"],
            embeddings=state["embeddings"],
            llm=state["llm"],
            memory_types=memory_types,
            force_daily=state["force_daily"],
            resolved_date=resolved_date,
            k=RETRIEVAL_K,
            top_n=RERANK_TOP_N,
        )
        semantic_docs: List[Document] = chain.invoke(state["rewritten_query"])
        _merge(semantic_docs, "SEMANTIC-type-filtered")
        # logger.info(f"[NODE:retrieve] Semantic search : {semantic_docs}")

    except Exception as exc:
        logger.error(f"[NODE:retrieve] Semantic search failed: {exc}")

    if not date_list:
        has_daily = any(d.metadata.get("memory_type") == "daily_summary" for d in docs)
        if not has_daily:
            recent = fetch_most_recent_daily_summary(
                horse_id=state["horse_id"],
                embeddings=state["embeddings"],
            )
            _merge(recent, "RECENT-daily-inject")

    logger.info(
        f"[NODE:retrieve] Final: {len(docs)} doc(s) | horse={state['horse_id']} | "
        f"date_list={date_list} | force_daily={state['force_daily']}"
    )
    return {"context": docs}


def node_generate(state: HorseState) -> dict:
    docs_content = build_docs_content(
        context=state["context"],
        resolved_date=state.get("resolved_date"),
        force_daily=state.get("force_daily", False),
    )
    date_hint = _build_date_hint(state.get("resolved_date"))
    try:
        answer = _run_generate(state, docs_content, date_hint, _GENERATE_PROMPT)
        return {"answer": answer}
    except Exception as exc:
        graceful = _openai_error_answer(state, exc)
        if graceful:
            return {"answer": graceful}
        logger.error(f"[NODE:generate] Unexpected: {exc}")
        return {"answer": f"Something went sideways in my brain, {state['user_name']}!"}



def node_evaluate(state: HorseState) -> dict:
    result = evaluate_answer_quality(
        question=state["user_input"],
        answer=state["answer"],
        context=state["context"],  
        llm=state["llm"],
    )

    score = result["score"]
    needs_retry = score < QUALITY_THRESHOLD

    logger.info(
        f"[NODE:evaluate] score={score:.2f} "
        f"| needs_retry={needs_retry} "
        f"| horse={state['horse_id']}"
    )

    return {
        "quality_score": score,
        "quality_reason": result.get("reason", ""),
        "needs_retry": needs_retry,
    }
    
def node_retrieve_expanded(state: HorseState) -> dict:
    logger.info(
        f"[NODE:retrieve_expanded] Expanding | prev_score={state.get('quality_score',0):.2f} | "
        f"reason='{state.get('quality_reason','')[:60]}' | horse={state['horse_id']}"
    )
    try:
        chain = build_expanded_retrieval_chain(
            horse_id=state["horse_id"],
            embeddings=state["embeddings"],
            llm=state["llm"],
            resolved_date=state.get("resolved_date"),
            force_daily=state.get("force_daily", False),
        )
        new_docs: List[Document] = chain.invoke(state["rewritten_query"])

        seen = {
            hashlib.md5(d.page_content.encode()).hexdigest() for d in state["context"]
        }
        added = [
            d
            for d in new_docs
            if hashlib.md5(d.page_content.encode()).hexdigest() not in seen
        ]
        merged = state["context"] + added

        logger.info(
            f"[NODE:retrieve_expanded] +{len(added)} new | total={len(merged)} | "
            f"horse={state['horse_id']}"
        )
        return {"expanded_context": merged}
    except Exception as exc:
        logger.error(f"[NODE:retrieve_expanded] Failed: {exc}")
        return {"expanded_context": state["context"]}

def node_generate_retry(state: HorseState) -> dict:
    expanded_context = state.get("expanded_context") or state["context"]
    docs_content = build_docs_content(
        context=expanded_context,
        resolved_date=state.get("resolved_date"),
        force_daily=state.get("force_daily", False),
    )
    date_hint = _build_date_hint(state.get("resolved_date"))
    logger.info(
        f"[NODE:generate_retry] {len(expanded_context)} doc(s) | horse={state['horse_id']}"
    )
    try:
        answer = _run_generate(state, docs_content, date_hint, _GENERATE_RETRY_PROMPT)
        return {"answer": answer}
    except Exception as exc:
        graceful = _openai_error_answer(state, exc)
        if graceful:
            return {"answer": graceful}
        logger.error(f"[NODE:generate_retry] Unexpected: {exc}")
        return {
            "answer": state.get(
                "answer", f"My brain short-circuited, {state['user_name']}!"
            )
        }


## GRAPH BUILD

def _build_graph():
    builder = StateGraph(HorseState)

    builder.add_node("intent_resolve", node_intent_resolve)
    builder.add_node("retrieve", node_retrieve)
    builder.add_node("generate", node_generate)
    builder.add_node("evaluate", node_evaluate)
    builder.add_node("retrieve_expanded", node_retrieve_expanded)
    builder.add_node("generate_retry", node_generate_retry)

    builder.add_edge(START, "intent_resolve")
    builder.add_edge("intent_resolve", "retrieve")
    builder.add_edge("retrieve", "generate")
    builder.add_edge("generate", "evaluate")

    builder.add_conditional_edges(
        "evaluate",
        _route_after_evaluate,
        {
            "retrieve_expanded": "retrieve_expanded",
            "__end__": "__end__",
        },
    )

    # Retry path terminates after generate_retry
    builder.add_edge("retrieve_expanded", "generate_retry")
    builder.add_edge("generate_retry", "__end__")

    return builder.compile()

GRAPH = _build_graph()