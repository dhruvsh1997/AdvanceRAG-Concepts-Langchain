# email_backend.py
from django.core.mail.backends.smtp import EmailBackend
import smtplib
import ssl

class CustomEmailBackend(EmailBackend):
    def open(self):
        if self.connection:
            return True  # Already open

        try:
            # Create SSL context that skips certificate verification
            context = ssl._create_unverified_context()

            # Connect to SMTP server
            self.connection = smtplib.SMTP(self.host, self.port)

            # Start TLS (secure connection), using unverified context
            self.connection.starttls(context=context)

            # Login
            self.connection.login(self.username, self.password)

            return True

        except (smtplib.SMTPException, ConnectionRefusedError) as e:
            if not self.fail_silently:
                raise
            return False
