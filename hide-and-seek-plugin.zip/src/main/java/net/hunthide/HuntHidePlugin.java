package net.hunthide;

import java.util.*;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.block.Block;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scoreboard.*;

public final class HuntHidePlugin extends JavaPlugin implements Listener, CommandExecutor {
  private enum Phase { LOBBY, STARTING, HIDING, HUNTING, ENDED }
  private Phase phase = Phase.LOBBY;
  private final Set<UUID> hiders = new HashSet<>(), alive = new HashSet<>(), spectators = new HashSet<>();
  private UUID seeker;
  private Location lobby, start;
  private int countdown, phaseSeconds;
  private BukkitTask tick;
  private NamespacedKey itemKey;

  @Override public void onEnable() {
    itemKey = new NamespacedKey(this, "hunt-hide-item");
    getServer().getPluginManager().registerEvents(this, this);
    Objects.requireNonNull(getCommand("set")).setExecutor(this);
    tick = getServer().getScheduler().runTaskTimer(this, this::gameTick, 20L, 20L);
    getLogger().info("HuntHide enabled for Paper 26.2");
  }
  @Override public void onDisable() { if (tick != null) tick.cancel(); }

  private void gameTick() {
    if (phase == Phase.LOBBY) {
      lobbyPlayers();
      int players = Bukkit.getOnlinePlayers().size();
      hud("Waiting for players  " + players + " / 35", ChatColor.GRAY);
      if (players >= 2) { phase = Phase.STARTING; countdown = 60; announce("Match starting in " + countdown + " seconds"); }
    } else if (phase == Phase.STARTING) {
      hud("Match starting in " + countdown + " seconds", ChatColor.YELLOW);
      if (--countdown <= 0) chooseRoles();
    } else if (phase == Phase.HIDING) {
      hud("Hide under  " + phaseSeconds + " seconds", ChatColor.AQUA);
      if (--phaseSeconds <= 0) beginHunt();
    } else if (phase == Phase.HUNTING) {
      hud("Match time  " + format(phaseSeconds), ChatColor.RED);
      if (--phaseSeconds <= 0 || alive.isEmpty()) finish(seeker != null && alive.isEmpty() ? "The seeker wins!" : "The hiders survive!");
    }
  }

  private void chooseRoles() {
    List<Player> players = new ArrayList<>(Bukkit.getOnlinePlayers());
    Collections.shuffle(players); Player chosen = players.get(0); seeker = chosen.getUniqueId();
    hiders.clear(); alive.clear();
    for (Player p : players) { if (!p.getUniqueId().equals(seeker)) { hiders.add(p.getUniqueId()); alive.add(p.getUniqueId()); } resetPlayer(p); }
    announce("Player tag: " + chosen.getName() + " is the SEEKER");
    chosen.sendTitle(ChatColor.RED + "SEEKER", "You hunt the hiders", 10, 60, 10);
    for (UUID id : hiders) player(id).sendTitle(ChatColor.AQUA + "HIDER", "Hide before the hunt begins", 10, 60, 10);
    teleportHiders(); chosen.teleport(lobby != null ? lobby : chosen.getLocation()); giveSeeker(chosen);
    phase = Phase.HIDING; phaseSeconds = 60;
    Bukkit.getScheduler().runTaskLater(this, () -> announce("Hide under 60 seconds"), 100L);
  }

  private void beginHunt() { phase = Phase.HUNTING; phaseSeconds = 8 * 60; if (seeker != null && start != null) player(seeker).teleport(start); announce("The hunt has started!"); }
  private void teleportHiders() { if (start != null) for (UUID id : alive) player(id).teleport(start); }

  private void finish(String message) {
    phase = Phase.ENDED; announce(message); for (Player p : Bukkit.getOnlinePlayers()) { p.setGameMode(GameMode.ADVENTURE); if (lobby != null) p.teleport(lobby); clearEffects(p); giveLobbyBook(p); }
    Bukkit.getScheduler().runTaskLater(this, () -> { phase = Phase.LOBBY; seeker = null; alive.clear(); hiders.clear(); announce("New lobby round ready"); }, 20L * 30);
  }

  @EventHandler public void onJoin(PlayerJoinEvent e) { Player p=e.getPlayer(); p.setGameMode(GameMode.ADVENTURE); if (phase != Phase.LOBBY && phase != Phase.ENDED) { p.setGameMode(GameMode.SPECTATOR); spectators.add(p.getUniqueId()); announce(p.getName()+" joined as a spectator"); } else giveLobbyBook(p); }
  @EventHandler public void onQuit(PlayerQuitEvent e) { UUID id=e.getPlayer().getUniqueId(); if (id.equals(seeker) && (phase == Phase.HIDING || phase == Phase.HUNTING)) finish("The seeker left. Match ended."); hiders.remove(id); alive.remove(id); spectators.remove(id); }
  @EventHandler public void onDeath(PlayerDeathEvent e) { Player p=e.getEntity(); if (alive.remove(p.getUniqueId())) { p.setGameMode(GameMode.SPECTATOR); announce(p.getName()+" was found and is now spectating"); } }
  @EventHandler public void onInteract(PlayerInteractEvent e) {
    ItemStack item=e.getItem(); if (item == null || !item.hasItemMeta()) return; String type=item.getItemMeta().getPersistentDataContainer().get(itemKey, PersistentDataType.STRING); if (type == null) return;
    if (type.equals("troll")) { Player p=e.getPlayer(); p.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 20, 0, false, false)); getServer().getScheduler().runTaskLater(this, () -> p.removePotionEffect(PotionEffectType.GLOWING), 5L); p.setExp(0); }
    if (type.equals("compass") && seeker != null) e.getPlayer().setSpectatorTarget(player(seeker));
    if (type.equals("snowball") && seeker != null && e.getPlayer().getUniqueId().equals(seeker)) { for (Player p:Bukkit.getOnlinePlayers()) p.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 400, 0, false, false)); announce("The seeker revealed all hiders for 20 seconds"); item.setAmount(item.getAmount()-1); }
  }

  private void giveSeeker(Player p) { p.getInventory().clear(); add(p, Material.MACE, 1, "Seeker mace", "mace"); add(p, Material.WIND_CHARGE, 64, "Infinity wind charges", "wind"); add(p, Material.ENDER_PEARL, 16, "Infinity ender pearls", "pearl"); add(p, Material.NETHERITE_SWORD, 1, "One-shot netherite sword", "sword"); add(p, Material.SNOWBALL, 3, "Reveal hiders", "snowball"); add(p, Material.BOW, 1, "Infinity bow", "bow"); add(p, Material.ARROW, 1, "Infinity arrows", "arrow"); }
  private void giveHider(Player p) { p.getInventory().clear(); add(p, Material.ENDER_PEARL, 64, "Ender pearls", "pearl"); add(p, Material.WIND_CHARGE, 64, "Wind charges", "wind"); add(p, Material.STICK, 1, "Knockback X stick (3 hits)", "stick"); add(p, Material.SUGAR, 1, "Troll seeker", "troll"); add(p, Material.COMPASS, 1, "Spectate seeker", "compass"); }
  private void giveLobbyBook(Player p) { if (phase != Phase.LOBBY && phase != Phase.ENDED) return; p.getInventory().clear(); ItemStack book=new ItemStack(Material.WRITTEN_BOOK); ItemMeta m=book.getItemMeta(); m.setDisplayName(ChatColor.GOLD+"HuntHide Leaderboard"); m.setLore(List.of(ChatColor.GRAY+"Hiders leaderboard",ChatColor.GRAY+"Seekers leaderboard")); book.setItemMeta(m); p.getInventory().addItem(book); }
  private void add(Player p, Material mat, int amount, String name, String type) { ItemStack i=new ItemStack(mat, amount); ItemMeta m=i.getItemMeta(); m.setDisplayName(ChatColor.WHITE+name); m.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, type); i.setItemMeta(m); p.getInventory().addItem(i); }
  private void resetPlayer(Player p) { p.setGameMode(GameMode.ADVENTURE); p.getInventory().clear(); clearEffects(p); if (p.getUniqueId().equals(seeker)) giveSeeker(p); else giveHider(p); }
  private void lobbyPlayers() { for (Player p:Bukkit.getOnlinePlayers()) { p.setGameMode(GameMode.ADVENTURE); if (lobby != null && p.getWorld()!=lobby.getWorld()) p.teleport(lobby); giveLobbyBook(p); } }
  private void clearEffects(Player p) { p.removePotionEffect(PotionEffectType.GLOWING); p.setSpectatorTarget(null); }
  private Player player(UUID id) { return Bukkit.getPlayer(id); }
  private void announce(String text) { Bukkit.broadcastMessage(ChatColor.DARK_AQUA+"[HuntHide] "+ChatColor.WHITE+text); for(Player p:Bukkit.getOnlinePlayers()) p.sendTitle(ChatColor.AQUA+"HUNT//HIDE", text, 5, 35, 5); }
  private void hud(String text, ChatColor color) { for(Player p:Bukkit.getOnlinePlayers()) { p.sendActionBar(color+text); p.setLevel(Math.max(0, phaseSeconds)); p.setExp(Math.max(0, Math.min(1, phaseSeconds / 60f))); } }
  private String format(int n) { return String.format("%02d:%02d", n/60, n%60); }

  @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) { if (!(sender instanceof Player p) || args.length != 1 || !sender.hasPermission("hunthide.admin")) return false; if (!args[0].equalsIgnoreCase("lobby") && !args[0].equalsIgnoreCase("start")) return false; if (args[0].equalsIgnoreCase("lobby")) lobby=p.getLocation().clone(); else start=p.getLocation().clone(); p.sendMessage(ChatColor.GREEN+"HuntHide "+args[0]+" location saved."); return true; }
}
