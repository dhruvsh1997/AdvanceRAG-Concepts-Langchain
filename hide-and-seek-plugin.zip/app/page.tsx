'use client'

import { useEffect, useState } from 'react'
import {
  Activity,
  ArrowUpRight,
  BookOpen,
  Box,
  Check,
  ChevronDown,
  CircleDot,
  Clock3,
  Command,
  Crosshair,
  Flag,
  Gamepad2,
  Gem,
  MapPin,
  Menu,
  MoreHorizontal,
  Play,
  Radio,
  RefreshCcw,
  Settings2,
  Shield,
  Skull,
  Sparkles,
  Swords,
  Users,
  Wifi,
  X,
  Zap,
} from 'lucide-react'

const players = [
  { name: 'NovaRider', role: 'Seeker', ping: 42, status: 'Hunting', color: 'seeker' },
  { name: 'PixelMoth', role: 'Hider', ping: 58, status: 'Alive', color: 'hider' },
  { name: 'KaitoZen', role: 'Hider', ping: 64, status: 'Alive', color: 'hider' },
  { name: 'LumaFox', role: 'Hider', ping: 71, status: 'Found', color: 'muted' },
  { name: 'VoidWisp', role: 'Hider', ping: 39, status: 'Alive', color: 'hider' },
  { name: 'CraftyBee', role: 'Spectator', ping: 88, status: 'Watching', color: 'muted' },
]

const events = [
  ['09:42:18', 'Troll seeker activated', 'PixelMoth', 'hider'],
  ['09:41:55', 'Hider found', 'LumaFox', 'seeker'],
  ['09:40:02', 'Match started', 'Round #128', 'system'],
]

export default function Page() {
  const [active, setActive] = useState('Overview')
  const [running, setRunning] = useState(true)
  const [seconds, setSeconds] = useState(6 * 60 + 42)
  const [toast, setToast] = useState('')
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    if (!running) return
    const timer = window.setInterval(() => setSeconds((value) => (value > 0 ? value - 1 : 8 * 60)), 1000)
    return () => window.clearInterval(timer)
  }, [running])

  const notify = (message: string) => {
    setToast(message)
    window.setTimeout(() => setToast(''), 2400)
  }

  const formatTime = (value: number) => `${Math.floor(value / 60).toString().padStart(2, '0')}:${(value % 60).toString().padStart(2, '0')}`

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <div className="brand"><div className="brand-mark"><Crosshair /></div><div><strong>HUNT//HIDE</strong><span>SERVER CONTROL</span></div></div>
        <div className="server-status"><span className="live-dot" /> Live server <span className="server-ip">play.hunthide.net</span></div>
        <nav className="nav-list" aria-label="Main navigation">
          <p className="nav-label">CONTROL ROOM</p>
          {[
            ['Overview', Activity], ['Live match', Radio], ['Players', Users],
          ].map(([label, Icon]) => <button key={label as string} className={`nav-item ${active === label ? 'active' : ''}`} onClick={() => setActive(label as string)}><Icon /><span>{label as string}</span>{label === 'Live match' && <span className="nav-count">6</span>}</button>)}
          <p className="nav-label space-top">SERVER</p>
          {[['Map & spawns', MapPin], ['Game rules', Settings2], ['Leaderboards', Gem]].map(([label, Icon]) => <button key={label as string} className={`nav-item ${active === label ? 'active' : ''}`} onClick={() => setActive(label as string)}><Icon /><span>{label as string}</span></button>)}
        </nav>
        <div className="sidebar-bottom"><div className="version"><span className="version-dot" /> v2.4.1 <span>stable</span></div><button className="profile"><div className="avatar">A</div><div><b>Admin</b><small>Operator</small></div><MoreHorizontal /></button></div>
      </aside>

      <section className="content">
        <header className="topbar"><div className="mobile-brand"><Menu /><b>HUNT//HIDE</b></div><div className="breadcrumbs"><span>Server</span><ChevronDown /><b>{active}</b></div><div className="top-actions"><span className="connection"><Wifi /> Connected</span><button className="icon-button"><Command /></button><button className="icon-button" onClick={() => setMenuOpen(!menuOpen)}><MoreHorizontal /></button></div></header>
        {menuOpen && <div className="quick-menu"><button onClick={() => notify('Server configuration copied')}><RefreshCcw /> Copy config</button><button onClick={() => notify('Console opened')}><TerminalIcon /> Open console</button></div>}

        <div className="page-wrap">
          <div className="page-heading"><div><div className="eyebrow"><span className="pulse" /> ROUND #128 · IN PROGRESS</div><h1>Live match</h1><p>Monitor the hunt and manage your arena in real time.</p></div><div className="heading-actions"><button className="secondary-button" onClick={() => notify('Match settings opened')}><Settings2 /> Match settings</button><button className={`primary-button ${!running ? 'start' : ''}`} onClick={() => { setRunning(!running); notify(running ? 'Match paused' : 'Match resumed') }}>{running ? <><span className="stop-icon" /> End match</> : <><Play /> Start match</>}</button></div></div>

          <div className="stat-grid"><Stat icon={Clock3} label="TIME REMAINING" value={formatTime(seconds)} detail="of 08:00 total" accent="cyan" /><Stat icon={Users} label="PLAYERS" value="6 / 35" detail="5 active · 1 spectator" accent="violet" /><Stat icon={Crosshair} label="HIDERS ALIVE" value="3" detail="of 4 hiders" accent="green" /><Stat icon={Swords} label="CURRENT SEEKER" value="NovaRider" detail="Hunting · 42 ms" accent="red" /></div>

          <div className="main-grid">
            <section className="panel arena-panel"><div className="panel-header"><div><h2>Arena overview</h2><p>world_hunt_03 · Oakwood Ruins</p></div><button className="dots-button"><MoreHorizontal /></button></div><div className="arena-map"><div className="map-grid" /><div className="map-label spawn-label"><span className="map-pin cyan-pin" /> START SPAWN</div><div className="map-label lobby-label"><span className="map-pin red-pin" /> LOBBY</div><div className="player-marker seeker-marker"><Crosshair /><span>NovaRider</span></div><div className="player-marker hider-marker one"><CircleDot /><span>PixelMoth</span></div><div className="player-marker hider-marker two"><CircleDot /><span>VoidWisp</span></div><div className="map-controls"><button onClick={() => notify('Arena coordinates copied')}><ArrowUpRight /> Open map</button><button onClick={() => notify('Spawn editor opened')}><MapPin /> Edit spawns</button></div></div><div className="coordinates"><div><span className="coord-icon cyan"><MapPin /></span><span><b>Start spawn</b><small>−142, 64, 238</small></span></div><div><span className="coord-icon red"><MapPin /></span><span><b>Lobby</b><small>−98, 72, 191</small></span></div><button onClick={() => notify('Run /set command copied')}><Command /> /set commands</button></div></section>

            <section className="panel roster-panel"><div className="panel-header"><div><h2>Player roster</h2><p>Live status and roles</p></div><button className="filter-button">All players <ChevronDown /></button></div><div className="roster-list">{players.map((player) => <div className="player-row" key={player.name}><div className={`player-avatar ${player.color}`}>{player.name.slice(0, 1)}</div><div className="player-name"><b>{player.name}</b><span className={`role ${player.color}`}>{player.role}</span></div><span className={`player-status ${player.status.toLowerCase()}`}><i />{player.status}</span><span className="ping"><Wifi /> {player.ping}</span></div>)}</div><button className="view-all" onClick={() => setActive('Players')}>View all players <ArrowUpRight /></button></section>
          </div>

          <div className="bottom-grid"><section className="panel event-panel"><div className="panel-header"><div><h2>Match activity</h2><p>Events from the last 10 minutes</p></div><button className="dots-button"><MoreHorizontal /></button></div><div className="event-list">{events.map(([time, text, name, type]) => <div className="event-row" key={time}><span className={`event-icon ${type}`}>{type === 'hider' ? <Zap /> : type === 'seeker' ? <Skull /> : <Flag />}</span><span className="event-time">{time}</span><span className="event-text">{text}<b>{name}</b></span></div>)}</div><button className="view-all" onClick={() => notify('Activity log opened')}>Open activity log <ArrowUpRight /></button></section><section className="panel rules-panel"><div className="panel-header"><div><h2>Match rules</h2><p>Current game configuration</p></div><button className="edit-link" onClick={() => setActive('Game rules')}>Edit rules <ArrowUpRight /></button></div><div className="rule-list"><Rule icon={Clock3} label="Match duration" value="08:00" /><Rule icon={Shield} label="Hide time" value="01:00" /><Rule icon={Sparkles} label="Troll seeker" value="3 uses" /><Rule icon={BookOpen} label="Lobby book" value="Enabled" /></div></section></div>
          <footer><span><CircleDot /> Server healthy</span><span>Last sync 12 seconds ago</span><span>© 2024 Hunt//Hide</span></footer>
        </div>
      </section>
      {toast && <div className="toast"><Check /> {toast}</div>}
    </main>
  )
}

function Stat({ icon: Icon, label, value, detail, accent }: { icon: typeof Clock3; label: string; value: string; detail: string; accent: string }) { return <div className={`stat-card ${accent}`}><div className="stat-top"><span>{label}</span><Icon /></div><strong>{value}</strong><small>{detail}</small></div> }
function Rule({ icon: Icon, label, value }: { icon: typeof Clock3; label: string; value: string }) { return <div className="rule-row"><span><Icon /> {label}</span><b>{value}</b></div> }
function TerminalIcon() { return <Box /> }
