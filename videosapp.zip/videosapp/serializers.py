from rest_framework import serializers

class VideoFileSerializer(serializers.Serializer):
    video = serializers.FileField()
    video_name = serializers.CharField(max_length=255, required=False)  
    created_at = serializers.DateTimeField(required=False, read_only=True)
    