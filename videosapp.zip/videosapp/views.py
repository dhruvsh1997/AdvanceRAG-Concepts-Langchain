import json
import logging
import subprocess
import time
import os
import tempfile
import requests
import google.generativeai as genai

from django.conf import settings
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser
from dotenv import load_dotenv

from .models import ShowVideoSummary
from google.api_core.exceptions import ResourceExhausted
 
from .video_utils import (
    generate_transcript_behindTheRace,
    load_memories,
    parallel_compress_and_upload,
    generate_transcript_daily_summary,
    modified_horse_summary_generate,
    mapped_summary_generate_prompt,
    extract_memory_keypoints_from_summary,
    delete_gemini_file,
    upload_video_to_gemini,
)

from .utils import compress_and_upload_video, generate_audio_transcript, generate_horse_summary_merged, generate_transcript_addon, generate_visual_transcript
 

load_dotenv()

logger = logging.getLogger("VideoSummaryAPI")

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
genai.configure(api_key=GEMINI_API_KEY)


# ---------------------------------------------------
# Utility: Compress Video to 360p
# ---------------------------------------------------

def compress_video_360p(input_path):
    if not input_path:
        return None
    output_path = input_path.replace(".mp4", "_480p.mp4")

    command = [
        "ffmpeg",
        "-y",
        "-i", input_path,
        "-vf", "scale=-2:480",
        "-c:v", "libx264",
        "-preset", "veryfast",  
        "-threads", "0",         
        "-crf", "28",
        "-c:a", "aac",
        "-b:a", "96k",
        output_path
    ]
    try:
        logger.info("Starting compression...")
        subprocess.run(command, check=True)
        logger.info(f"Compression done: {output_path}")
        return output_path
    except Exception as e:
        logger.exception("Compression failed")
        raise e


# ---------------------------------------------------
# Base Mixin for Downloading Videos
# ---------------------------------------------------

class VideoDownloadMixin:

    def stream_download_video(self, url):
        logger.info(f"Downloading video from: {url}")

        with requests.get(url, stream=True, timeout=(30, 600)) as r:
            r.raise_for_status()

            with tempfile.NamedTemporaryFile(delete=False, suffix=".mp4") as tmp:
                for chunk in r.iter_content(chunk_size=1024 * 1024):  
                    if chunk:
                        tmp.write(chunk)

                logger.info(f"Download complete: {tmp.name}")
                return tmp.name

class DailySummaryVideoAPI_New(VideoDownloadMixin, APIView):
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    def post(self, request):

        short_video_url = request.data.get("short_video_url")
        short_video_file = request.FILES.get("short_video_file")

        if not any([
            short_video_url,
            short_video_file
        ]):
            return Response(
                {"error": "Provide a short video (url or file)"},
                status=status.HTTP_400_BAD_REQUEST
            )

        start_time = time.time()

        short_temp_path = None
        short_compressed_path = None
        short_video_obj = None

        timings = {}

        try:

            # -------------------------------------------------
            # STEP 1 — Download / Save Video
            # -------------------------------------------------
            t = time.time()

            if short_video_file:

                with tempfile.NamedTemporaryFile(
                    delete=False,
                    suffix=".mp4"
                ) as temp:

                    for chunk in short_video_file.chunks():
                        temp.write(chunk)

                    short_temp_path = temp.name

            elif short_video_url:

                short_temp_path = self.stream_download_video(
                    short_video_url
                )

            timings["video_download"] = round(
                time.time() - t,
                2
            )

            # -------------------------------------------------
            # STEP 2 — Load Memory
            # -------------------------------------------------
            t = time.time()

            (
                facility_memory,
                human_memory,
                equipment_memory,
                horse_memory
            ) = load_memories()

            timings["memory_load"] = round(
                time.time() - t,
                2
            )

            # -------------------------------------------------
            # STEP 3 — Compress + Upload
            # -------------------------------------------------
            t = time.time()

            (
                short_video_obj,
                short_compressed_path
            ) = compress_and_upload_video(
                short_temp_path
            )

            timings["compress_upload"] = round(
                time.time() - t,
                2
            )

            # -------------------------------------------------
            # STEP 4 — Generate Transcripts
            # -------------------------------------------------
            t = time.time()

            short_audio = None
            short_visual = None
            short_transcript = None

            if short_video_obj:

                short_audio = generate_audio_transcript(
                    short_video_obj
                )

                short_visual = generate_visual_transcript(
                    short_video_obj,
                    facility_memory,
                    human_memory,
                    equipment_memory,
                    horse_memory
                )

                short_transcript = generate_transcript_addon(
                    audio_transcript=short_audio,
                    visual_transcript=short_visual
                )

            timings["transcripts"] = round(
                time.time() - t,
                2
            )

            # -------------------------------------------------
            # STEP 5 — Summary Generation
            # -------------------------------------------------
            t = time.time()

            short_summary = None
            summary_key_points = None

            if short_transcript:

                short_summary = (
                    generate_horse_summary_merged(
                        json.dumps(
                            short_transcript,
                            indent=2
                        )
                    )
                )

                summary_key_points = (
                    extract_memory_keypoints_from_summary(
                        short_summary
                    )
                )

            else:

                short_summary = (
                    "No valid video processed."
                )

                summary_key_points = ""

            timings["summary_generation"] = round(
                time.time() - t,
                2
            )

            return Response({

                "status": "success",

                "results": {

                    "short_video_summary":
                        short_summary,

                    "memory_key_points":
                        summary_key_points,

                    "short_transcript":
                        short_transcript,

                },

                "meta": {

                    "processing_time_seconds":
                        round(
                            time.time() - start_time,
                            2
                        ),

                    "timings":
                        timings
                }

            })

        except ResourceExhausted as e:

            logger.error(
                "Gemini quota exhausted."
            )

            return Response(
                {
                    "error":
                        "Gemini API quota exhausted. Please retry later.",

                    "detail":
                        str(e),
                },
                status=status.HTTP_429_TOO_MANY_REQUESTS,
            )

        except Exception as e:

            logger.exception(
                "Processing failed"
            )

            return Response(
                {"error": str(e)},
                status=500
            )

        finally:

            # -------------------------------------------------
            # Cleanup temp files
            # -------------------------------------------------
            for path in [
                short_temp_path
            ]:

                if path and os.path.exists(path):

                    try:
                        os.remove(path)

                    except Exception:

                        logger.warning(
                            f"Could not remove temp file: {path}",
                            exc_info=True
                        )

            # -------------------------------------------------
            # Cleanup compressed files
            # -------------------------------------------------
            for path in [
                short_compressed_path
            ]:

                if path and os.path.exists(path):

                    try:
                        os.remove(path)

                    except Exception:

                        logger.warning(
                            f"Could not remove compressed file: {path}",
                            exc_info=True
                        )

            # -------------------------------------------------
            # Cleanup Gemini uploaded file
            # -------------------------------------------------
            if short_video_obj:

                delete_gemini_file(
                    short_video_obj
                )




class DailySummaryVideoAPI(VideoDownloadMixin, APIView):
    parser_classes = [MultiPartParser, FormParser, JSONParser]
 
    def post(self, request):
 
        short_video_url  = request.data.get("short_video_url")
        long_video_url   = request.data.get("long_video_url")
        short_video_file = request.FILES.get("short_video_file")
        long_video_file  = request.FILES.get("long_video_file")
 
        if not any([short_video_url, short_video_file, long_video_url, long_video_file]):
            return Response(
                {"error": "Provide at least one video (url or file)"},
                status=status.HTTP_400_BAD_REQUEST
            )
 
        start_time = time.time()
 
        short_temp_path      = None
        long_temp_path       = None
        short_compressed_path = None
        long_compressed_path  = None
        short_video_obj      = None
        long_video_obj       = None
 
        timings = {}
 
        try:

            if short_video_file:
                with tempfile.NamedTemporaryFile(delete=False, suffix=".mp4") as temp:
                    for chunk in short_video_file.chunks():
                        temp.write(chunk)
                    short_temp_path = temp.name
 
            elif short_video_url:
                short_temp_path = self.stream_download_video(short_video_url)
 
            if long_video_file:
                with tempfile.NamedTemporaryFile(delete=False, suffix=".mp4") as temp:
                    for chunk in long_video_file.chunks():
                        temp.write(chunk)
                    long_temp_path = temp.name
 
            elif long_video_url:
                long_temp_path = self.stream_download_video(long_video_url)
 

            t = time.time()
            facility_memory, human_memory, equipment_memory, horse_memory = load_memories()
            timings["memory_load"] = round(time.time() - t, 2)
 
            t = time.time()
            (
                short_video_obj,
                short_compressed_path,
                long_video_obj,
                long_compressed_path,
            ) = parallel_compress_and_upload(short_temp_path, long_temp_path)
            timings["compress_upload"] = round(time.time() - t, 2)
 

            t = time.time()
 
            short_transcript = None
            long_transcript  = None
 
            if short_video_obj:
                short_transcript = generate_transcript_daily_summary(
                    short_video_obj,
                    facility_memory,
                    human_memory,
                    equipment_memory,
                    horse_memory,
                )
 
            if long_video_obj:
                long_transcript = generate_transcript_daily_summary(
                    long_video_obj,
                    facility_memory,
                    human_memory,
                    equipment_memory,
                    horse_memory,
                )
 
            timings["transcripts"] = round(time.time() - t, 2)
 
            # ────────────────────────────────────────────
            # STEP 5 — Summary generation
            # ────────────────────────────────────────────
            t = time.time()
 
            short_summary    = None
            mapped_summary   = None
            summary_key_points = None
 
            # -- BOTH videos provided --
            if short_transcript and long_transcript:
 
                short_summary = modified_horse_summary_generate(
                    transcript_text=short_transcript
                )
 
                mapped_summary = mapped_summary_generate_prompt(
                    short_summary=short_summary,
                    long_transcript=long_transcript,
                )
                summary_key_points = extract_memory_keypoints_from_summary(mapped_summary)
 
            # -- Short video only --
            elif short_transcript:
 
                short_summary = modified_horse_summary_generate(
                    transcript_text=short_transcript
                )
                mapped_summary     = short_summary
                summary_key_points = extract_memory_keypoints_from_summary(mapped_summary)
 
            # -- Long video only --
            elif long_transcript:
 
                mapped_summary     = modified_horse_summary_generate(
                    transcript_text=long_transcript
                )
                summary_key_points = extract_memory_keypoints_from_summary(mapped_summary)
 
            else:
                mapped_summary     = "No valid video processed."
                summary_key_points = ""
 
            timings["summary_generation"] = round(time.time() - t, 2)
 
            return Response({
                "status": "success",
 
                "results": {
                    "short_video_summary": short_summary,
                    "mapped_summary":      mapped_summary,
                    "memory_key_points":   summary_key_points,
                },
 
                "meta": {
                    "processing_time_seconds": round(time.time() - start_time, 2)

                }
            })
 
        except ResourceExhausted as e:
            logger.error("Gemini quota exhausted — all retries failed.")
            return Response(
                {
                    "error":  "Gemini API quota exhausted. Please retry later.",
                    "detail": str(e),
                },
                status=status.HTTP_429_TOO_MANY_REQUESTS,
            )
 
        except Exception as e:
            logger.exception("Processing failed")
            return Response({"error": str(e)}, status=500)
 
        finally:
            for path in [short_temp_path, long_temp_path]:
                if path and os.path.exists(path):
                    try:
                        os.remove(path)
                    except Exception:
                        logger.warning(f"Could not remove temp file: {path}", exc_info=True)
 

            for path in [short_compressed_path, long_compressed_path]:
                if path and os.path.exists(path):
                    try:
                        os.remove(path)
                    except Exception:
                        logger.warning(f"Could not remove compressed file: {path}", exc_info=True)
 

            for video_obj in [short_video_obj, long_video_obj]:
                if video_obj:
                    delete_gemini_file(video_obj)
 
 
 
# class DailySummaryVideoAPI_New(VideoDownloadMixin, APIView):
#     parser_classes = [MultiPartParser, FormParser, JSONParser]

#     def post(self, request):

#         short_video_url = request.data.get("short_video_url")
#         long_video_url = request.data.get("long_video_url")

#         short_video_file = request.FILES.get("short_video_file")
#         long_video_file = request.FILES.get("long_video_file")

#         if not any([
#             short_video_url,
#             short_video_file,
#             long_video_url,
#             long_video_file
#         ]):
#             return Response(
#                 {"error": "Provide at least one video (url or file)"},
#                 status=status.HTTP_400_BAD_REQUEST
#             )

#         start_time = time.time()

#         short_temp_path = None
#         long_temp_path = None

#         short_compressed_path = None
#         long_compressed_path = None

#         short_video_obj = None
#         long_video_obj = None

#         timings = {}

#         try:

#             # -------------------------------------------------
#             # STEP 1 — Download / Save Videos
#             # -------------------------------------------------
#             if short_video_file:
#                 with tempfile.NamedTemporaryFile(
#                     delete=False,
#                     suffix=".mp4"
#                 ) as temp:
#                     for chunk in short_video_file.chunks():
#                         temp.write(chunk)
#                     short_temp_path = temp.name

#             elif short_video_url:
#                 short_temp_path = self.stream_download_video(
#                     short_video_url
#                 )

#             if long_video_file:
#                 with tempfile.NamedTemporaryFile(
#                     delete=False,
#                     suffix=".mp4"
#                 ) as temp:
#                     for chunk in long_video_file.chunks():
#                         temp.write(chunk)
#                     long_temp_path = temp.name

#             elif long_video_url:
#                 long_temp_path = self.stream_download_video(
#                     long_video_url
#                 )

#             # -------------------------------------------------
#             # STEP 2 — Load Memory
#             # -------------------------------------------------
#             t = time.time()

#             (
#                 facility_memory,
#                 human_memory,
#                 equipment_memory,
#                 horse_memory
#             ) = load_memories()

#             timings["memory_load"] = round(
#                 time.time() - t, 2
#             )

#             # -------------------------------------------------
#             # STEP 3 — Compress + Upload
#             # -------------------------------------------------
#             t = time.time()

#             (
#                 short_video_obj,
#                 short_compressed_path,
#                 long_video_obj,
#                 long_compressed_path,
#             ) = parallel_compress_and_upload(
#                 short_temp_path,
#                 long_temp_path
#             )

#             timings["compress_upload"] = round(
#                 time.time() - t, 2
#             )

#             # -------------------------------------------------
#             # STEP 4 — Generate Transcripts
#             # -------------------------------------------------
#             t = time.time()

#             short_transcript = None
#             long_transcript = None

#             short_audio = None
#             short_visual = None

#             long_audio = None
#             long_visual = None

#             # ---------- SHORT VIDEO ----------
#             if short_video_obj:

#                 short_audio = generate_audio_transcript(
#                     short_video_obj
#                 )

#                 short_visual = generate_visual_transcript(
#                     short_video_obj,
#                     facility_memory,
#                     human_memory,
#                     equipment_memory,
#                     horse_memory
#                 )

#                 short_transcript = generate_transcript_addon(
#                     audio_transcript=short_audio,
#                     visual_transcript=short_visual
#                 )

#             # ---------- LONG VIDEO ----------
#             # Long video used ONLY for contextual visual evidence
#             if long_video_obj:

#                 long_visual = generate_visual_transcript(
#                     long_video_obj,
#                     facility_memory,
#                     human_memory,
#                     equipment_memory,
#                     horse_memory
#                 )

#                 long_transcript = long_visual

#             timings["transcripts"] = round(
#                 time.time() - t, 2
#             )

#             # -------------------------------------------------
#             # STEP 5 — Summary Generation
#             # -------------------------------------------------
#             t = time.time()

#             short_summary = None
#             mapped_summary = None
#             summary_key_points = None

#             # BOTH VIDEOS
#             if short_transcript and long_transcript:

#                 merged_context = {
#                     "short_video_transcript":
#                         short_transcript,

#                     "long_video_context":
#                         long_transcript
#                 }

#                 short_summary = (
#                     generate_horse_summary_merged(
#                         json.dumps(
#                             merged_context,
#                             indent=2
#                         )
#                     )
#                 )

#                 mapped_summary = short_summary

#                 summary_key_points = (
#                     extract_memory_keypoints_from_summary(
#                         mapped_summary
#                     )
#                 )

#             # SHORT VIDEO ONLY
#             elif short_transcript:

#                 short_summary = (
#                     generate_horse_summary_merged(
#                         json.dumps(
#                             short_transcript,
#                             indent=2
#                         )
#                     )
#                 )

#                 mapped_summary = short_summary

#                 summary_key_points = (
#                     extract_memory_keypoints_from_summary(
#                         mapped_summary
#                     )
#                 )

#             # LONG VIDEO ONLY
#             elif long_transcript:

#                 mapped_summary = (
#                     generate_horse_summary_merged(
#                         json.dumps(
#                             long_transcript,
#                             indent=2
#                         )
#                     )
#                 )

#                 summary_key_points = (
#                     extract_memory_keypoints_from_summary(
#                         mapped_summary
#                     )
#                 )

#             else:
#                 mapped_summary = (
#                     "No valid video processed."
#                 )
#                 summary_key_points = ""

#             timings["summary_generation"] = round(
#                 time.time() - t, 2
#             )

#             return Response({
#                 "status": "success",

#                 "results": {
#                     "short_video_summary":
#                         short_summary,

#                     # "mapped_summary":
#                     #     mapped_summary,

#                     "memory_key_points":
#                         summary_key_points,

#                     "short_visual_transcript":
#                         short_visual,

#                     # "long_visual_transcript":
#                     #     long_visual,
#                 },

#                 "meta": {
#                     "processing_time_seconds":
#                         round(
#                             time.time() - start_time,
#                             2
#                         ),
#                     "timings": timings
#                 }
#             })

#         except ResourceExhausted as e:

#             logger.error(
#                 "Gemini quota exhausted."
#             )

#             return Response(
#                 {
#                     "error":
#                         "Gemini API quota exhausted. Please retry later.",
#                     "detail":
#                         str(e),
#                 },
#                 status=status.HTTP_429_TOO_MANY_REQUESTS,
#             )

#         except Exception as e:

#             logger.exception(
#                 "Processing failed"
#             )

#             return Response(
#                 {"error": str(e)},
#                 status=500
#             )

#         finally:

#             # cleanup temp files
#             for path in [
#                 short_temp_path,
#                 long_temp_path
#             ]:
#                 if path and os.path.exists(path):
#                     try:
#                         os.remove(path)
#                     except Exception:
#                         logger.warning(
#                             f"Could not remove temp file: {path}",
#                             exc_info=True
#                         )

#             # cleanup compressed files
#             for path in [
#                 short_compressed_path,
#                 long_compressed_path
#             ]:
#                 if path and os.path.exists(path):
#                     try:
#                         os.remove(path)
#                     except Exception:
#                         logger.warning(
#                             f"Could not remove compressed file: {path}",
#                             exc_info=True
#                         )

#             # cleanup Gemini uploaded files
#             for video_obj in [
#                 short_video_obj,
#                 long_video_obj
#             ]:
#                 if video_obj:
#                     delete_gemini_file(
#                         video_obj
#                     )