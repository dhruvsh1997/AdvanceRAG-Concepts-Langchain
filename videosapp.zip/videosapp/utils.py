import subprocess
import time
import google.generativeai as genai
import os
import json
import logging
from collections import defaultdict
from google.api_core.exceptions import ResourceExhausted
import re
from django.conf import settings
from dotenv import load_dotenv

load_dotenv()


GEMINI_API_KEY =os.environ.get("GEMINI_API_KEY")
genai.configure(api_key=GEMINI_API_KEY)
MODEL = genai.GenerativeModel("gemini-2.5-flash")

logger = logging.getLogger("VideoSummaryAPI")

_memory_cache = {}


def gemini_call_with_retry(prompt_parts, max_retries=4, base_delay=65):
    """
    Drop-in replacement for MODEL.generate_content() with 429 retry logic.
 
    prompt_parts: list — anything normally passed to generate_content()
                  e.g. [video_file, prompt_str] or just [prompt_str]
 
    On ResourceExhausted (429):
      - Reads the suggested retry delay from the error message.
      - Falls back to base_delay (65s) if no delay is found.
      - Applies 1.5× backoff on each subsequent retry.
      - Re-raises after max_retries exhausted.
 
    On blocked response (no candidates):
      - Retries once with the text prompt trimmed to 15 000 chars.
      - Returns None if still blocked (caller handles gracefully).
    """
    delay = base_delay
 
    for attempt in range(1, max_retries + 1):
        try:
            response = MODEL.generate_content(prompt_parts)
 
            if not response.candidates:
                logger.warning(
                    f"Gemini returned no candidates (attempt {attempt}). "
                    "Retrying with trimmed prompt."
                )
                trimmed = prompt_parts[:-1] + [prompt_parts[-1][:15000]]
                response = MODEL.generate_content(trimmed)
 
                if not response.candidates:
                    logger.error("Trimmed retry also returned no candidates.")
                    return None
 
            return response.candidates[0].content.parts[0].text
 
        except ResourceExhausted as e:
            suggested = _parse_retry_delay(str(e))
            wait = suggested if suggested else delay
 
            logger.warning(
                f"[Attempt {attempt}/{max_retries}] Gemini quota hit. "
                f"Waiting {wait}s before retry..."
            )
 
            if attempt == max_retries:
                logger.error("All retry attempts exhausted.")
                raise
 
            time.sleep(wait)
            delay = int(delay * 1.5)  
 
        except Exception:
            logger.exception("Gemini call failed with non-retryable error.")
            raise
 
    return None
 
 
def load_json(filename):
    file_path = os.path.join(
        settings.BASE_DIR,
        "videosapp",
        "Memories_Data",
        filename
    )
 
    logger.info(f"Attempting to load memory file: {file_path}")
 
    if not os.path.exists(file_path):
        logger.error(f"Memory file NOT FOUND: {file_path}")
        raise FileNotFoundError(f"Memory file not found: {file_path}")
 
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
            logger.info(
                f"Successfully loaded memory file: {filename} "
                f"(size: {len(data) if hasattr(data, '__len__') else 'unknown'})"
            )
            return data
 
    except json.JSONDecodeError:
        logger.exception(f"Invalid JSON format in file: {file_path}")
        raise
 
    except Exception:
        logger.exception(f"Unexpected error loading file: {file_path}")
        raise
 
 
def load_memories():
    """
    Load memory files once per process and cache them.
    All subsequent requests in the same worker reuse the cached copy —
    zero disk I/O after the first call.
    """
    global _memory_cache
 
    if _memory_cache:
        logger.info("Returning memories from in-process cache.")
        return (
            _memory_cache["facility"],
            _memory_cache["human"],
            _memory_cache["equipment"],
            _memory_cache["horse"],
        )
 
    logger.info("Cache empty — loading all memory files from disk...")
 
    try:
        _memory_cache = {
            "facility":  load_json("facility_memory_data.json"),
            "human":     load_json("human_recognition_details.json"),
            "equipment": load_json("equipment_details.json"),
            "horse":     load_json("horse_traits_memory.json"),
        }
        logger.info("All memory files loaded and cached successfully.")
        return (
            _memory_cache["facility"],
            _memory_cache["human"],
            _memory_cache["equipment"],
            _memory_cache["horse"],
        )
 
    except Exception:
        logger.exception("Failed to load one or more memory files.")
        raise
 
 
def invalidate_memory_cache():
    """
    Call this if you update the JSON files and want the next request
    to reload them without restarting the server.
    e.g. expose as a management command or admin action.
    """
    global _memory_cache
    _memory_cache = {}
    logger.info("Memory cache invalidated.")



def _parse_retry_delay(error_message: str) -> int | None:
    """
    Extract the suggested retry-after seconds from Gemini's 429 message.
    Adds a 5-second safety buffer.
    """
    match = re.search(r"retry in (\d+)", str(error_message))
    return int(match.group(1)) + 5 if match else None

 
 
def upload_video_to_gemini(video_path, max_wait=300):
    """Upload a local video file to Gemini and wait until it is ACTIVE."""
    video_file = genai.upload_file(video_path)
    start_time = time.time()
 
    while True:
        video_file = genai.get_file(video_file.name)
 
        if video_file.state.name == "ACTIVE":
            logger.info(f"Gemini video ready: {video_file.name}")
            return video_file
 
        if video_file.state.name == "FAILED":
            raise Exception(f"Gemini video processing failed: {video_file.name}")
 
        if time.time() - start_time > max_wait:
            raise TimeoutError(
                f"Gemini video processing exceeded {max_wait}s timeout: {video_file.name}"
            )
 
        time.sleep(2)
 
 
def delete_gemini_file(video_file):
    """
    OPTIMIZATION 3: Delete uploaded file from Gemini storage after processing.
 
    Uploaded files accumulate in your Gemini project storage and count
    toward your storage quota. Always clean up after each request.
    Safe to call — errors are logged but not re-raised.
    """
    try:
        genai.delete_file(video_file.name)
        logger.info(f"Deleted Gemini file: {video_file.name}")
    except Exception:
        logger.warning(
            f"Could not delete Gemini file: {video_file.name}",
            exc_info=True
        )
        
def compress_video0p(input_path):
    if not input_path:
        return None
    output_path = input_path.replace(".mp4", "_480p.mp4")

    command = [
        "ffmpeg",
        "-y",
        "-i", input_path,
        "-vf", "scale=-2:480",
        "-c:v", "libx264",
        "-preset", "veryfast",  
        "-threads", "0",         
        "-crf", "28",
        "-c:a", "aac",
        "-b:a", "96k",
        output_path
    ]
    try:
        logger.info("Starting compression...")
        subprocess.run(command, check=True)
        logger.info(f"Compression done: {output_path}")
        return output_path
    except Exception as e:
        logger.exception("Compression failed")
        raise e


        
def compress_and_upload_video(video_path):
    """
    Compress a single video and upload it to Gemini.

    Returns:
        uploaded_video_obj,
        compressed_video_path
    """

    if not video_path:
        return None, None

    compressed_path = compress_video(
        video_path
    )

    uploaded_video_obj = upload_video_to_gemini(
        compressed_path
    )

    return (
        uploaded_video_obj,
        compressed_path
    )

def generate_audio_transcript(video_file):
    """
    Generates a detailed transcript focusing on horse activity and trainer cues.
    """
    
    prompt = """
    You are an audio transcription system.

    Your task is to generate ONLY spoken narration
    from the uploaded video.

    STRICT RULES:
    1. Include ONLY spoken words.
    2. Ignore visuals completely.
    3. Ignore horse activity, humans, equipment,
    locations, or actions unless explicitly spoken.
    4. Do NOT infer or hallucinate words.
    5. Preserve exact timestamps.
    6. Maintain chronological order.
    7. Split transcript naturally by narration changes.
    8. If no narration exists during a time period,
       do NOT invent content.
    
    OUTPUT FORMAT STRICTLY:

    [
        {
            "start_timestamp": "00:00:05",
            "end_timestamp": "00:00:12",
            "narration": "spoken narration text"
        }
    ]

    IMPORTANT:
    - Return ONLY valid JSON.
    - No markdown.
    - No ```json wrapper.
    - No explanation text.
    """

    # response = MODEL.generate_content([video_file, prompt])
    response = MODEL.generate_content(
        [video_file, prompt],
        generation_config={
            "temperature": 0.1,
            "top_p": 0.8,
            "response_mime_type": "application/json",  
        }
    )
    return response.text



def generate_visual_transcript(video_file, facility_memory, human_memory, equipment_memory, horse_memory):

    prompt = f"""
You are an advanced multimodal video analyst.

Your task is to generate a STRICT VISUAL TRANSCRIPT
of the uploaded video with accurate timestamps.

IMPORTANT RULES:
--------------------------------------------------

1. ONLY describe VISUAL CONTENT.
2. DO NOT include audio transcript.
3. DO NOT infer emotions, intentions, future actions,
   pain, fear, comfort, or assumptions.
4. ONLY describe what is directly visible.
5. Use the provided memory JSON data to identify:
   - humans
   - horses
   - equipment
   - facility areas

6. If identity is uncertain, say:
   - unidentified human
   - unidentified horse
   - unidentified equipment

7. Explicitly mention timestamps whenever:
   - a known human appears
   - a horse appears
   - equipment becomes visible
   - facility/location changes
   - interactions occur

8. Mention:
   - visible actions
   - movement
   - interactions
   - environment
   - object placement
   - horse activity
   - equipment usage

9. DO NOT hallucinate identities.

10. Generate transcript in chronological order.

==================================================
FACILITY MEMORY
==================================================

{json.dumps(facility_memory, indent=2)}

==================================================
HUMAN MEMORY
==================================================

{json.dumps(human_memory, indent=2)}

==================================================
EQUIPMENT MEMORY
==================================================

{json.dumps(equipment_memory, indent=2)}

==================================================
HORSE MEMORY
==================================================

{json.dumps(horse_memory, indent=2)}

==================================================

OUTPUT FORMAT STRICTLY:

[
  {{
    "start_timestamp": "00:00:05",
    "end_timestamp": "00:00:15",
    "facility": "...",
    "humans": ["..."],
    "horses": ["..."],
    "equipment": ["..."],
    "visual_activity": "...",
    "environment_details": "..."
  }}
]

IMPORTANT:
- Return ONLY valid JSON.
- No markdown.
- No ```json wrapper.
- No explanation text.
"""

    response = MODEL.generate_content(
        [video_file, prompt],
        generation_config={
            "temperature": 0.1,
            "top_p": 0.8,
            "response_mime_type": "application/json", 
        }
    )

    transcript_text = response.text.strip()

    return transcript_text




def time_to_seconds(timestamp):
    h, m, s = map(int, timestamp.split(":"))
    return h * 3600 + m * 60 + s


def overlap(a_start, a_end, b_start, b_end):
    return max(
        0,
        min(a_end, b_end)
        - max(a_start, b_start)
    )

def generate_transcript_addon(
    audio_transcript,
    visual_transcript):

    if isinstance(audio_transcript, str):

        audio_transcript = (
            audio_transcript
            .replace("```json", "")
            .replace("```", "")
            .strip()
        )

        audio_transcript = json.loads(
            audio_transcript
        )

    # Fix visual transcript too
    if isinstance(visual_transcript, str):

        visual_transcript = (
            visual_transcript
            .replace("```json", "")
            .replace("```", "")
            .strip()
        )

        visual_transcript = json.loads(
            visual_transcript
        )

    aligned = []

    for audio in audio_transcript:

        a_start = time_to_seconds(
            audio["start_timestamp"]
        )

        a_end = time_to_seconds(
            audio["end_timestamp"]
        )

        matched_visuals = []

        for visual in visual_transcript:

            v_start = time_to_seconds(
                visual["start_timestamp"]
            )

            v_end = time_to_seconds(
                visual["end_timestamp"]
            )

            if overlap(
                a_start,
                a_end,
                v_start,
                v_end
            ) > 0:

                matched_visuals.append(
                    visual
                )

        aligned.append({
            "start_timestamp":
                audio["start_timestamp"],

            "end_timestamp":
                audio["end_timestamp"],

            "narration":
                audio["narration"],

            "visual_evidence":
                matched_visuals
        })

    return aligned


def generate_horse_summary_merged(
    transcript_text):
    
    prompt = f"""
    You are the horse who is in the focus on the camera in this video.

    Based on the visual transcript below, describe your experience.

    Rules:
    - Speak in first person ("I")
    - Focus on feelings, sensations, and actions
    - Keep narration natural and chronological.
    - If multiple horses are present, focus on the primary horse being observed.
    
    Visual Transcript:
    {transcript_text}
    """
    
    response = MODEL.generate_content(
        prompt,
        generation_config={
            "temperature": 0.2,
            "top_p": 0.8,
        }
    )

    summary = response.text.strip()
    return summary


def extract_memory_keypoints_from_summary(mapped_summary):

    prompt = f"""
    You are a horse recalling the important moments of your day.

    Below is a narrative description of your day written from your perspective.

    DAY NARRATIVE:
    {mapped_summary}

    Your task is to extract the moments that would become **lasting memories**
    from the day.

    These memories should capture meaningful experiences such as:

    • training activities
    • interactions with trainers or humans
    • movements or exercises performed
    • environmental changes (arena, paddock, stable)
    • equipment adjustments
    • notable behavioral responses
    • transitions between activities

    GUIDELINES

    - Write each memory in **first-person ("I")** as the horse.
    - Each memory should be **short and clear (1 sentence)**.
    - Focus only on **important moments**, not every small detail.
    - Keep the memories **chronological**.
    - Do NOT invent events that are not in the narrative.
    - Each memory should feel like something the horse would remember from the day.

    OUTPUT FORMAT

    Return the memories as a numbered list.

    Example:

    1. I began the morning walking calmly around the arena while my trainer guided me forward.

    2. I transitioned into a steady trot when my trainer gave the cue to increase my pace.

    3. I worked through several controlled circles while responding to gentle rein adjustments.

    4. I slowed into a relaxed walk as the training session moved into a cooldown.

    Return only the numbered list of memories.
    """
    return gemini_call_with_retry([prompt])