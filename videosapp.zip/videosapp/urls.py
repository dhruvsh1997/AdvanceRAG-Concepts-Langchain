from django.urls import path
from .views import DailySummaryVideoAPI_New, DailySummaryVideoAPI

urlpatterns = [
    # path("", ShowVideoSummaryAPI.as_view(), name="video-summary"),
    path("daily-summary/",DailySummaryVideoAPI.as_view(),name="daily-summary"),
    path("daily/",DailySummaryVideoAPI_New.as_view(),name="daily"),

]