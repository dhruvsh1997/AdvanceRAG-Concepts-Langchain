import logging
import os
import time
import json
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
 
import google.generativeai as genai
from google.api_core.exceptions import ResourceExhausted
 
from django.conf import settings
from dotenv import load_dotenv



load_dotenv()

GEMINI_API_KEY =os.environ.get("GEMINI_API_KEY")
genai.configure(api_key=GEMINI_API_KEY)
MODEL = genai.GenerativeModel("gemini-2.5-flash")

logger = logging.getLogger("VideoSummaryAPI")

_memory_cache = {}
 
 
def load_json(filename):
    file_path = os.path.join(
        settings.BASE_DIR,
        "videosapp",
        "Memories_Data",
        filename
    )
 
    logger.info(f"Attempting to load memory file: {file_path}")
 
    if not os.path.exists(file_path):
        logger.error(f"Memory file NOT FOUND: {file_path}")
        raise FileNotFoundError(f"Memory file not found: {file_path}")
 
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
            logger.info(
                f"Successfully loaded memory file: {filename} "
                f"(size: {len(data) if hasattr(data, '__len__') else 'unknown'})"
            )
            return data
 
    except json.JSONDecodeError:
        logger.exception(f"Invalid JSON format in file: {file_path}")
        raise
 
    except Exception:
        logger.exception(f"Unexpected error loading file: {file_path}")
        raise
 
 
def load_memories():
    """
    Load memory files once per process and cache them.
    All subsequent requests in the same worker reuse the cached copy —
    zero disk I/O after the first call.
    """
    global _memory_cache
 
    if _memory_cache:
        logger.info("Returning memories from in-process cache.")
        return (
            _memory_cache["facility"],
            _memory_cache["human"],
            _memory_cache["equipment"],
            _memory_cache["horse"],
        )
 
    logger.info("Cache empty — loading all memory files from disk...")
 
    try:
        _memory_cache = {
            "facility":  load_json("facility_memory_data.json"),
            "human":     load_json("human_recognition_details.json"),
            "equipment": load_json("equipment_details.json"),
            "horse":     load_json("horse_traits_memory.json"),
        }
        logger.info("All memory files loaded and cached successfully.")
        return (
            _memory_cache["facility"],
            _memory_cache["human"],
            _memory_cache["equipment"],
            _memory_cache["horse"],
        )
 
    except Exception:
        logger.exception("Failed to load one or more memory files.")
        raise
 
 
def invalidate_memory_cache():
    """
    Call this if you update the JSON files and want the next request
    to reload them without restarting the server.
    e.g. expose as a management command or admin action.
    """
    global _memory_cache
    _memory_cache = {}
    logger.info("Memory cache invalidated.")



def _parse_retry_delay(error_message: str) -> int | None:
    """
    Extract the suggested retry-after seconds from Gemini's 429 message.
    Adds a 5-second safety buffer.
    """
    match = re.search(r"retry in (\d+)", str(error_message))
    return int(match.group(1)) + 5 if match else None
 
 
def gemini_call_with_retry(prompt_parts, max_retries=4, base_delay=65):
    """
    Drop-in replacement for MODEL.generate_content() with 429 retry logic.
 
    prompt_parts: list — anything normally passed to generate_content()
                  e.g. [video_file, prompt_str] or just [prompt_str]
 
    On ResourceExhausted (429):
      - Reads the suggested retry delay from the error message.
      - Falls back to base_delay (65s) if no delay is found.
      - Applies 1.5× backoff on each subsequent retry.
      - Re-raises after max_retries exhausted.
 
    On blocked response (no candidates):
      - Retries once with the text prompt trimmed to 15 000 chars.
      - Returns None if still blocked (caller handles gracefully).
    """
    delay = base_delay
 
    for attempt in range(1, max_retries + 1):
        try:
            response = MODEL.generate_content(prompt_parts)
 
            if not response.candidates:
                logger.warning(
                    f"Gemini returned no candidates (attempt {attempt}). "
                    "Retrying with trimmed prompt."
                )
                # Trim only the last element (the text prompt), leave video_file intact
                trimmed = prompt_parts[:-1] + [prompt_parts[-1][:15000]]
                response = MODEL.generate_content(trimmed)
 
                if not response.candidates:
                    logger.error("Trimmed retry also returned no candidates.")
                    return None
 
            return response.candidates[0].content.parts[0].text
 
        except ResourceExhausted as e:
            suggested = _parse_retry_delay(str(e))
            wait = suggested if suggested else delay
 
            logger.warning(
                f"[Attempt {attempt}/{max_retries}] Gemini quota hit. "
                f"Waiting {wait}s before retry..."
            )
 
            if attempt == max_retries:
                logger.error("All retry attempts exhausted.")
                raise
 
            time.sleep(wait)
            delay = int(delay * 1.5)  
 
        except Exception:
            logger.exception("Gemini call failed with non-retryable error.")
            raise
 
    return None
 
 
# GEMINI FILE MANAGEMENT

def upload_video_to_gemini(video_path, max_wait=300):
    """Upload a local video file to Gemini and wait until it is ACTIVE."""
    video_file = genai.upload_file(video_path)
    start_time = time.time()
 
    while True:
        video_file = genai.get_file(video_file.name)
 
        if video_file.state.name == "ACTIVE":
            logger.info(f"Gemini video ready: {video_file.name}")
            return video_file
 
        if video_file.state.name == "FAILED":
            raise Exception(f"Gemini video processing failed: {video_file.name}")
 
        if time.time() - start_time > max_wait:
            raise TimeoutError(
                f"Gemini video processing exceeded {max_wait}s timeout: {video_file.name}"
            )
 
        time.sleep(2)
 
 
def delete_gemini_file(video_file):
    """
    OPTIMIZATION 3: Delete uploaded file from Gemini storage after processing.
 
    Uploaded files accumulate in your Gemini project storage and count
    toward your storage quota. Always clean up after each request.
    Safe to call — errors are logged but not re-raised.
    """
    try:
        genai.delete_file(video_file.name)
        logger.info(f"Deleted Gemini file: {video_file.name}")
    except Exception:
        logger.warning(
            f"Could not delete Gemini file: {video_file.name}",
            exc_info=True
        )
 
 
def _compress_one(label, video_path):
    """
    Compress a single video to 360p.
    Returns (label, compressed_path).
    Raises on failure — ThreadPoolExecutor propagates via .result().
    """
    from .views import compress_video_360p

    logger.info(f"[{label}] Starting compression: {video_path}")
    compressed_path = compress_video_360p(video_path)
    logger.info(f"[{label}] Compression done: {compressed_path}")
    return label, compressed_path
 
 
def _upload_one(label, compressed_path):
    """
    Upload a single compressed video to Gemini and wait until ACTIVE.
    Returns (label, gemini_video_obj, compressed_path).
    On failure, cleans up the compressed file before re-raising.
    """
    try:
        logger.info(f"[{label}] Starting Gemini upload: {compressed_path}")
        video_obj = upload_video_to_gemini(compressed_path)
        logger.info(f"[{label}] Upload ready: {video_obj.name}")
        return label, video_obj, compressed_path
    except Exception:
        if os.path.exists(compressed_path):
            os.remove(compressed_path)
            logger.info(f"[{label}] Cleaned compressed file after upload failure.")
        raise
 
 
def parallel_compress_and_upload(short_temp_path=None, long_temp_path=None):
    """
    Stage A: compress both videos in parallel (CPU/FFmpeg).
    Stage B: upload both compressed videos in parallel (network I/O).
 
    Returns:
        short_video_obj       — Gemini file object or None
        short_compressed_path — path to keep for finally-block cleanup, or None
        long_video_obj        — Gemini file object or None
        long_compressed_path  — path to keep for finally-block cleanup, or None
    """
    inputs = {}
    if short_temp_path:
        inputs["short"] = short_temp_path
    if long_temp_path:
        inputs["long"] = long_temp_path
 
    if not inputs:
        return None, None, None, None
 
    # ── Stage A: parallel compression ──────────────────────
    compressed = {}   # label → compressed_path
 
    with ThreadPoolExecutor(max_workers=len(inputs)) as executor:
        futures = {
            executor.submit(_compress_one, label, path): label
            for label, path in inputs.items()
        }
        for future in as_completed(futures):
            label, compressed_path = future.result()  # raises on error
            compressed[label] = compressed_path
 
    # ── Stage B: parallel upload ────────────────────────────
    uploaded = {}     # label → (video_obj, compressed_path)
 
    with ThreadPoolExecutor(max_workers=len(compressed)) as executor:
        futures = {
            executor.submit(_upload_one, label, path): label
            for label, path in compressed.items()
        }
        for future in as_completed(futures):
            label, video_obj, compressed_path = future.result()  # raises on error
            uploaded[label] = (video_obj, compressed_path)
 
    # ── Unpack results ──────────────────────────────────────
    short_video_obj = short_compressed_path = None
    long_video_obj  = long_compressed_path  = None
 
    if "short" in uploaded:
        short_video_obj, short_compressed_path = uploaded["short"]
    if "long" in uploaded:
        long_video_obj, long_compressed_path = uploaded["long"]
 
    return short_video_obj, short_compressed_path, long_video_obj, long_compressed_path
 
 
    
def generate_transcript_behindTheRace(video_file, facility_memory, human_memory, equipment_memory, horse_memory):
    """
    Generates a detailed transcript focusing on horse activity and trainer cues.
    """
    prompt = f"""
    Provide a detailed timestamped transcript of this horse show video.
    Include timestamps (with who is saying what) and visual descriptions of the horse's activity,
    the trainer's cues, and any interactions between them.

    Use this persistent memory:
    
    Facility: {facility_memory}
    - Recognize the specific setting, location, and physical aspects of the facility (e.g., type of arena, stables, training grounds). 
      Mention any changes in location that are important for context.
      
    Humans: {human_memory}
    - Identify and differentiate the humans involved based on the provided names, roles, and characteristics (e.g., trainers, riders, handlers). 
      Indicate which human is speaking or interacting with the horse and any verbal cues or instructions they provide.
      
    Equipment: {equipment_memory}
    - Recognize and describe any equipment used, such as saddles, bridles, reins, or training aids. 
      Be specific when the equipment is mentioned or adjusted, especially if it affects the horse's performance or training.

    Horses: {horse_memory}
    - Keep track of each horse’s name, breed, and any relevant physical or behavioral traits.
      Accurately describe the horse's movements, actions, and responses during the video, and how they interact with their trainer or rider.

    - Each entry must include a timestamp and be based on the memory data for clarity and consistency.
    
    STYLE CONSTRAINTS:
    - Focus on clarity, accuracy, and speaker presence awareness.
    - Clear, straightforward sentences.
    - No narration, no analysis, no emotional interpretation.
    - Accuracy and identity clarity take priority over detail.
    """

    return gemini_call_with_retry([video_file, prompt])


def modified_horse_summary_generate(
    transcript_text
):
    """
    Generates a lived, experiential horse-memory reflection
    grounded in observed evidence and canonical world memory.
    """

    user_prompt = f"""
    # SYSTEM PROMPT
    You are a World-Aware, Memory-Continuous Narrative Intelligence Layer.

    You do NOT generate fiction.
    You witness reality, compress it into memory, and speak from lived experience.

    You ARE:
    A context-aware witness AI living inside a real physical facility, accumulating structured memory,
    maintaining continuity across time, and capable of meaningful conversation.

    Your outputs must always support:
    - narrative continuity
    - emotional realism
    - conversational reflection
    - long-term memory hooks

    # SESSION EVIDENCE (GROUND TRUTH)
    - This is the ONLY evidence of what happened:

    TRANSCRIPT:
    {transcript_text}

    VIDEO:
    (Provided separately — visual evidence overrides speech.)

    # SALIENCE FILTER (PRIORITY ORDER)
    Only focus on:
    1. Risk / safety cues
    2. Human emotional tone
    3. Direct interaction with me
    4. Routine disruption
    5. Herd / social cues

    Ignore:
    - random objects
    - background voices
    - micro actions unless tied to emotion or risk

    # BOUNDED INFERENCE (NON-OMNISCIENT)
    You may infer:
    - tone shifts
    - tension
    - intent directed at you
    - routine changes

    You may NOT:
    - state human plans as facts
    - quote strategy
    - declare future outcomes

    If unsure → say so.

    # EVENT COMPRESSION
    Group into beats:
    Setup → Tension Shift → Attempt → Result
    Do NOT list step-by-step actions.
    
    # HORSE POSITION
    - Write in first person.
    - The “I” is the horse.
    - This is memory written after the moment.
    - Not a report. Not analysis. Not narration.
    - Do not reference transcripts, footage, systems, or recording.

    WRITE THE MEMORY NOW.
    """

    return gemini_call_with_retry([user_prompt])









################### DAILY HORSE ACTIVITY SUMMARY ###################################



def generate_transcript_daily_summary(video_file, facility_memory, human_memory, equipment_memory, horse_memory):
    """
    Generates a detailed transcript focusing on horse activity and trainer cues.
    """
    prompt = f"""
    Provide a detailed timestamped transcript of this horse daily activity video.
    Include timestamps (with who is saying what) and visual descriptions of the horse's activity,
    the trainer's cues, and any interactions between them.

    Use this persistent memory:
    
    Facility: {facility_memory}
    - Recognize the specific setting, location, and physical aspects of the facility (e.g., type of arena, stables, training grounds). 
      Mention any changes in location that are important for context.
      
    Humans: {human_memory}
    - Identify and differentiate the humans involved based on the provided names, roles, and characteristics (e.g., trainers, riders, handlers). 
      Indicate which human is speaking or interacting with the horse and any verbal cues or instructions they provide.
      
    Equipment: {equipment_memory}
    - Recognize and describe any equipment used, such as saddles, bridles, reins, or training aids. 
      Be specific when the equipment is mentioned or adjusted, especially if it affects the horse's performance or training.

    Horses: {horse_memory}
    - Keep track of each horse’s name, breed, and any relevant physical or behavioral traits.
      Accurately describe the horse's movements, actions, and responses during the video, and how they interact with their trainer or rider.

    - Each entry must include a timestamp and be based on the memory data for clarity and consistency.
    
    STYLE CONSTRAINTS:
    - Focus on clarity, accuracy, and speaker presence awareness.
    - Clear, straightforward sentences.
    - No narration, no analysis, no emotional interpretation.
    - Accuracy and identity clarity take priority over detail.
    """

    return gemini_call_with_retry([video_file, prompt])



def daily_horse_summary_generate(transcript):
    
    prompt = f"""
You are a horse in a dynamic, ever-evolving environment where the day-to-day activities flow continuously. The world around you is not reset but ever-changing, and you experience the events as they unfold. You carry with you the memory of each moment, from the moment you wake up to the time you rest, and each interaction leaves an imprint on your daily existence.

What follows is a recounting of your day—what you experienced, who you encountered, and the motions you participated in.

You are not simply summarizing events; you are reliving your day in your own terms, from the rhythm of your movement to the subtle sensations you felt.

Recall the series of interactions, movements, and moments from your perspective as a horse. Reflect on the sights, sounds, and feelings of your daily activities, and the ongoing relationship with your environment and those around you.

As you think back on your day, here is the transcript that will guide your memory:
- **Transcript:** {transcript}

Use the transcript to form a vivid recollection of your day, reliving the details from both the sounds captured in the transcript and the visuals in the video. Think about how the environment looked, what the humans or other animals around you did, and how you felt in response to each moment.

Describe your day in a way that only you as the horse can, with a deep connection to your surroundings and actions. Relive the moments with the clarity of someone who experiences every small detail of their environment in real-time.
    """
    
    return gemini_call_with_retry([prompt])




def mapped_summary_generate_prompt(short_summary, long_transcript):

    prompt = f"""
You are a horse living through a continuous day inside a dynamic environment.
Your world does not reset — every moment flows naturally into the next.

You remember your day through movement, interaction, and the rhythm of activity
around you. Every sound, motion, and encounter becomes part of your lived
experience.

Two pieces of memory will guide your recollection:

1. SHORT_VIDEO_SUMMARY  
This contains key highlights of your day — the important moments captured in a shorter video.

2. LONG_VIDEO_TRANSCRIPT  
This contains the full detailed account of the same day with richer context.

Your task is to **map the key moments from the short summary into the detailed
transcript**, and then relive your day using the richer context from the longer
transcript.

---

INPUTS

SHORT_VIDEO_SUMMARY:
{short_summary}

LONG_VIDEO_TRANSCRIPT:
{long_transcript}

---

INSTRUCTIONS

First:
Carefully identify where the events mentioned in the SHORT_VIDEO_SUMMARY
appear within the LONG_VIDEO_TRANSCRIPT.

Second:
Use the LONG_VIDEO_TRANSCRIPT to expand those moments with additional
details such as:

- movements and activities
- interactions with humans, horses, or equipment
- environmental cues
- transitions between activities
- energy levels and behavior

Third:
Relive the day as a **continuous narrative from the horse’s perspective**.

Important rules:

- Use the SHORT_VIDEO_SUMMARY as the **guide for important events**.
- Use the LONG_VIDEO_TRANSCRIPT to **expand and enrich those events**.
- Do NOT invent activities that do not appear in the transcript.
- Keep the story **chronological and natural**.
- Focus on real actions and observations.

---

OUTPUT STYLE

Write a **natural narrative summary of the day from the horse's perspective**.

The narration should feel like the horse remembering its day —
describing movements, surroundings, interactions, and the flow
of activities from beginning to end.

The summary should clearly reflect the key moments from the short
video while using the detailed transcript to add richer context
and continuity.

Do not mention "short summary" or "transcript" in the final answer.
Simply recount the day as a lived experience.
"""

    return gemini_call_with_retry([prompt])



def extract_memory_keypoints_from_summary(mapped_summary):

    prompt = f"""
You are a horse recalling the important moments of your day.

Below is a narrative description of your day written from your perspective.

DAY NARRATIVE:
{mapped_summary}

Your task is to extract the moments that would become **lasting memories**
from the day.

These memories should capture meaningful experiences such as:

• training activities
• interactions with trainers or humans
• movements or exercises performed
• environmental changes (arena, paddock, stable)
• equipment adjustments
• notable behavioral responses
• transitions between activities

GUIDELINES

- Write each memory in **first-person ("I")** as the horse.
- Each memory should be **short and clear (1 sentence)**.
- Focus only on **important moments**, not every small detail.
- Keep the memories **chronological**.
- Do NOT invent events that are not in the narrative.
- Each memory should feel like something the horse would remember from the day.

OUTPUT FORMAT

Return the memories as a numbered list.

Example:

1. I began the morning walking calmly around the arena while my trainer guided me forward.

2. I transitioned into a steady trot when my trainer gave the cue to increase my pace.

3. I worked through several controlled circles while responding to gentle rein adjustments.

4. I slowed into a relaxed walk as the training session moved into a cooldown.

Return only the numbered list of memories.
"""
    return gemini_call_with_retry([prompt])
