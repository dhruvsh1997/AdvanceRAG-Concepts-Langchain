from django.db import models

# Create your models here.

class ShowVideoSummary(models.Model):
    video_url = models.URLField(null=True, blank=True)
    transcript = models.TextField()
    summary = models.TextField()
    processing_time = models.FloatField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"VideoSummary {self.id} - {self.created_at}"