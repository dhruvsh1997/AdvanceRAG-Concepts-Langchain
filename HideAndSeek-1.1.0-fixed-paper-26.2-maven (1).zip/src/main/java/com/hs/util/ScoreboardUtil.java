package com.hs.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.*;

import java.util.*;

public class ScoreboardUtil {

    private final Scoreboard board;
    private final Objective sidebar;
    private final Team hiderNametagTeam; // used to hide hider nametags
    private final Set<String> usedEntries = new HashSet<>();

    public ScoreboardUtil() {
        board = org.bukkit.Bukkit.getScoreboardManager().getNewScoreboard();
        sidebar = board.registerNewObjective("hs_side", Criteria.DUMMY,
                Component.text("✦ HIDE & SEEK ✦", NamedTextColor.AQUA, TextDecoration.BOLD));
        sidebar.setDisplaySlot(DisplaySlot.SIDEBAR);

        Team existing = board.getTeam("hs_hidden");
        hiderNametagTeam = existing != null ? existing : board.registerNewTeam("hs_hidden");
        hiderNametagTeam.setOption(Team.Option.NAME_TAG_VISIBILITY, Team.OptionStatus.NEVER);
    }

    public void apply(Player p) {
        p.setScoreboard(board);
    }

    public void hideNametag(Player p) {
        hiderNametagTeam.addEntry(p.getName());
    }

    public void showNametag(Player p) {
        hiderNametagTeam.removeEntry(p.getName());
    }

    /** Simple pre-match sidebar: just a status line, no roles/timers yet. */
    public void showWaiting(String status) {
        clearScores();
        int line = 15;
        sidebar.getScore("§7" + status).setScore(line);
    }

    /**
     * Rebuilds the full in-match sidebar.
     * @param mapName    the current map's display id, or null
     * @param phase      short phase label, e.g. "Hiding" / "Hunting"
     * @param timer      formatted time remaining, e.g. "1:23" or "45s"
     * @param seekers    all current seekers (may be more than one via mid-match join)
     * @param hidersAlive hiders still in play
     * @param hidersDead  hiders already caught
     */
    public void update(String mapName, String phase, String timer, List<Player> seekers,
                        List<Player> hidersAlive, List<Player> hidersDead) {
        clearScores();
        int line = 15;

        if (mapName != null) {
            sidebar.getScore("§7Map: §f" + trim(mapName, 24)).setScore(line--);
        }
        if (phase != null) {
            sidebar.getScore("§7Phase: §e" + phase).setScore(line--);
        }
        if (timer != null) {
            sidebar.getScore("§7Time left: §f" + timer).setScore(line--);
        }
        sidebar.getScore(blank(line)).setScore(line--);

        if (seekers != null && !seekers.isEmpty()) {
            String label = seekers.size() == 1 ? "§c§lSeeker" : "§c§lSeekers";
            sidebar.getScore(label).setScore(line--);
            for (Player s : seekers) {
                sidebar.getScore(uniqueEntry("§c▶ " + s.getName(), line)).setScore(line--);
            }
            sidebar.getScore(blank(line)).setScore(line--);
        }

        int aliveCount = hidersAlive == null ? 0 : hidersAlive.size();
        int totalHiders = aliveCount + (hidersDead == null ? 0 : hidersDead.size());
        sidebar.getScore("§b§lHiders §f(" + aliveCount + "/" + totalHiders + ")").setScore(line--);
        if (hidersAlive != null) {
            for (Player h : hidersAlive) {
                sidebar.getScore(uniqueEntry("§a✔ " + h.getName(), line)).setScore(line--);
            }
        }
        if (hidersDead != null && !hidersDead.isEmpty()) {
            for (Player h : hidersDead) {
                sidebar.getScore(uniqueEntry("§8§m" + h.getName(), line)).setScore(line--);
            }
        }
    }

    private String trim(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max - 1) + "…";
    }

    private void clearScores() {
        for (String entry : new HashSet<>(board.getEntries())) {
            board.resetScores(entry);
        }
        usedEntries.clear();
    }

    private String blank(int line) {
        return uniqueEntry("§r", line);
    }

    private String uniqueEntry(String base, int line) {
        // Scoreboard entries must be unique strings; append invisible color codes if needed.
        String s = base;
        while (usedEntries.contains(s)) s = s + "§" + Integer.toHexString(Math.abs(line) % 16);
        usedEntries.add(s);
        return s;
    }

    public void clearFor(Player p) {
        p.setScoreboard(org.bukkit.Bukkit.getScoreboardManager().getMainScoreboard());
    }
}
