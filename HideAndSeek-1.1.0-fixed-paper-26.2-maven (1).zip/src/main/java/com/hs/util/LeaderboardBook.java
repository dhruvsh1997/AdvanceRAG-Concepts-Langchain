package com.hs.util;

import com.hs.data.PlayerStats;
import com.hs.data.StatsManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;

import java.util.List;
import java.util.Map;
import java.util.UUID;

public class LeaderboardBook {

    public static ItemStack build(StatsManager stats) {
        ItemStack book = new ItemStack(Material.WRITTEN_BOOK);
        BookMeta meta = (BookMeta) book.getItemMeta();
        meta.setTitle("Leaderboard");
        meta.setAuthor("Hide & Seek");
        meta.displayName(Component.text("Leaderboard", NamedTextColor.GOLD)
                .decoration(TextDecoration.ITALIC, false));

        meta.addPages(
                page("Top Hiders", stats.topHiders(10), true),
                page("Top Seekers", stats.topSeekers(10), false));

        book.setItemMeta(meta);
        return book;
    }

    private static Component page(String title, List<Map.Entry<UUID, PlayerStats>> entries, boolean hider) {
        Component c = Component.text(title, NamedTextColor.DARK_BLUE, TextDecoration.BOLD)
                .append(Component.newline()).append(Component.newline());
        int rank = 1;
        for (Map.Entry<UUID, PlayerStats> e : entries) {
            OfflinePlayer op = Bukkit.getOfflinePlayer(e.getKey());
            String name = op.getName() != null ? op.getName() : "Unknown";
            int wins = hider ? e.getValue().hiderWins : e.getValue().seekerWins;
            c = c.append(Component.text(rank + ". ", NamedTextColor.GRAY))
                    .append(Component.text(name, NamedTextColor.BLACK))
                    .append(Component.text(" - " + wins + " wins", NamedTextColor.DARK_GREEN))
                    .append(Component.newline());
            rank++;
        }
        if (entries.isEmpty()) {
            c = c.append(Component.text("No data yet.", NamedTextColor.GRAY));
        }
        return c;
    }
}
