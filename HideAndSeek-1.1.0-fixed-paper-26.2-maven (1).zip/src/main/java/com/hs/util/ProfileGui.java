package com.hs.util;

import com.hs.data.PlayerStats;
import com.hs.data.StatsManager;
import com.hs.gui.ProfileHolder;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.List;

public class ProfileGui {

    public static Inventory build(Player target, StatsManager stats) {
        ProfileHolder holder = new ProfileHolder();
        Inventory inv = Bukkit.createInventory(holder, 27,
                Component.text(target.getName() + "'s Profile", NamedTextColor.DARK_AQUA, TextDecoration.BOLD));
        holder.setInventory(inv);

        ItemStack pane = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta paneMeta = pane.getItemMeta();
        paneMeta.displayName(Component.text(" "));
        pane.setItemMeta(paneMeta);
        for (int i = 0; i < 27; i++) inv.setItem(i, pane);

        PlayerStats s = stats.get(target.getUniqueId());
        int totalRounds = s.hiderRounds + s.seekerRounds;
        int totalWins = s.hiderWins + s.seekerWins;
        String winRate = totalRounds == 0 ? "N/A" : String.format("%.1f%%", (totalWins * 100.0) / totalRounds);

        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        meta.setOwningPlayer(target);
        meta.displayName(Component.text(target.getName(), NamedTextColor.YELLOW, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                blank(),
                stat("Hider wins", s.hiderWins, NamedTextColor.AQUA),
                stat("Seeker wins", s.seekerWins, NamedTextColor.RED),
                stat("Total wins", totalWins, NamedTextColor.GOLD),
                blank(),
                stat("Rounds as Hider", s.hiderRounds, NamedTextColor.AQUA),
                stat("Rounds as Seeker", s.seekerRounds, NamedTextColor.RED),
                stat("Total rounds", totalRounds, NamedTextColor.GRAY),
                blank(),
                stat("Hiders caught", s.catches, NamedTextColor.RED),
                stat("Times survived", s.survives, NamedTextColor.AQUA),
                blank(),
                line("Win rate", winRate, NamedTextColor.GREEN)
        ));
        head.setItemMeta(meta);
        inv.setItem(13, head);

        return inv;
    }

    private static Component blank() {
        return Component.text(" ");
    }

    private static Component stat(String label, int value, NamedTextColor color) {
        return Component.text(label + ": ", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)
                .append(Component.text(value, color).decoration(TextDecoration.ITALIC, false));
    }

    private static Component line(String label, String value, NamedTextColor color) {
        return Component.text(label + ": ", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)
                .append(Component.text(value, color).decoration(TextDecoration.ITALIC, false));
    }
}
