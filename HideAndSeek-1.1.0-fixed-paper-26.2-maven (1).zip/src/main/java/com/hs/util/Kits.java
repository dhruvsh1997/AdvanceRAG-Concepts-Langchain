package com.hs.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

/** Builds the fixed item kits for seekers and hiders. Custom items are tagged via PersistentDataContainer
 *  so listeners can identify them regardless of slot, and so /inv edit templates keep working. */
public class Kits {

    // PDC keys, initialized by the plugin's NamespacedKey factory
    public static NamespacedKey KEY_ITEM_ID;
    public static NamespacedKey KEY_STICK_USES;

    public static final String ID_SNOWBALL = "hs_snowball";
    public static final String ID_TROLL_SUGAR = "hs_troll_sugar";
    public static final String ID_SPECTATE_COMPASS = "hs_spectate_compass";
    public static final String ID_HIDER_STICK = "hs_hider_stick";
    public static final String ID_SEEKER_SWORD = "hs_seeker_sword";
    public static final String ID_WIND_CHARGE = "hs_wind_charge";
    public static final String ID_ENDER_PEARL = "hs_ender_pearl";
    public static final String ID_MACE = "hs_mace";
    public static final String ID_BOW = "hs_bow";

    // spectator / mid-match lobby / profile items
    public static final String ID_STOP_SPECTATING = "hs_stop_spectating_poppy";
    public static final String ID_SPECTATOR_LIST_COMPASS = "hs_spectator_list_compass";
    public static final String ID_JOIN_SEEKER_SWORD = "hs_join_seeker_sword";
    public static final String ID_LOBBY_SPECTATE_COMPASS = "hs_lobby_spectate_compass";
    public static final String ID_PROFILE_HEAD = "hs_profile_head";

    public static ItemStack tag(ItemStack item, String id) {
        ItemMeta meta = item.getItemMeta();
        meta.getPersistentDataContainer().set(KEY_ITEM_ID, PersistentDataType.STRING, id);
        item.setItemMeta(meta);
        return item;
    }

    public static String getTag(ItemStack item) {
        if (item == null || item.getItemMeta() == null) return null;
        return item.getItemMeta().getPersistentDataContainer().get(KEY_ITEM_ID, PersistentDataType.STRING);
    }

    private static Component name(String text, NamedTextColor color) {
        return Component.text(text, color).decoration(TextDecoration.ITALIC, false);
    }

    private static Component lore(String text) {
        return Component.text(text, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false);
    }

    // ---------- individual item builders ----------

    public static ItemStack buildMace() {
        ItemStack mace = new ItemStack(Material.MACE);
        ItemMeta meta = mace.getItemMeta();
        meta.displayName(name("Seeker's Mace", NamedTextColor.RED));
        mace.setItemMeta(meta);
        return tag(mace, ID_MACE);
    }

    public static ItemStack buildWindCharge() {
        ItemStack wind = new ItemStack(Material.WIND_CHARGE, 64);
        ItemMeta meta = wind.getItemMeta();
        meta.displayName(name("Wind Charge", NamedTextColor.WHITE));
        meta.lore(List.of(lore("Never runs out")));
        wind.setItemMeta(meta);
        return tag(wind, ID_WIND_CHARGE);
    }

    public static ItemStack buildEnderPearl(int amount) {
        ItemStack pearl = new ItemStack(Material.ENDER_PEARL, amount);
        ItemMeta meta = pearl.getItemMeta();
        meta.lore(List.of(lore("Never runs out")));
        pearl.setItemMeta(meta);
        return tag(pearl, ID_ENDER_PEARL);
    }

    public static ItemStack buildOneShotSword() {
        ItemStack sword = new ItemStack(Material.NETHERITE_SWORD);
        ItemMeta meta = sword.getItemMeta();
        meta.displayName(name("✦ One-Shot Blade ✦", NamedTextColor.RED));
        meta.lore(List.of(lore("Any hit catches a hider instantly")));
        meta.setUnbreakable(true);
        AttributeModifier dmgMod = new AttributeModifier(
                new NamespacedKey("hideandseek", "one_shot_damage"), 500.0,
                AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND);
        meta.addAttributeModifier(Attribute.ATTACK_DAMAGE, dmgMod);
        sword.setItemMeta(meta);
        return tag(sword, ID_SEEKER_SWORD);
    }

    public static ItemStack[] buildInfinityBowAndArrow() {
        ItemStack bow = new ItemStack(Material.BOW);
        ItemMeta meta = bow.getItemMeta();
        meta.displayName(name("Hunter's Bow", NamedTextColor.GOLD));
        meta.addEnchant(Enchantment.INFINITY, 1, true);
        meta.setUnbreakable(true);
        bow.setItemMeta(meta);
        return new ItemStack[]{ tag(bow, ID_BOW), new ItemStack(Material.ARROW, 1) };
    }

    public static ItemStack buildRevealSnowball(int glowSeconds) {
        ItemStack snowball = new ItemStack(Material.SNOWBALL, 3);
        ItemMeta meta = snowball.getItemMeta();
        meta.displayName(name("❄ Reveal Snowball", NamedTextColor.AQUA));
        meta.lore(List.of(
                lore("Right-click to glow all hiders"),
                lore("cyan for " + glowSeconds + "s. Only 3 uses!")));
        snowball.setItemMeta(meta);
        return tag(snowball, ID_SNOWBALL);
    }

    public static ItemStack buildPanicStick() {
        ItemStack stick = new ItemStack(Material.STICK);
        ItemMeta meta = stick.getItemMeta();
        meta.displayName(name("Panic Stick", NamedTextColor.YELLOW));
        meta.addEnchant(Enchantment.KNOCKBACK, 10, true);
        meta.lore(List.of(lore("Knocks the seeker away"), lore("3 uses only")));
        meta.getPersistentDataContainer().set(KEY_STICK_USES, PersistentDataType.INTEGER, 3);
        stick.setItemMeta(meta);
        return tag(stick, ID_HIDER_STICK);
    }

    public static ItemStack buildTrollSugar(int seconds) {
        ItemStack sugar = new ItemStack(Material.SUGAR);
        ItemMeta meta = sugar.getItemMeta();
        meta.displayName(name("Troll Seeker", NamedTextColor.LIGHT_PURPLE));
        meta.lore(List.of(lore("Right-click to bait the seeker"),
                lore("Blinking glow for " + seconds + "s")));
        sugar.setItemMeta(meta);
        return tag(sugar, ID_TROLL_SUGAR);
    }

    public static ItemStack buildSpectateCompass() {
        ItemStack compass = new ItemStack(Material.COMPASS);
        ItemMeta meta = compass.getItemMeta();
        meta.displayName(name("\uD83D\uDC41 Spectate Seeker", NamedTextColor.GOLD));
        meta.lore(List.of(lore("Right-click to watch through"), lore("the seeker's eyes")));
        compass.setItemMeta(meta);
        return tag(compass, ID_SPECTATE_COMPASS);
    }

    /** Every unique ability/kit item in the plugin, for the /ability items viewer. */
    public static List<ItemStack> allAbilityItems(int glowSeconds, int trollSeconds) {
        List<ItemStack> list = new ArrayList<>();
        list.add(buildMace());
        list.add(buildWindCharge());
        list.add(buildEnderPearl(64));
        list.add(buildOneShotSword());
        ItemStack[] bow = buildInfinityBowAndArrow();
        list.add(bow[0]);
        list.add(bow[1]);
        list.add(buildRevealSnowball(glowSeconds));
        list.add(buildPanicStick());
        list.add(buildTrollSugar(trollSeconds));
        list.add(buildSpectateCompass());
        return list;
    }

    // ---------- spectator / mid-match lobby / profile items ----------

    public static ItemStack buildStopSpectatingPoppy() {
        ItemStack poppy = new ItemStack(Material.POPPY);
        ItemMeta meta = poppy.getItemMeta();
        meta.displayName(name("Stop Spectating", NamedTextColor.RED));
        meta.lore(List.of(lore("Click to return to the lobby")));
        poppy.setItemMeta(meta);
        return tag(poppy, ID_STOP_SPECTATING);
    }

    public static ItemStack buildSpectatorListCompass() {
        ItemStack compass = new ItemStack(Material.COMPASS);
        ItemMeta meta = compass.getItemMeta();
        meta.displayName(name("Spectate", NamedTextColor.GOLD));
        meta.lore(List.of(lore("Click to teleport to a player")));
        compass.setItemMeta(meta);
        return tag(compass, ID_SPECTATOR_LIST_COMPASS);
    }

    public static ItemStack buildJoinSeekerSword() {
        ItemStack sword = new ItemStack(Material.IRON_SWORD);
        ItemMeta meta = sword.getItemMeta();
        meta.displayName(name("Join as a Hunter/Seeker", NamedTextColor.RED));
        meta.lore(List.of(lore("Right-click to jump into the hunt")));
        sword.setItemMeta(meta);
        return tag(sword, ID_JOIN_SEEKER_SWORD);
    }

    public static ItemStack buildLobbySpectateCompass() {
        ItemStack compass = new ItemStack(Material.COMPASS);
        ItemMeta meta = compass.getItemMeta();
        meta.displayName(name("Spectate", NamedTextColor.GOLD));
        meta.lore(List.of(lore("Click to watch the match")));
        compass.setItemMeta(meta);
        return tag(compass, ID_LOBBY_SPECTATE_COMPASS);
    }

    /** A player's own head, skinned as them, used as the profile-viewer item in the lobby. */
    public static ItemStack buildProfileHead(Player owner) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        org.bukkit.inventory.meta.SkullMeta meta = (org.bukkit.inventory.meta.SkullMeta) head.getItemMeta();
        meta.setOwningPlayer(owner);
        meta.displayName(name("Your Profile", NamedTextColor.YELLOW));
        meta.lore(List.of(lore("Right-click to view your stats"),
                lore("Sneak + right-click any player"),
                lore("to view theirs")));
        head.setItemMeta(meta);
        return tag(head, ID_PROFILE_HEAD);
    }

    // ---------- full kit builders (36-slot arrays matching player main inventory) ----------

    public static ItemStack[] buildDefaultSeekerKit(int glowSeconds) {
        ItemStack[] arr = new ItemStack[36];
        arr[0] = buildMace();
        arr[1] = buildWindCharge();
        arr[2] = buildEnderPearl(64);
        arr[3] = buildOneShotSword();
        ItemStack[] bow = buildInfinityBowAndArrow();
        arr[4] = bow[0];
        arr[5] = bow[1];
        arr[8] = buildRevealSnowball(glowSeconds);
        return arr;
    }

    public static ItemStack[] buildDefaultHiderKit(int trollSeconds) {
        ItemStack[] arr = new ItemStack[36];
        arr[0] = buildEnderPearl(64);
        arr[1] = buildWindCharge();
        arr[2] = buildPanicStick();
        arr[3] = buildTrollSugar(trollSeconds);
        arr[8] = buildSpectateCompass();
        return arr;
    }

    // ---------- giving kits to players ----------

    public static void applyKit(Player p, ItemStack[] template) {
        p.getInventory().clear();
        ItemStack[] contents = new ItemStack[41]; // 36 main + 4 armor + 1 offhand
        for (int i = 0; i < 36 && i < template.length; i++) {
            contents[i] = template[i] == null ? null : template[i].clone();
        }
        p.getInventory().setContents(contents);
    }

    /** Full spectator mode (GameMode.SPECTATOR) hotbar: slot 0 = teleport-list compass, slot 8 = stop-spectating poppy. */
    public static void applySpectatorHotbar(Player p) {
        p.getInventory().clear();
        p.getInventory().setItem(0, buildSpectatorListCompass());
        p.getInventory().setItem(8, buildStopSpectatingPoppy());
    }

    /** Mid-match "adventure lobby" hotbar: slot 0 = join-as-seeker sword, slot 1 = spectate compass, slot 8 = leaderboard book. */
    public static void applyMidMatchLobbyHotbar(Player p, ItemStack leaderboardBook) {
        p.getInventory().clear();
        p.getInventory().setItem(0, buildJoinSeekerSword());
        p.getInventory().setItem(1, buildLobbySpectateCompass());
        p.getInventory().setItem(8, leaderboardBook);
    }
}
