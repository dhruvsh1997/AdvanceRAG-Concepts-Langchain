package com.hs.listeners;

import com.hs.GameManager;
import com.hs.HideAndSeekPlugin;
import com.hs.PlayerRole;
import com.hs.gui.SpectatorListHolder;
import com.hs.util.Kits;
import com.hs.util.ProfileGui;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

public class SpectatorListener implements Listener {

    private final HideAndSeekPlugin plugin;
    private final GameManager gm;

    public SpectatorListener(HideAndSeekPlugin plugin) {
        this.plugin = plugin;
        this.gm = plugin.getGameManager();
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        ItemStack item = e.getItem();
        if (item == null || !e.getAction().isRightClick()) return;
        String id = Kits.getTag(item);
        if (id == null) return;
        Player p = e.getPlayer();

        switch (id) {
            case Kits.ID_STOP_SPECTATING -> {
                e.setCancelled(true);
                gm.exitSpectatorToLobby(p);
            }
            case Kits.ID_SPECTATOR_LIST_COMPASS -> {
                e.setCancelled(true);
                p.openInventory(buildSpectatorListGui());
            }
            case Kits.ID_JOIN_SEEKER_SWORD -> {
                e.setCancelled(true);
                gm.joinAsSeekerMidMatch(p);
            }
            case Kits.ID_LOBBY_SPECTATE_COMPASS -> {
                e.setCancelled(true);
                gm.enterSpectatorFromLobby(p);
            }
            case Kits.ID_PROFILE_HEAD -> {
                e.setCancelled(true);
                p.openInventory(ProfileGui.build(p, gm.getStats()));
            }
            default -> {}
        }
    }

    /** Sneak + right-click another player anywhere, anytime, to view their profile. */
    @EventHandler
    public void onEntityInteract(PlayerInteractEntityEvent e) {
        if (!e.getPlayer().isSneaking()) return;
        if (!(e.getRightClicked() instanceof Player target)) return;
        e.setCancelled(true);
        e.getPlayer().openInventory(ProfileGui.build(target, gm.getStats()));
    }

    private Inventory buildSpectatorListGui() {
        SpectatorListHolder holder = new SpectatorListHolder();
        Inventory inv = Bukkit.createInventory(holder, 27,
                Component.text("Spectate a Player", NamedTextColor.DARK_AQUA, TextDecoration.BOLD));
        holder.setInventory(inv);

        // hiders fill the top + bottom rows
        int[] hiderSlots = {0, 1, 2, 3, 4, 5, 6, 7, 8, 18, 19, 20, 21, 22, 23, 24, 25, 26};
        int hi = 0;
        for (Player h : gm.getAliveHiders()) {
            if (hi >= hiderSlots.length) break;
            int slot = hiderSlots[hi++];
            inv.setItem(slot, headFor(h, NamedTextColor.AQUA));
            holder.setTarget(slot, h);
        }

        // seeker(s) sit in the middle row, centered
        var seekers = gm.getSeekers();
        int[] midSlots = {13, 12, 14, 11, 15, 10, 16, 9, 17};
        for (int i = 0; i < seekers.size() && i < midSlots.length; i++) {
            int slot = midSlots[i];
            inv.setItem(slot, headFor(seekers.get(i), NamedTextColor.RED));
            holder.setTarget(slot, seekers.get(i));
        }

        return inv;
    }

    private ItemStack headFor(Player target, NamedTextColor nameColor) {
        ItemStack head = new ItemStack(org.bukkit.Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        meta.setOwningPlayer(target);
        meta.displayName(Component.text(target.getName(), nameColor, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        head.setItemMeta(meta);
        return head;
    }

    @EventHandler
    public void onSpectatorListClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof SpectatorListHolder holder)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == null || !(e.getClickedInventory().getHolder() instanceof SpectatorListHolder)) return;
        var targetId = holder.getTarget(e.getSlot());
        if (targetId == null) return;
        Player target = Bukkit.getPlayer(targetId);
        if (target == null || !(e.getWhoClicked() instanceof Player viewer)) return;
        if (viewer.getGameMode() != GameMode.SPECTATOR || gm.getRole(viewer) != PlayerRole.SPECTATOR) return;
        viewer.teleport(target.getLocation());
        viewer.closeInventory();
    }
}
