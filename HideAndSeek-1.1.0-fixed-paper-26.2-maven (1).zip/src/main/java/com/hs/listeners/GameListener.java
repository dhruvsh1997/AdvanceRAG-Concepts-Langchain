package com.hs.listeners;

import com.hs.GameManager;
import com.hs.GameState;
import com.hs.HideAndSeekPlugin;
import com.hs.PlayerRole;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;

public class GameListener implements Listener {

    private final HideAndSeekPlugin plugin;
    private final GameManager gm;

    public GameListener(HideAndSeekPlugin plugin) {
        this.plugin = plugin;
        this.gm = plugin.getGameManager();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        e.joinMessage(null);
        gm.onJoin(e.getPlayer());
        gm.broadcast(Component.text(e.getPlayer().getName() + " joined.", NamedTextColor.GRAY));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        e.quitMessage(null);
        gm.broadcast(Component.text(e.getPlayer().getName() + " left.", NamedTextColor.GRAY));
        gm.onQuit(e.getPlayer());
    }

    // Seeker's one-shot sword / mace kill a hider -> caught, not actually death (avoid death screen spam)
    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;
        if (!(e.getDamager() instanceof Player attacker)) return;
        if (gm.getState() != GameState.HUNT_PHASE) return;

        if (gm.getRole(attacker) == PlayerRole.SEEKER && gm.getRole(victim) == PlayerRole.HIDER) {
            e.setCancelled(true); // we handle the "catch" ourselves instead of letting them die/respawn
            gm.onHiderCaught(victim, attacker);
        } else if (gm.getRole(attacker) == PlayerRole.HIDER && gm.getRole(victim) == PlayerRole.SEEKER) {
            // hiders are allowed to knock the seeker back with the panic stick (handled by knockback enchant);
            // prevent them from actually damaging the seeker
            e.setDamage(0);
        } else if (gm.getRole(victim) == PlayerRole.SPECTATOR || gm.getRole(attacker) == PlayerRole.SPECTATOR) {
            e.setCancelled(true);
        }
    }

    // Prevent any other damage source from killing players mid-match (fall, fire, drown, etc.)
    // so the only way to "die" is being caught by the seeker.
    @EventHandler
    public void onOtherDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (gm.getState() == GameState.HIDE_PHASE || gm.getState() == GameState.HUNT_PHASE) {
            PlayerRole role = gm.getRole(p);
            if (role == PlayerRole.HIDER || role == PlayerRole.SEEKER) {
                if (e.getCause() != EntityDamageEvent.DamageCause.ENTITY_ATTACK) {
                    e.setCancelled(true);
                }
            } else {
                e.setCancelled(true);
            }
        } else if (gm.getState() != GameState.HUNT_PHASE && gm.getState() != GameState.HIDE_PHASE) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onHunger(FoodLevelChangeEvent e) {
        e.setCancelled(true);
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        e.setCancelled(true);
    }

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        if (gm.getState() != GameState.HUNT_PHASE || gm.getRole(e.getPlayer()) != PlayerRole.SEEKER) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent e) {
        e.setCancelled(true);
    }
}
