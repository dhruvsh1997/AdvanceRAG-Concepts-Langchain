package com.hs.listeners;

import com.hs.HideAndSeekPlugin;
import com.hs.gui.AbilityViewHolder;
import com.hs.gui.KitEditHolder;
import com.hs.gui.ProfileHolder;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryClickEvent;

public class GuiListener implements Listener {

    private final HideAndSeekPlugin plugin;

    public GuiListener(HideAndSeekPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder() instanceof KitEditHolder holder)) return;
        var contents = e.getInventory().getContents();
        if (holder.getRole() == KitEditHolder.Role.SEEKER) {
            plugin.getKitManager().saveSeeker(contents);
        } else {
            plugin.getKitManager().saveHider(contents);
        }
        if (e.getPlayer() instanceof Player p) {
            p.sendMessage(Component.text("Saved the " +
                    (holder.getRole() == KitEditHolder.Role.SEEKER ? "seeker" : "hider") + " kit.",
                    NamedTextColor.GREEN));
        }
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        boolean viewOnly = e.getInventory().getHolder() instanceof AbilityViewHolder
                || e.getInventory().getHolder() instanceof ProfileHolder;
        if (viewOnly && e.getClickedInventory() != null
                && (e.getClickedInventory().getHolder() instanceof AbilityViewHolder
                    || e.getClickedInventory().getHolder() instanceof ProfileHolder)) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof AbilityViewHolder
                || e.getInventory().getHolder() instanceof ProfileHolder) {
            e.setCancelled(true);
        }
    }
}
