package com.hs.listeners;

import com.hs.GameManager;
import com.hs.GameState;
import com.hs.HideAndSeekPlugin;
import com.hs.PlayerRole;
import com.hs.util.Kits;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class InteractListener implements Listener {

    private final HideAndSeekPlugin plugin;
    private final GameManager gm;

    // Players currently spectating the seeker via the compass, mapped to where to return them
    private final Map<UUID, org.bukkit.Location> spectating = new HashMap<>();
    private final Set<UUID> onCooldown = new HashSet<>();

    public InteractListener(HideAndSeekPlugin plugin) {
        this.plugin = plugin;
        this.gm = plugin.getGameManager();
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        ItemStack item = e.getItem();
        if (item == null) return;
        String id = Kits.getTag(item);
        if (id == null) return;
        Player p = e.getPlayer();
        if (!e.getAction().isRightClick()) return;
        // PlayerInteractEvent can fire once per hand; only handle the main-hand event or
        // every right click ends up processed (and toggled) twice.
        if (e.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return;

        switch (id) {
            case Kits.ID_SNOWBALL -> {
                e.setCancelled(true);
                handleSnowball(p, item);
            }
            case Kits.ID_TROLL_SUGAR -> {
                e.setCancelled(true);
                handleTrollSugar(p);
            }
            case Kits.ID_SPECTATE_COMPASS -> {
                e.setCancelled(true);
                handleSpectateCompass(p);
            }
            case Kits.ID_WIND_CHARGE, Kits.ID_ENDER_PEARL -> refillNextTick(p, id);
            default -> {}
        }
    }

    // Only the seeker's wind charges/pearls are infinite. Hiders use the same item IDs but
    // must NOT be refilled — they get one stack (64) and it depletes normally.
    private void refillNextTick(Player p, String id) {
        if (gm.getRole(p) != PlayerRole.SEEKER) return;
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (gm.getState() != GameState.HIDE_PHASE && gm.getState() != GameState.HUNT_PHASE) return;
            if (gm.getRole(p) != PlayerRole.SEEKER) return;
            for (ItemStack it : p.getInventory().getContents()) {
                if (it != null && id.equals(Kits.getTag(it)) && it.getAmount() < 64) {
                    it.setAmount(64);
                }
            }
        }, 1L);
    }

    private void handleSnowball(Player seeker, ItemStack item) {
        if (gm.getRole(seeker) != PlayerRole.SEEKER || gm.getState() != GameState.HUNT_PHASE) return;
        if (item.getAmount() <= 0) return;
        item.setAmount(item.getAmount() - 1);

        int dur = gm.getSnowballGlowSeconds() * 20;
        for (Player target : Bukkit.getOnlinePlayers()) {
            if (gm.getRole(target) == PlayerRole.HIDER) {
                target.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, dur, 0, false, false));
            }
        }
        seeker.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, dur, 0, false, false));
        gm.broadcast(Component.text("The seeker revealed all hiders!", NamedTextColor.AQUA));

        int[] left = {gm.getSnowballGlowSeconds()};
        new BukkitRunnable() {
            @Override public void run() {
                if (left[0] <= 0 || gm.getState() != GameState.HUNT_PHASE) {
                    cancel();
                    return;
                }
                for (Player t : Bukkit.getOnlinePlayers()) {
                    PlayerRole r = gm.getRole(t);
                    if (r == PlayerRole.HIDER || r == PlayerRole.SEEKER) {
                        t.sendActionBar(Component.text("Glowing: " + left[0] + "s", NamedTextColor.AQUA));
                    }
                }
                left[0]--;
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    private void handleTrollSugar(Player hider) {
        if (gm.getRole(hider) != PlayerRole.HIDER || gm.getState() != GameState.HUNT_PHASE) return;
        if (onCooldown.contains(hider.getUniqueId())) return;
        onCooldown.add(hider.getUniqueId());

        int totalTicks = gm.getTrollSeekerSeconds() * 20;
        Player seeker = gm.getSeeker();
        gm.broadcast(Component.text(hider.getName() + " baited the seeker!", NamedTextColor.LIGHT_PURPLE));

        new BukkitRunnable() {
            int tick = 0;
            @Override public void run() {
                if (tick >= totalTicks) {
                    hider.removePotionEffect(PotionEffectType.GLOWING);
                    onCooldown.remove(hider.getUniqueId());
                    hider.setExp(0); hider.setLevel(0);
                    if (seeker != null) { seeker.setExp(0); seeker.setLevel(0); }
                    cancel();
                    return;
                }
                // blink: on for 2 ticks, off for 2 ticks
                if ((tick / 2) % 2 == 0) {
                    hider.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 4, 0, false, false));
                } else {
                    hider.removePotionEffect(PotionEffectType.GLOWING);
                }
                float progress = 1f - ((float) tick / totalTicks);
                hider.setExp(Math.max(0f, Math.min(1f, progress)));
                hider.setLevel(Math.max(0, (totalTicks - tick) / 20));
                if (seeker != null) {
                    seeker.setExp(Math.max(0f, Math.min(1f, progress)));
                    seeker.setLevel(Math.max(0, (totalTicks - tick) / 20));
                }
                tick++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void handleSpectateCompass(Player hider) {
        if (gm.getRole(hider) != PlayerRole.HIDER || gm.getState() != GameState.HUNT_PHASE) return;
        Player seeker = gm.getSeeker();
        if (seeker == null) return;

        if (spectating.containsKey(hider.getUniqueId())) {
            stopSpectating(hider);
        } else {
            spectating.put(hider.getUniqueId(), hider.getLocation());
            hider.setGameMode(GameMode.SPECTATOR);
            // setSpectatorTarget must happen a tick after the gamemode switch actually
            // reaches the client, otherwise the client silently ignores it and the
            // compass appears to "do nothing".
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (!spectating.containsKey(hider.getUniqueId())) return; // toggled off already
                if (hider.getGameMode() != GameMode.SPECTATOR) return;
                Player currentSeeker = gm.getSeeker();
                if (currentSeeker != null) hider.setSpectatorTarget(currentSeeker);
            }, 2L);
            hider.sendMessage(Component.text("Right-click the compass again to return.", NamedTextColor.GRAY));
        }
    }

    private void stopSpectating(Player hider) {
        org.bukkit.Location back = spectating.remove(hider.getUniqueId());
        hider.setSpectatorTarget(null);
        hider.setGameMode(GameMode.ADVENTURE);
        if (back != null) hider.teleport(back);
    }

    /** Drops any stale compass-spectate tracking for a player without touching their
     *  gamemode (used when something else, like being caught, already moved them on). */
    public void forgetSpectate(Player p) {
        spectating.remove(p.getUniqueId());
    }

    @EventHandler
    public void onHiderStickHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player attacker)) return;
        ItemStack hand = attacker.getInventory().getItemInMainHand();
        if (!Kits.ID_HIDER_STICK.equals(Kits.getTag(hand))) return;

        ItemMeta meta = hand.getItemMeta();
        Integer uses = meta.getPersistentDataContainer().get(Kits.KEY_STICK_USES, PersistentDataType.INTEGER);
        if (uses == null) uses = 3;
        uses--;
        if (uses <= 0) {
            attacker.getInventory().remove(hand);
            attacker.sendMessage(Component.text("Your Panic Stick broke!", NamedTextColor.GRAY));
        } else {
            meta.getPersistentDataContainer().set(Kits.KEY_STICK_USES, PersistentDataType.INTEGER, uses);
            hand.setItemMeta(meta);
        }
    }
}
