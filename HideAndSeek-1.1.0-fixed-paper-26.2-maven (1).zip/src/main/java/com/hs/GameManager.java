package com.hs;

import com.hs.data.KitManager;
import com.hs.data.MapManager;
import com.hs.data.RoleCommandManager;
import com.hs.data.StatsManager;
import com.hs.util.Kits;
import com.hs.util.LeaderboardBook;
import com.hs.util.ScoreboardUtil;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.*;

public class GameManager {

    // ---- brand styling ----
    private static final Component PREFIX = Component.text("[", NamedTextColor.DARK_GRAY)
            .append(Component.text("Hide&Seek", NamedTextColor.AQUA, TextDecoration.BOLD))
            .append(Component.text("] ", NamedTextColor.DARK_GRAY))
            .decoration(TextDecoration.ITALIC, false);

    private static final NamedTextColor[] SPIN_COLORS = {
            NamedTextColor.RED, NamedTextColor.GOLD, NamedTextColor.YELLOW,
            NamedTextColor.GREEN, NamedTextColor.AQUA, NamedTextColor.LIGHT_PURPLE
    };

    private final com.hs.HideAndSeekPlugin plugin;
    private final StatsManager stats;
    private final MapManager mapManager;
    private final KitManager kitManager;
    private final RoleCommandManager roleCommandManager;
    private final ScoreboardUtil scoreboard = new ScoreboardUtil();

    private GameState state = GameState.WAITING;
    private final Map<UUID, PlayerRole> roles = new HashMap<>();
    private final Set<UUID> caught = new HashSet<>(); // hiders caught this match

    private MapManager.MapData currentMap; // map in use for the current/last match

    private BukkitTask tickTask;
    private int secondsLeft;
    private BossBar matchBossBar;

    // config
    private int maxWaitingDisplay, countdownSeconds, hideSeconds, matchSeconds,
            nextMatchSeconds, roleSpinSeconds, snowballGlowSeconds, trollSeekerSeconds, minPlayers;

    public GameManager(com.hs.HideAndSeekPlugin plugin, MapManager mapManager, KitManager kitManager,
                        RoleCommandManager roleCommandManager) {
        this.plugin = plugin;
        this.mapManager = mapManager;
        this.kitManager = kitManager;
        this.roleCommandManager = roleCommandManager;
        this.stats = new StatsManager(plugin);
        loadConfig();
        startHeartbeat();
    }

    public void loadConfig() {
        var c = plugin.getConfig();
        maxWaitingDisplay = c.getInt("settings.max-waiting-display", 35);
        countdownSeconds = c.getInt("settings.countdown-seconds", 60);
        hideSeconds = c.getInt("settings.hide-seconds", 60);
        matchSeconds = c.getInt("settings.match-seconds", 480);
        nextMatchSeconds = c.getInt("settings.next-match-seconds", 30);
        roleSpinSeconds = c.getInt("settings.role-spin-seconds", 5);
        snowballGlowSeconds = c.getInt("settings.snowball-glow-seconds", 20);
        trollSeekerSeconds = c.getInt("settings.troll-seeker-seconds", 5);
        minPlayers = c.getInt("settings.min-players", 2);
    }

    public GameState getState() { return state; }
    public ScoreboardUtil getScoreboardUtil() { return scoreboard; }
    public StatsManager getStats() { return stats; }
    public MapManager getMapManager() { return mapManager; }
    public KitManager getKitManager() { return kitManager; }
    public RoleCommandManager getRoleCommandManager() { return roleCommandManager; }
    public PlayerRole getRole(Player p) { return roles.getOrDefault(p.getUniqueId(), PlayerRole.NONE); }
    public MapManager.MapData getCurrentMap() { return currentMap; }

    public boolean isMidMatch() { return state == GameState.HIDE_PHASE || state == GameState.HUNT_PHASE; }

    /** Where players sit while nothing is happening yet: the last-used map's lobby if we have one,
     *  otherwise any completed map's lobby, otherwise the default world spawn. */
    private Location waitingLocation() {
        if (currentMap != null && currentMap.lobby != null) return currentMap.lobby;
        MapManager.MapData any = mapManager.randomCompleted();
        if (any != null) return any.lobby;
        World w = Bukkit.getWorlds().isEmpty() ? null : Bukkit.getWorlds().get(0);
        return w != null ? w.getSpawnLocation() : null;
    }

    // ---------------- Player join/quit ----------------

    public void onJoin(Player p) {
        scoreboard.apply(p);
        p.setGameMode(GameMode.ADVENTURE);
        if (state == GameState.WAITING || state == GameState.COUNTDOWN || state == GameState.ENDING) {
            roles.put(p.getUniqueId(), PlayerRole.NONE);
            teleportSafe(p, waitingLocation());
            giveLobbyBook(p);
            giveProfileHead(p);
        } else {
            // mid-match join -> full spectator mode with the spectator hotbar
            roles.put(p.getUniqueId(), PlayerRole.SPECTATOR);
            p.setGameMode(GameMode.SPECTATOR);
            teleportSafe(p, currentMap != null ? currentMap.start : waitingLocation());
            Kits.applySpectatorHotbar(p);
            p.sendMessage(PREFIX.append(Component.text("A match is in progress — you'll spectate until it ends.", NamedTextColor.GRAY)));
        }
    }

    public void onQuit(Player p) {
        PlayerRole role = getRole(p);
        roles.remove(p.getUniqueId());
        scoreboard.showNametag(p);

        if (role == PlayerRole.SEEKER && (state == GameState.HIDE_PHASE || state == GameState.HUNT_PHASE)) {
            broadcast(Component.text("The seeker left — match cancelled!", NamedTextColor.RED));
            endMatch(null);
        } else if (role == PlayerRole.HIDER && state == GameState.HUNT_PHASE) {
            checkWinConditions();
        }
    }

    public void giveLobbyBook(Player p) {
        p.getInventory().setItem(0, LeaderboardBook.build(stats));
    }

    /** Between-match lobby only: a player's own skinned head at hotbar slot 4 (profile viewer). */
    public void giveProfileHead(Player p) {
        p.getInventory().setItem(4, Kits.buildProfileHead(p));
    }

    private void teleportSafe(Player p, Location loc) {
        if (loc != null) p.teleport(loc);
    }

    // ---------------- Mid-match spectator state transitions ----------------

    /** Spectator (free-cam) -> adventure "mid-match lobby": join-as-seeker sword, spectate compass, book. */
    public void exitSpectatorToLobby(Player p) {
        if (!isMidMatch() || getRole(p) != PlayerRole.SPECTATOR) return;
        p.setGameMode(GameMode.ADVENTURE);
        teleportSafe(p, currentMap != null ? currentMap.lobby : waitingLocation());
        Kits.applyMidMatchLobbyHotbar(p, LeaderboardBook.build(stats));
    }

    /** Adventure "mid-match lobby" -> full spectator mode, spawned in the map. */
    public void enterSpectatorFromLobby(Player p) {
        if (!isMidMatch() || getRole(p) != PlayerRole.SPECTATOR) return;
        p.setGameMode(GameMode.SPECTATOR);
        teleportSafe(p, currentMap != null ? currentMap.start : waitingLocation());
        Kits.applySpectatorHotbar(p);
    }

    /** Adventure "mid-match lobby" -> jump into the hunt as an extra seeker. */
    public void joinAsSeekerMidMatch(Player p) {
        if (!isMidMatch() || getRole(p) != PlayerRole.SPECTATOR) return;
        roles.put(p.getUniqueId(), PlayerRole.SEEKER);
        p.setGameMode(GameMode.ADVENTURE);
        teleportSafe(p, currentMap.start);
        ItemStack[] seekerKit = kitManager.hasSeekerTemplate()
                ? kitManager.getSeekerTemplate() : Kits.buildDefaultSeekerKit(snowballGlowSeconds);
        Kits.applyKit(p, seekerKit);
        scoreboard.showNametag(p);
        roleCommandManager.runForSeeker(p);
        broadcast(Component.text(p.getName() + " joined the hunt as an extra seeker!", NamedTextColor.RED));
        p.playSound(p.getLocation(), Sound.ENTITY_WITHER_AMBIENT, 1f, 1f);
        updateScoreboard();
    }

    // ---------------- Heartbeat: drives WAITING -> COUNTDOWN ----------------

    private void startHeartbeat() {
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (state == GameState.WAITING) {
                int online = onlineNonSpectatorCount();
                if (online >= minPlayers && mapManager.hasAnyCompletedMap()) {
                    startCountdown();
                } else {
                    for (Player p : Bukkit.getOnlinePlayers()) {
                        if (getRole(p) == PlayerRole.NONE) {
                            Component msg = !mapManager.hasAnyCompletedMap()
                                    ? Component.text("Waiting for an admin to set up a map...", NamedTextColor.RED)
                                    : Component.text("Waiting for players " + online + "/" + maxWaitingDisplay,
                                    NamedTextColor.YELLOW);
                            p.sendActionBar(msg);
                        }
                    }
                    scoreboard.showWaiting("Waiting for players (" + online + "/" + maxWaitingDisplay + ")");
                }
            }
        }, 20L, 20L);
    }

    private int onlineNonSpectatorCount() {
        int c = 0;
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (getRole(p) == PlayerRole.NONE) c++;
        }
        return c;
    }

    // ---------------- COUNTDOWN ----------------

    private void startCountdown() {
        state = GameState.COUNTDOWN;
        secondsLeft = countdownSeconds;
        cancelTick();
        tickTask = new BukkitRunnable() {
            @Override public void run() {
                if (onlineNonSpectatorCount() < minPlayers) {
                    state = GameState.WAITING;
                    cancel();
                    return;
                }
                if (secondsLeft <= 0) {
                    cancel();
                    chooseMapThenReveal();
                    return;
                }
                NamedTextColor color = secondsLeft <= 5 ? NamedTextColor.RED
                        : secondsLeft <= 15 ? NamedTextColor.GOLD : NamedTextColor.GREEN;
                for (Player p : lobbyPlayers()) {
                    p.sendActionBar(Component.text("Match starting in " + secondsLeft + "s", color));
                    if (secondsLeft <= 5) {
                        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f,
                                secondsLeft == 0 ? 2f : 1f + (5 - secondsLeft) * 0.15f);
                    }
                }
                updateScoreboard();
                secondsLeft--;
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    private List<Player> lobbyPlayers() {
        List<Player> list = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (getRole(p) == PlayerRole.NONE) list.add(p);
        }
        return list;
    }

    // ---------------- MAP SPIN ----------------

    private void chooseMapThenReveal() {
        List<MapManager.MapData> pool = mapManager.completed();
        if (pool.isEmpty()) { state = GameState.WAITING; return; }

        if (pool.size() == 1) {
            currentMap = pool.get(0);
            beginRoleReveal();
            return;
        }

        state = GameState.MAP_SPIN;
        MapManager.MapData chosen = pool.get(new Random().nextInt(pool.size()));
        List<Player> players = lobbyPlayers();
        for (Player p : players) p.playSound(p.getLocation(), Sound.BLOCK_ENDER_CHEST_OPEN, 1f, 1f);

        final int totalTicks = roleSpinSeconds * 20;
        new BukkitRunnable() {
            int tick = 0;
            @Override public void run() {
                if (tick >= totalTicks) {
                    cancel();
                    currentMap = chosen;
                    for (Player p : players) {
                        p.showTitle(Title.title(
                                Component.text("Map Selected", NamedTextColor.GREEN, TextDecoration.BOLD),
                                Component.text(chosen.id, NamedTextColor.WHITE),
                                Title.Times.times(Duration.ofMillis(200), Duration.ofSeconds(2), Duration.ofMillis(400))));
                        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.4f);
                        teleportSafe(p, chosen.lobby);
                    }
                    Bukkit.getScheduler().runTaskLater(plugin, GameManager.this::beginRoleReveal, 40L);
                    return;
                }
                MapManager.MapData flash = pool.get((tick / 3) % pool.size());
                NamedTextColor color = SPIN_COLORS[(tick / 3) % SPIN_COLORS.length];
                for (Player p : players) {
                    p.showTitle(Title.title(
                            Component.text("Selecting Map...", NamedTextColor.GRAY),
                            Component.text(flash.id, color, TextDecoration.BOLD),
                            Title.Times.times(Duration.ZERO, Duration.ofMillis(200), Duration.ZERO)));
                    if (tick % 3 == 0) p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1.2f);
                }
                tick++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        broadcast(Component.text("Picking a map...", NamedTextColor.GOLD));
    }

    // ---------------- ROLE REVEAL (spin) ----------------

    private void beginRoleReveal() {
        state = GameState.ROLE_REVEAL;
        List<Player> pool = lobbyPlayers();
        if (pool.size() < minPlayers) { state = GameState.WAITING; return; }

        Player seeker = pool.get(new Random().nextInt(pool.size()));
        for (Player p : pool) {
            roles.put(p.getUniqueId(), p.equals(seeker) ? PlayerRole.SEEKER : PlayerRole.HIDER);
        }

        // Spin animation: rapidly flash HIDER/SEEKER titles for roleSpinSeconds, then land on real role
        final int totalTicks = roleSpinSeconds * 20;
        final int[] tick = {0};
        new BukkitRunnable() {
            @Override public void run() {
                if (tick[0] >= totalTicks) {
                    cancel();
                    for (Player p : pool) {
                        boolean isSeeker = getRole(p) == PlayerRole.SEEKER;
                        p.showTitle(Title.title(
                                isSeeker ? Component.text("SEEKER", NamedTextColor.RED, TextDecoration.BOLD)
                                        : Component.text("HIDER", NamedTextColor.AQUA, TextDecoration.BOLD),
                                Component.empty(),
                                Title.Times.times(Duration.ofMillis(100), Duration.ofSeconds(2), Duration.ofMillis(300))));
                        p.playSound(p.getLocation(),
                                isSeeker ? Sound.ENTITY_WITHER_AMBIENT : Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
                        // role assigned -> fire the configured /cmd set command for this role now
                        if (isSeeker) roleCommandManager.runForSeeker(p);
                        else roleCommandManager.runForHider(p);
                    }
                    Bukkit.getScheduler().runTaskLater(plugin, GameManager.this::startHidePhase, 40L);
                    return;
                }
                boolean flashSeeker = (tick[0] / 4) % 2 == 0;
                for (Player p : pool) {
                    p.showTitle(Title.title(
                            flashSeeker ? Component.text("SEEKER", NamedTextColor.RED, TextDecoration.BOLD)
                                    : Component.text("HIDER", NamedTextColor.AQUA, TextDecoration.BOLD),
                            Component.empty(),
                            Title.Times.times(Duration.ZERO, Duration.ofMillis(250), Duration.ZERO)));
                    if (tick[0] % 4 == 0) p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1.5f);
                }
                tick[0]++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        broadcast(Component.text("Roles are being decided...", NamedTextColor.GOLD));
    }

    // ---------------- HIDE PHASE ----------------

    private void startHidePhase() {
        state = GameState.HIDE_PHASE;
        caught.clear();

        ItemStack[] hiderKit = kitManager.hasHiderTemplate()
                ? kitManager.getHiderTemplate() : Kits.buildDefaultHiderKit(trollSeekerSeconds);

        for (Player p : Bukkit.getOnlinePlayers()) {
            PlayerRole role = getRole(p);
            p.getInventory().clear();
            plugin.getInteractListener().forgetSpectate(p);
            if (role == PlayerRole.HIDER) {
                teleportSafe(p, currentMap.start);
                Kits.applyKit(p, hiderKit);
                scoreboard.hideNametag(p);
                p.setGameMode(GameMode.ADVENTURE);
                stats.get(p.getUniqueId()).hiderRounds++;
            } else if (role == PlayerRole.SEEKER) {
                // trapped in lobby: keep them there, blind + immobile-ish
                teleportSafe(p, currentMap.lobby);
                p.setGameMode(GameMode.ADVENTURE);
                p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, hideSeconds * 20 + 20, 0, false, false));
                p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, hideSeconds * 20 + 20, 250, false, false));
                p.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, hideSeconds * 20 + 20, 128, false, false));
                stats.get(p.getUniqueId()).seekerRounds++;
            }
        }
        announceTitle(Component.text("Hide!", NamedTextColor.AQUA, TextDecoration.BOLD),
                Component.text("You have " + hideSeconds + "s", NamedTextColor.GRAY));

        secondsLeft = hideSeconds;
        cancelTick();
        tickTask = new BukkitRunnable() {
            @Override public void run() {
                if (secondsLeft <= 0) {
                    cancel();
                    startHuntPhase();
                    return;
                }
                for (Player p : allActive()) {
                    p.sendActionBar(Component.text("Hide! " + secondsLeft + "s", NamedTextColor.AQUA));
                }
                updateScoreboard();
                secondsLeft--;
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    // ---------------- HUNT PHASE ----------------

    private void startHuntPhase() {
        state = GameState.HUNT_PHASE;
        Player seeker = getSeeker();
        if (seeker != null) {
            seeker.removePotionEffect(PotionEffectType.BLINDNESS);
            seeker.removePotionEffect(PotionEffectType.SLOWNESS);
            seeker.removePotionEffect(PotionEffectType.JUMP_BOOST);
            teleportSafe(seeker, currentMap.start);
            ItemStack[] seekerKit = kitManager.hasSeekerTemplate()
                    ? kitManager.getSeekerTemplate() : Kits.buildDefaultSeekerKit(snowballGlowSeconds);
            Kits.applyKit(seeker, seekerKit);
            seeker.playSound(seeker.getLocation(), Sound.ENTITY_WITHER_SPAWN, 1f, 1f);
        }
        broadcastRoleTags();
        announceTitle(Component.text("HUNT!", NamedTextColor.RED, TextDecoration.BOLD),
                Component.text("The seeker has been released!", NamedTextColor.GRAY));

        matchBossBar = BossBar.bossBar(Component.text("Match Time", NamedTextColor.GREEN), 1f,
                BossBar.Color.GREEN, BossBar.Overlay.NOTCHED_10);
        for (Player p : allActive()) p.showBossBar(matchBossBar);

        updateScoreboard();

        secondsLeft = matchSeconds;
        cancelTick();
        tickTask = new BukkitRunnable() {
            @Override public void run() {
                if (secondsLeft <= 0) {
                    cancel();
                    endMatch(PlayerRole.HIDER);
                    return;
                }
                float frac = Math.max(0f, (float) secondsLeft / matchSeconds);
                matchBossBar.progress(frac);
                matchBossBar.color(frac > 0.5f ? BossBar.Color.GREEN : frac > 0.2f ? BossBar.Color.YELLOW : BossBar.Color.RED);
                matchBossBar.name(Component.text("Match Time: " + formatTime(secondsLeft), NamedTextColor.GOLD));
                updateScoreboard();
                secondsLeft--;
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    private String formatTime(int totalSeconds) {
        int m = totalSeconds / 60, s = totalSeconds % 60;
        return String.format("%d:%02d", m, s);
    }

    private void broadcastRoleTags() {
        for (Player p : allActive()) {
            PlayerRole r = getRole(p);
            if (r == PlayerRole.SEEKER) {
                broadcast(Component.text(p.getName() + " is the ", NamedTextColor.GRAY)
                        .append(Component.text("SEEKER", NamedTextColor.RED, TextDecoration.BOLD)));
            } else if (r == PlayerRole.HIDER) {
                broadcast(Component.text(p.getName() + " is a ", NamedTextColor.GRAY)
                        .append(Component.text("HIDER", NamedTextColor.AQUA, TextDecoration.BOLD)));
            }
        }
    }

    // ---------------- Hider caught ----------------

    public void onHiderCaught(Player hider, Player seeker) {
        if (state != GameState.HUNT_PHASE) return;
        if (getRole(hider) != PlayerRole.HIDER) return;

        caught.add(hider.getUniqueId());
        roles.put(hider.getUniqueId(), PlayerRole.SPECTATOR);
        plugin.getInteractListener().forgetSpectate(hider);
        hider.setGameMode(GameMode.SPECTATOR);
        scoreboard.showNametag(hider);
        Kits.applySpectatorHotbar(hider);
        if (matchBossBar != null) hider.hideBossBar(matchBossBar);

        broadcast(Component.text(hider.getName() + " was caught by the seeker!", NamedTextColor.RED));
        for (Player p : allActive()) p.playSound(p.getLocation(), Sound.BLOCK_ANVIL_LAND, 0.7f, 1.2f);
        if (seeker != null) stats.get(seeker.getUniqueId()).catches++;

        updateScoreboard();
        checkWinConditions();
    }

    private void checkWinConditions() {
        if (state != GameState.HUNT_PHASE) return;
        List<Player> remaining = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (getRole(p) == PlayerRole.HIDER) remaining.add(p);
        }
        if (remaining.isEmpty()) {
            endMatch(PlayerRole.SEEKER);
        }
    }

    // ---------------- End / restart ----------------

    private void endMatch(PlayerRole winner) {
        cancelTick();
        state = GameState.ENDING;

        if (matchBossBar != null) {
            for (Player p : Bukkit.getOnlinePlayers()) p.hideBossBar(matchBossBar);
            matchBossBar = null;
        }

        if (winner == PlayerRole.HIDER) {
            broadcast(Component.text("Time's up! The hiders win!", NamedTextColor.AQUA, TextDecoration.BOLD));
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (getRole(p) == PlayerRole.HIDER) stats.get(p.getUniqueId()).hiderWins++;
            }
        } else if (winner == PlayerRole.SEEKER) {
            broadcast(Component.text("All hiders caught! The seeker wins!", NamedTextColor.RED, TextDecoration.BOLD));
            for (Player s : getSeekers()) stats.get(s.getUniqueId()).seekerWins++;
        } else {
            broadcast(Component.text("Match ended.", NamedTextColor.GRAY));
        }
        stats.save();
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
        }

        Location returnTo = currentMap != null ? currentMap.lobby : waitingLocation();
        for (Player p : Bukkit.getOnlinePlayers()) {
            scoreboard.showNametag(p);
            p.setGameMode(GameMode.ADVENTURE);
            teleportSafe(p, returnTo);
            p.getInventory().clear();
            roles.put(p.getUniqueId(), PlayerRole.NONE);
            giveLobbyBook(p);
            giveProfileHead(p);
        }

        secondsLeft = nextMatchSeconds;
        tickTask = new BukkitRunnable() {
            @Override public void run() {
                if (secondsLeft <= 0) {
                    cancel();
                    state = GameState.WAITING;
                    return;
                }
                for (Player p : Bukkit.getOnlinePlayers()) {
                    p.sendActionBar(Component.text("Next match in " + secondsLeft + "s", NamedTextColor.GREEN));
                }
                scoreboard.showWaiting("Next match in " + secondsLeft + "s");
                secondsLeft--;
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    public void forceStop() {
        cancelTick();
        if (matchBossBar != null) {
            for (Player p : Bukkit.getOnlinePlayers()) p.hideBossBar(matchBossBar);
            matchBossBar = null;
        }
        Location returnTo = waitingLocation();
        for (Player p : Bukkit.getOnlinePlayers()) {
            scoreboard.showNametag(p);
            p.setGameMode(GameMode.ADVENTURE);
            teleportSafe(p, returnTo);
            p.getInventory().clear();
            roles.put(p.getUniqueId(), PlayerRole.NONE);
            giveLobbyBook(p);
            giveProfileHead(p);
        }
        state = GameState.WAITING;
    }

    public void forceStart() {
        if (state == GameState.WAITING && mapManager.hasAnyCompletedMap() && onlineNonSpectatorCount() >= minPlayers) {
            cancelTick();
            startCountdown();
        }
    }

    private void cancelTick() {
        if (tickTask != null) { tickTask.cancel(); tickTask = null; }
    }

    // ---------------- helpers ----------------

    public Player getSeeker() {
        for (Map.Entry<UUID, PlayerRole> e : roles.entrySet()) {
            if (e.getValue() == PlayerRole.SEEKER) {
                Player p = Bukkit.getPlayer(e.getKey());
                if (p != null) return p;
            }
        }
        return null;
    }

    public List<Player> getSeekers() {
        List<Player> list = new ArrayList<>();
        for (Map.Entry<UUID, PlayerRole> e : roles.entrySet()) {
            if (e.getValue() == PlayerRole.SEEKER) {
                Player p = Bukkit.getPlayer(e.getKey());
                if (p != null) list.add(p);
            }
        }
        return list;
    }

    public List<Player> getAliveHiders() {
        List<Player> list = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (getRole(p) == PlayerRole.HIDER) list.add(p);
        }
        return list;
    }

    private List<Player> allActive() {
        List<Player> list = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            PlayerRole r = getRole(p);
            if (r == PlayerRole.HIDER || r == PlayerRole.SEEKER) list.add(p);
        }
        return list;
    }

    public void updateScoreboard() {
        List<Player> alive = new ArrayList<>(), dead = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (getRole(p) == PlayerRole.HIDER) alive.add(p);
        }
        for (UUID id : caught) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) dead.add(p);
        }
        String mapName = currentMap != null ? currentMap.id : null;
        String phase = switch (state) {
            case COUNTDOWN -> "Starting";
            case MAP_SPIN -> "Picking Map";
            case ROLE_REVEAL -> "Assigning Roles";
            case HIDE_PHASE -> "Hiding";
            case HUNT_PHASE -> "Hunting";
            case ENDING -> "Match Over";
            default -> "Waiting";
        };
        String timer = secondsLeft >= 0 && (state == GameState.HUNT_PHASE || state == GameState.HIDE_PHASE
                || state == GameState.COUNTDOWN || state == GameState.ENDING)
                ? formatTime(secondsLeft) : null;
        scoreboard.update(mapName, phase, timer, getSeekers(), alive, dead);
    }

    public void broadcast(Component msg) {
        Component full = PREFIX.append(msg);
        for (Player p : Bukkit.getOnlinePlayers()) p.sendMessage(full);
    }

    public void announceTitle(Component title, Component subtitle) {
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.showTitle(Title.title(title, subtitle,
                    Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(2), Duration.ofMillis(500))));
        }
    }

    public int getMinPlayers() { return minPlayers; }
    public int getSnowballGlowSeconds() { return snowballGlowSeconds; }
    public int getTrollSeekerSeconds() { return trollSeekerSeconds; }
}
