package com.hs.commands;

import com.hs.HideAndSeekPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class CmdCommand implements CommandExecutor {

    private final HideAndSeekPlugin plugin;

    public CmdCommand(HideAndSeekPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("hs.admin")) {
            sender.sendMessage(Component.text("You don't have permission.", NamedTextColor.RED));
            return true;
        }
        if (args.length < 3 || !args[0].equalsIgnoreCase("set")
                || !(args[1].equalsIgnoreCase("seeker") || args[1].equalsIgnoreCase("hider"))) {
            sender.sendMessage(Component.text("Usage: /cmd set <seeker|hider> <command>", NamedTextColor.RED));
            sender.sendMessage(Component.text("Example: /cmd set seeker effect give %player% speed 999999 2", NamedTextColor.GRAY));
            return true;
        }

        StringBuilder sb = new StringBuilder();
        for (int i = 2; i < args.length; i++) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(args[i]);
        }
        String cmd = sb.toString();
        // strip a leading slash if they typed one
        if (cmd.startsWith("/")) cmd = cmd.substring(1);

        if (args[1].equalsIgnoreCase("seeker")) {
            plugin.getRoleCommandManager().setSeekerCommand(cmd);
            sender.sendMessage(Component.text("Seeker role command set to: /" + cmd, NamedTextColor.GREEN));
        } else {
            plugin.getRoleCommandManager().setHiderCommand(cmd);
            sender.sendMessage(Component.text("Hider role command set to: /" + cmd, NamedTextColor.GREEN));
        }
        sender.sendMessage(Component.text("It will run for a player the moment they're assigned that role " +
                "(use %player% for their name).", NamedTextColor.GRAY));
        return true;
    }
}
