package com.hs.commands;

import com.hs.HideAndSeekPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class HsCommand implements CommandExecutor {

    private final HideAndSeekPlugin plugin;

    public HsCommand(HideAndSeekPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("hs.admin")) {
            sender.sendMessage(Component.text("You don't have permission.", NamedTextColor.RED));
            return true;
        }
        if (args.length != 1) {
            sender.sendMessage(Component.text("Usage: /hs <forcestart|stop>", NamedTextColor.RED));
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "forcestart" -> {
                plugin.getGameManager().forceStart();
                sender.sendMessage(Component.text("Attempting to force-start the match.", NamedTextColor.GREEN));
            }
            case "stop" -> {
                plugin.getGameManager().forceStop();
                sender.sendMessage(Component.text("Match stopped, everyone returned to lobby.", NamedTextColor.GREEN));
            }
            default -> sender.sendMessage(Component.text("Usage: /hs <forcestart|stop>", NamedTextColor.RED));
        }
        return true;
    }
}
