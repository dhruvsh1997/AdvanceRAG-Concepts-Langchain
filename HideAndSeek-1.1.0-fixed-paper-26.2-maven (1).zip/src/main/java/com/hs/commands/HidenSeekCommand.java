package com.hs.commands;

import com.hs.HideAndSeekPlugin;
import com.hs.data.MapManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class HidenSeekCommand implements CommandExecutor {

    private final HideAndSeekPlugin plugin;

    public HidenSeekCommand(HideAndSeekPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Players only.");
            return true;
        }
        if (!p.hasPermission("hs.admin")) {
            p.sendMessage(Component.text("You don't have permission.", NamedTextColor.RED));
            return true;
        }

        // /hidenseek setup <map id, can contain spaces> <start|lobby>
        if (args.length < 3 || !args[0].equalsIgnoreCase("setup")) {
            p.sendMessage(Component.text("Usage: /hidenseek setup <map id> <start|lobby>", NamedTextColor.RED));
            p.sendMessage(Component.text("Example: /hidenseek setup hide n seek 1 start", NamedTextColor.GRAY));
            return true;
        }

        String point = args[args.length - 1];
        if (!point.equalsIgnoreCase("start") && !point.equalsIgnoreCase("lobby")) {
            p.sendMessage(Component.text("Last word must be 'start' or 'lobby'.", NamedTextColor.RED));
            return true;
        }

        StringBuilder idBuilder = new StringBuilder();
        for (int i = 1; i < args.length - 1; i++) {
            if (idBuilder.length() > 0) idBuilder.append(' ');
            idBuilder.append(args[i]);
        }
        String mapId = idBuilder.toString().trim();
        if (mapId.isEmpty()) {
            p.sendMessage(Component.text("You must give a map id, e.g. /hidenseek setup hide n seek 1 start", NamedTextColor.RED));
            return true;
        }

        MapManager mapManager = plugin.getMapManager();
        MapManager.MapData data;
        if (point.equalsIgnoreCase("start")) {
            data = mapManager.setStart(mapId, p.getLocation());
        } else {
            data = mapManager.setLobby(mapId, p.getLocation());
        }

        p.sendMessage(Component.text("Set " + point.toLowerCase() + " for map \"" + mapId + "\".", NamedTextColor.GREEN));
        if (data.isComplete()) {
            p.sendMessage(Component.text("Map \"" + mapId + "\" setup complete! It's now in the map pool.", NamedTextColor.AQUA));
        } else {
            p.sendMessage(Component.text("Still need to set the " +
                    (point.equalsIgnoreCase("start") ? "lobby" : "start") + " for this map.", NamedTextColor.YELLOW));
        }
        return true;
    }
}
