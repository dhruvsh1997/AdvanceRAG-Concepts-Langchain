package com.hs.commands;

import com.hs.HideAndSeekPlugin;
import com.hs.gui.KitEditHolder;
import com.hs.util.Kits;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class InvCommand implements CommandExecutor {

    private final HideAndSeekPlugin plugin;

    public InvCommand(HideAndSeekPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Players only.");
            return true;
        }
        if (!p.hasPermission("hs.admin")) {
            p.sendMessage(Component.text("You don't have permission.", NamedTextColor.RED));
            return true;
        }
        if (args.length != 2 || !args[0].equalsIgnoreCase("edit")) {
            p.sendMessage(Component.text("Usage: /inv edit <seeker|hider>", NamedTextColor.RED));
            return true;
        }

        String roleArg = args[1].toLowerCase();
        KitEditHolder.Role role;
        ItemStack[] template;
        String title;
        if (roleArg.equals("seeker")) {
            role = KitEditHolder.Role.SEEKER;
            template = plugin.getKitManager().hasSeekerTemplate()
                    ? plugin.getKitManager().getSeekerTemplate()
                    : Kits.buildDefaultSeekerKit(plugin.getGameManager().getSnowballGlowSeconds());
            title = "Edit Seeker Kit";
        } else if (roleArg.equals("hider")) {
            role = KitEditHolder.Role.HIDER;
            template = plugin.getKitManager().hasHiderTemplate()
                    ? plugin.getKitManager().getHiderTemplate()
                    : Kits.buildDefaultHiderKit(plugin.getGameManager().getTrollSeekerSeconds());
            title = "Edit Hider Kit";
        } else {
            p.sendMessage(Component.text("Usage: /inv edit <seeker|hider>", NamedTextColor.RED));
            return true;
        }

        KitEditHolder holder = new KitEditHolder(role);
        Inventory inv = Bukkit.createInventory(holder, 36,
                Component.text(title, NamedTextColor.DARK_AQUA));
        holder.setInventory(inv);
        for (int i = 0; i < 36 && i < template.length; i++) {
            if (template[i] != null) inv.setItem(i, template[i]);
        }
        p.openInventory(inv);
        p.sendMessage(Component.text("Edit freely and close the chest to save.", NamedTextColor.GRAY));
        return true;
    }
}
