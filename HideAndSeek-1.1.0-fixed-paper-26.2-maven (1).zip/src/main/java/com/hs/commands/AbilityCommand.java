package com.hs.commands;

import com.hs.HideAndSeekPlugin;
import com.hs.gui.AbilityViewHolder;
import com.hs.util.Kits;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public class AbilityCommand implements CommandExecutor {

    private final HideAndSeekPlugin plugin;

    public AbilityCommand(HideAndSeekPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Players only.");
            return true;
        }
        if (!p.hasPermission("hs.admin")) {
            p.sendMessage(Component.text("You don't have permission.", NamedTextColor.RED));
            return true;
        }
        if (args.length != 1 || !args[0].equalsIgnoreCase("items")) {
            p.sendMessage(Component.text("Usage: /ability items", NamedTextColor.RED));
            return true;
        }

        AbilityViewHolder holder = new AbilityViewHolder();
        Inventory inv = Bukkit.createInventory(holder, 27,
                Component.text("Ability Items (view only)", NamedTextColor.DARK_PURPLE));
        holder.setInventory(inv);

        List<ItemStack> items = Kits.allAbilityItems(
                plugin.getGameManager().getSnowballGlowSeconds(),
                plugin.getGameManager().getTrollSeekerSeconds());
        for (int i = 0; i < items.size() && i < 27; i++) {
            inv.setItem(i, items.get(i));
        }
        p.openInventory(inv);
        return true;
    }
}
