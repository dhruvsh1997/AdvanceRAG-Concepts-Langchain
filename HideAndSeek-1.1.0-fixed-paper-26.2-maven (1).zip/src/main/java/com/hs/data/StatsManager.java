package com.hs.data;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class StatsManager {

    private final JavaPlugin plugin;
    private final File file;
    private FileConfiguration cfg;
    private final Map<UUID, PlayerStats> cache = new HashMap<>();

    public StatsManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "stats.yml");
        load();
    }

    private void load() {
        if (!file.exists()) {
            try {
                plugin.getDataFolder().mkdirs();
                file.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().warning("Could not create stats.yml: " + e.getMessage());
            }
        }
        cfg = YamlConfiguration.loadConfiguration(file);
        cache.clear();
        if (cfg.contains("players")) {
            for (String key : Objects.requireNonNull(cfg.getConfigurationSection("players")).getKeys(false)) {
                UUID id = UUID.fromString(key);
                PlayerStats s = new PlayerStats();
                String base = "players." + key + ".";
                s.hiderWins = cfg.getInt(base + "hiderWins", 0);
                s.seekerWins = cfg.getInt(base + "seekerWins", 0);
                s.hiderRounds = cfg.getInt(base + "hiderRounds", 0);
                s.seekerRounds = cfg.getInt(base + "seekerRounds", 0);
                s.catches = cfg.getInt(base + "catches", 0);
                s.survives = cfg.getInt(base + "survives", 0);
                cache.put(id, s);
            }
        }
    }

    public void save() {
        for (Map.Entry<UUID, PlayerStats> e : cache.entrySet()) {
            String base = "players." + e.getKey() + ".";
            PlayerStats s = e.getValue();
            cfg.set(base + "hiderWins", s.hiderWins);
            cfg.set(base + "seekerWins", s.seekerWins);
            cfg.set(base + "hiderRounds", s.hiderRounds);
            cfg.set(base + "seekerRounds", s.seekerRounds);
            cfg.set(base + "catches", s.catches);
            cfg.set(base + "survives", s.survives);
        }
        try {
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save stats.yml: " + e.getMessage());
        }
    }

    public PlayerStats get(UUID uuid) {
        return cache.computeIfAbsent(uuid, k -> new PlayerStats());
    }

    /** Top N hiders by hiderWins, returns list of [name-uuid, stats] sorted desc. */
    public List<Map.Entry<UUID, PlayerStats>> topHiders(int n) {
        List<Map.Entry<UUID, PlayerStats>> list = new ArrayList<>(cache.entrySet());
        list.sort((a, b) -> Integer.compare(b.getValue().hiderWins, a.getValue().hiderWins));
        return list.subList(0, Math.min(n, list.size()));
    }

    public List<Map.Entry<UUID, PlayerStats>> topSeekers(int n) {
        List<Map.Entry<UUID, PlayerStats>> list = new ArrayList<>(cache.entrySet());
        list.sort((a, b) -> Integer.compare(b.getValue().seekerWins, a.getValue().seekerWins));
        return list.subList(0, Math.min(n, list.size()));
    }
}
