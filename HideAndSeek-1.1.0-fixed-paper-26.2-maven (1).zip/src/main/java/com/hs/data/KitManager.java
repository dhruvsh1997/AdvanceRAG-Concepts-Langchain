package com.hs.data;

import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/** Stores custom seeker/hider kit templates (36 slots, matching a player's main inventory)
 *  that ops can edit in-game via /inv edit. Falls back to null (caller uses the plugin's
 *  hardcoded default kit) when no custom template has been saved yet. */
public class KitManager {

    public static final int SIZE = 36;

    private final JavaPlugin plugin;
    private final File file;
    private ItemStack[] seekerTemplate; // null if not customized
    private ItemStack[] hiderTemplate;

    public KitManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "kits.yml");
        load();
    }

    private void load() {
        if (!file.exists()) return;
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        seekerTemplate = readList(cfg, "seeker");
        hiderTemplate = readList(cfg, "hider");
    }

    private ItemStack[] readList(FileConfiguration cfg, String path) {
        if (!cfg.contains(path)) return null;
        List<?> raw = cfg.getList(path);
        if (raw == null) return null;
        ItemStack[] arr = new ItemStack[SIZE];
        for (int i = 0; i < SIZE && i < raw.size(); i++) {
            Object o = raw.get(i);
            if (o instanceof ItemStack it && it.getType() != Material.AIR) {
                arr[i] = it;
            }
        }
        return arr;
    }

    public void saveSeeker(ItemStack[] contents) {
        seekerTemplate = clone(contents);
        persist();
    }

    public void saveHider(ItemStack[] contents) {
        hiderTemplate = clone(contents);
        persist();
    }

    private ItemStack[] clone(ItemStack[] contents) {
        ItemStack[] copy = new ItemStack[SIZE];
        for (int i = 0; i < SIZE && i < contents.length; i++) {
            copy[i] = contents[i] == null ? null : contents[i].clone();
        }
        return copy;
    }

    private void persist() {
        FileConfiguration cfg = new YamlConfiguration();
        writeList(cfg, "seeker", seekerTemplate);
        writeList(cfg, "hider", hiderTemplate);
        try {
            plugin.getDataFolder().mkdirs();
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save kits.yml: " + e.getMessage());
        }
    }

    private void writeList(FileConfiguration cfg, String path, ItemStack[] arr) {
        if (arr == null) return;
        List<ItemStack> list = new ArrayList<>();
        for (ItemStack it : arr) {
            list.add(it == null ? new ItemStack(Material.AIR) : it);
        }
        cfg.set(path, list);
    }

    public ItemStack[] getSeekerTemplate() { return seekerTemplate == null ? null : clone(seekerTemplate); }
    public ItemStack[] getHiderTemplate() { return hiderTemplate == null ? null : clone(hiderTemplate); }
    public boolean hasSeekerTemplate() { return seekerTemplate != null; }
    public boolean hasHiderTemplate() { return hiderTemplate != null; }
}
