package com.hs.data;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class MapManager {

    public static class MapData {
        public final String id; // display id, e.g. "hide n seek 1"
        public Location start;
        public Location lobby;

        public MapData(String id) { this.id = id; }

        public boolean isComplete() { return start != null && lobby != null; }
    }

    private final JavaPlugin plugin;
    private final File file;
    private final Map<String, MapData> maps = new LinkedHashMap<>(); // key = id.toLowerCase()

    public MapManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "maps.yml");
        load();
    }

    private void load() {
        if (!file.exists()) {
            try {
                plugin.getDataFolder().mkdirs();
                file.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().warning("Could not create maps.yml: " + e.getMessage());
            }
        }
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        maps.clear();
        List<Map<?, ?>> list = cfg.getMapList("maps");
        for (Map<?, ?> raw : list) {
            String id = String.valueOf(raw.get("id"));
            MapData data = new MapData(id);
            data.start = deserialize(raw.get("start"));
            data.lobby = deserialize(raw.get("lobby"));
            maps.put(id.toLowerCase(Locale.ROOT), data);
        }
    }

    public void save() {
        FileConfiguration cfg = new YamlConfiguration();
        List<Map<String, Object>> list = new ArrayList<>();
        for (MapData d : maps.values()) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id", d.id);
            if (d.start != null) m.put("start", serialize(d.start));
            if (d.lobby != null) m.put("lobby", serialize(d.lobby));
            list.add(m);
        }
        cfg.set("maps", list);
        try {
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save maps.yml: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private Location deserialize(Object raw) {
        if (!(raw instanceof Map)) return null;
        try {
            Map<String, Object> m = (Map<String, Object>) raw;
            World w = Bukkit.getWorld((String) m.get("world"));
            if (w == null) return null;
            return new Location(w, ((Number) m.get("x")).doubleValue(), ((Number) m.get("y")).doubleValue(),
                    ((Number) m.get("z")).doubleValue(),
                    ((Number) m.getOrDefault("yaw", 0)).floatValue(),
                    ((Number) m.getOrDefault("pitch", 0)).floatValue());
        } catch (Exception e) {
            return null;
        }
    }

    private Map<String, Object> serialize(Location loc) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("world", loc.getWorld().getName());
        m.put("x", loc.getX());
        m.put("y", loc.getY());
        m.put("z", loc.getZ());
        m.put("yaw", loc.getYaw());
        m.put("pitch", loc.getPitch());
        return m;
    }

    /** Sets the start point for a map id, creating the map entry if it doesn't exist yet. */
    public MapData setStart(String id, Location loc) {
        MapData d = maps.computeIfAbsent(id.toLowerCase(Locale.ROOT), k -> new MapData(id));
        d.start = loc.clone();
        save();
        return d;
    }

    public MapData setLobby(String id, Location loc) {
        MapData d = maps.computeIfAbsent(id.toLowerCase(Locale.ROOT), k -> new MapData(id));
        d.lobby = loc.clone();
        save();
        return d;
    }

    public MapData get(String id) {
        return maps.get(id.toLowerCase(Locale.ROOT));
    }

    public Collection<MapData> all() {
        return maps.values();
    }

    public List<MapData> completed() {
        List<MapData> list = new ArrayList<>();
        for (MapData d : maps.values()) if (d.isComplete()) list.add(d);
        return list;
    }

    public MapData randomCompleted() {
        List<MapData> list = completed();
        if (list.isEmpty()) return null;
        return list.get(new Random().nextInt(list.size()));
    }

    public boolean hasAnyCompletedMap() {
        return !completed().isEmpty();
    }
}
