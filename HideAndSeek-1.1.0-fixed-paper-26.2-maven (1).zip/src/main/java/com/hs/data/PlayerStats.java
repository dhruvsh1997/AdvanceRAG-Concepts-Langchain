package com.hs.data;

public class PlayerStats {
    public int hiderWins = 0;
    public int seekerWins = 0;
    public int hiderRounds = 0;
    public int seekerRounds = 0;
    public int catches = 0; // times this player caught a hider (as seeker)
    public int survives = 0; // times this player survived a full match as hider
}
