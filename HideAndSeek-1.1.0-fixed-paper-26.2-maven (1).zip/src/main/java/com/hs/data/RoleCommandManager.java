package com.hs.data;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;

/** Stores a console command to run (once) whenever a player is assigned the SEEKER or HIDER role,
 *  set in-game via /cmd set <seeker|hider> <command>. %player% in the stored command is replaced
 *  with the player's name. */
public class RoleCommandManager {

    private final JavaPlugin plugin;
    private final File file;
    private String seekerCommand;
    private String hiderCommand;

    public RoleCommandManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "role-commands.yml");
        load();
    }

    private void load() {
        if (!file.exists()) return;
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        seekerCommand = cfg.getString("seeker", null);
        hiderCommand = cfg.getString("hider", null);
    }

    private void save() {
        FileConfiguration cfg = new YamlConfiguration();
        if (seekerCommand != null) cfg.set("seeker", seekerCommand);
        if (hiderCommand != null) cfg.set("hider", hiderCommand);
        try {
            plugin.getDataFolder().mkdirs();
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save role-commands.yml: " + e.getMessage());
        }
    }

    public void setSeekerCommand(String cmd) { seekerCommand = cmd; save(); }
    public void setHiderCommand(String cmd) { hiderCommand = cmd; save(); }
    public String getSeekerCommand() { return seekerCommand; }
    public String getHiderCommand() { return hiderCommand; }

    public void runForSeeker(Player p) { run(seekerCommand, p); }
    public void runForHider(Player p) { run(hiderCommand, p); }

    private void run(String template, Player p) {
        if (template == null || template.isBlank()) return;
        String resolved = template.replace("%player%", p.getName());
        Bukkit.getScheduler().runTask(plugin, () ->
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), resolved));
    }
}
