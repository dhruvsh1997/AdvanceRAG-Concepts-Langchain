package com.hs;

public enum PlayerRole {
    NONE,       // in lobby, waiting, or joined mid-match (spectator)
    HIDER,
    SEEKER,
    SPECTATOR   // died, or joined mid-match
}
