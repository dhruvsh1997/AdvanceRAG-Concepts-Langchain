package com.hs.gui;

import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Chest GUI listing alive hiders and the seeker(s) as heads; clicking a head teleports the
 *  viewing spectator to that player. */
public class SpectatorListHolder implements InventoryHolder {

    private Inventory inventory;
    private final Map<Integer, UUID> slotTargets = new HashMap<>();

    public void setInventory(Inventory inventory) { this.inventory = inventory; }

    @Override
    public Inventory getInventory() { return inventory; }

    public void setTarget(int slot, Player target) { slotTargets.put(slot, target.getUniqueId()); }

    public UUID getTarget(int slot) { return slotTargets.get(slot); }
}
