package com.hs.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class KitEditHolder implements InventoryHolder {

    public enum Role { SEEKER, HIDER }

    private final Role role;
    private Inventory inventory;

    public KitEditHolder(Role role) {
        this.role = role;
    }

    public Role getRole() { return role; }

    public void setInventory(Inventory inventory) { this.inventory = inventory; }

    @Override
    public Inventory getInventory() { return inventory; }
}
