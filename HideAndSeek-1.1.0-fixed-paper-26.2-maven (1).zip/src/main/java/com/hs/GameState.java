package com.hs;

public enum GameState {
    WAITING,        // < min players, or not enough to start countdown
    COUNTDOWN,      // pre-match countdown, still joinable
    MAP_SPIN,       // spinning to pick which map this match uses (only if 2+ completed maps)
    ROLE_REVEAL,    // 5s title/spin animation
    HIDE_PHASE,     // hiders free, seeker trapped in lobby
    HUNT_PHASE,     // seeker hunting, 8 min match timer
    ENDING          // match over, showing results, next-match countdown
}
