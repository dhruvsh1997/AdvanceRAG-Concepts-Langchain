package com.hs;

import com.hs.commands.AbilityCommand;
import com.hs.commands.CmdCommand;
import com.hs.commands.HidenSeekCommand;
import com.hs.commands.HsCommand;
import com.hs.commands.InvCommand;
import com.hs.data.KitManager;
import com.hs.data.MapManager;
import com.hs.data.RoleCommandManager;
import com.hs.listeners.GameListener;
import com.hs.listeners.GuiListener;
import com.hs.listeners.InteractListener;
import com.hs.listeners.SpectatorListener;
import com.hs.util.Kits;
import org.bukkit.NamespacedKey;
import org.bukkit.plugin.java.JavaPlugin;

public class HideAndSeekPlugin extends JavaPlugin {

    private MapManager mapManager;
    private KitManager kitManager;
    private RoleCommandManager roleCommandManager;
    private GameManager gameManager;
    private InteractListener interactListener;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        Kits.KEY_ITEM_ID = new NamespacedKey(this, "item_id");
        Kits.KEY_STICK_USES = new NamespacedKey(this, "stick_uses");

        mapManager = new MapManager(this);
        kitManager = new KitManager(this);
        roleCommandManager = new RoleCommandManager(this);
        gameManager = new GameManager(this, mapManager, kitManager, roleCommandManager);

        interactListener = new InteractListener(this);
        getServer().getPluginManager().registerEvents(new GameListener(this), this);
        getServer().getPluginManager().registerEvents(interactListener, this);
        getServer().getPluginManager().registerEvents(new GuiListener(this), this);
        getServer().getPluginManager().registerEvents(new SpectatorListener(this), this);

        getCommand("hidenseek").setExecutor(new HidenSeekCommand(this));
        getCommand("hs").setExecutor(new HsCommand(this));
        getCommand("inv").setExecutor(new InvCommand(this));
        getCommand("ability").setExecutor(new AbilityCommand(this));
        getCommand("cmd").setExecutor(new CmdCommand(this));

        getLogger().info("HideAndSeek enabled.");
    }

    @Override
    public void onDisable() {
        if (gameManager != null) {
            gameManager.forceStop();
            gameManager.getStats().save();
        }
    }

    public GameManager getGameManager() { return gameManager; }
    public InteractListener getInteractListener() { return interactListener; }
    public MapManager getMapManager() { return mapManager; }
    public KitManager getKitManager() { return kitManager; }
    public RoleCommandManager getRoleCommandManager() { return roleCommandManager; }
}
