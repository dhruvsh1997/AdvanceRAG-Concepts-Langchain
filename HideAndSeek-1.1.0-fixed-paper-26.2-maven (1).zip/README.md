# HideAndSeek Plugin (Paper 26.2)

## Build

Requires Java 25 and Maven. This project targets Paper 26.2 and has been
compiled successfully with Maven:

```
mvn clean package
```

The finished JAR will be at `target/HideAndSeek.jar`. Copy it into your Paper
server's `plugins/` folder and restart the server.

## Setup — multiple maps

There's no `/set` command anymore. Instead, every map gets its own id, and you can set up as many
maps as you like:

```
/hidenseek setup hide n seek 1 start
/hidenseek setup hide n seek 1 lobby
/hidenseek setup hide n seek 2 start
/hidenseek setup hide n seek 2 lobby
```

A map id can contain spaces — everything between `setup` and the trailing `start`/`lobby` is the id.
A map only enters the map pool once *both* its start and lobby points are set; the plugin tells you
in chat when a map becomes complete.

With 2+ completed maps, every match opens with a **map-selection spin** (flashing map names in random
colors) before the hider/seeker role spin. With exactly 1 completed map, that map is just used
directly and the map spin is skipped.

## Commands

- `/hidenseek setup <map id> <start|lobby>` — set a map's spawn or lobby point (op only)
- `/hs forcestart` — force-starts the countdown early (op only)
- `/hs stop` — force-ends the current match, returns everyone to the lobby (op only)
- `/inv edit <seeker|hider>` — opens a 36-slot chest pre-filled with that role's current kit; drop
  items in, take items out, rearrange freely, and closing the chest saves it as the new kit template
  for every future match (op only)
- `/ability items` — opens a view-only chest showing one of every ability item in the plugin, for
  reference (op only)

## How it plays

- **Waiting**: with < 2 players, players see `Waiting for players X/35` in their action bar (or a
  warning if no map has been set up yet).
- **Countdown**: once 2+ players are around, a 60s countdown runs in the action bar, turning gold at
  15s and red with a rising pitch "tick" sound in the last 5s.
- **Map spin** *(only with 2+ completed maps)*: a ~5s flashing title cycles through map names in
  different colors, lands on the chosen map, then teleports everyone to that map's lobby.
- **Role reveal**: a 5s flashing HIDER/SEEKER title "spin" plays, then everyone's real role is shown
  (cyan HIDER / red SEEKER), each with its own reveal sound.
- **Hide phase (60s)**: hiders are teleported to the map's start point and given their kit; the
  seeker is held in the lobby (blinded + heavily slowed so they can't peek) while a `Hide! Xs` action
  bar counts down.
- **Hunt phase (8 min)**: the seeker is released to the start point with their kit; a boss bar shows
  match time and shifts green → yellow → red as time runs low. A seeker hit marks a hider as
  caught → spectator. Hiders surviving the full 8 minutes win; if all hiders are caught first, the
  seeker wins.
- **Ending**: results are broadcast (with a win jingle), stats saved, everyone returned to that map's
  lobby, then a 30s "Next match in Xs" countdown loops back to waiting.
- Anyone who joins mid-match is put in spectator mode and moved to the current lobby once the match
  ends. Hiders who get caught become spectators for the rest of the match. If the seeker
  disconnects, the match is cancelled immediately.
- The leaderboard book (page 1: top hiders by wins, page 2: top seekers by wins) is only given while
  in the lobby, from `stats.yml` (persists across restarts).

## Items

**Seeker**: Mace, self-refilling Wind Charges, self-refilling Ender Pearls, a one-shot Netherite
Sword (massive bonus attack-damage attribute), Bow + Infinity enchant (1 arrow, never runs out), and
exactly 3 Reveal Snowballs (right-click: all hiders glow cyan, seeker glows red, both for 20s, with a
countdown shown in the action bar).

**Hider**: a stack of Ender Pearls, a stack of Wind Charges (both self-refilling), a Knockback X
"Panic Stick" good for exactly 3 hits before it breaks, a "Troll Seeker" sugar (right-click: 5s of
blinking red glow on the hider, with the countdown shown on both the hider's and seeker's XP bar), and
a "Spectate Seeker" compass (right-click: toggles spectator-mode camera lock onto the seeker's POV,
right-click again to return to your body).

Both kits above are just the **defaults** — use `/inv edit seeker` or `/inv edit hider` to customize
them per-server; the plugin will use your saved version from then on. Hiders' nametags are hidden via
a scoreboard team for the whole match.

## Files the plugin creates

- `maps.yml` — every map's id + start/lobby locations
- `kits.yml` — your custom seeker/hider kits (only written once you save via `/inv edit`)
- `stats.yml` — persisted leaderboard stats
- `config.yml` — timers and counts (`settings:` block)

## Notes / things you may want to tweak

- Only one seeker is selected per match. For multiple seekers on big player counts, that's a
  follow-up change to `beginRoleReveal()` in `GameManager.java`.
- "Trapped in the lobby" during hide phase is done with Blindness + heavy Slowness + Jump Boost
  rather than a physical cage — if your lobby build already encloses the seeker, you can drop those
  potion effects.
- The sword/mace "one-shot kill" doesn't actually let the hider die (no death screen); it's
  intercepted and converted straight into a "caught → spectator" state.
- Fall damage, drowning, fire, etc. are disabled during hide/hunt phases so the only way to lose is
  being caught by the seeker.
- "Spectate seeker" uses Bukkit's supported spectator camera lock rather than full NMS camera
  packets — the hider briefly enters spectator mode themselves while locked on.

## New in this update

### Mid-match spectating & rejoining

There are two states for a player who isn't currently hiding/seeking during a live match:

- **Full spectator** (free-cam, `GameMode.SPECTATOR`): hotbar slot 1 is a **Spectate** compass that
  opens a chest of every alive hider's head (name shown in cyan) and the seeker(s)' heads (name shown
  in red) — click a head to teleport to that player. Hotbar slot 9 is a **Stop Spectating** poppy that
  drops you into the mid-match lobby in adventure mode.
- **Mid-match lobby** (adventure mode, standing at the map's lobby): hotbar slot 1 is an iron sword,
  **"Join as a Hunter/Seeker"** — right-click to become an extra seeker and get summoned into the map
  with a seeker kit. Hotbar slot 2 is a **Spectate** compass that sends you back into full spectator
  mode inside the map. Hotbar slot 9 is the leaderboard book.

You land in full spectator mode automatically when you join mid-match or when you're caught as a
hider.

This is separate from the between-match lobby (waiting for the next match), where players only ever
get the leaderboard book + profile head — none of the above items appear there.

### Player profiles

In the between-match lobby only, every player gets their own skinned head at hotbar slot 5
("Your Profile"). Right-click it to see your own stats (wins, rounds, catches, survives, win rate) in
a chest GUI. **Sneak + right-click any player, anywhere, anytime** (not just the lobby) to view their
profile the same way.

### Per-role console commands

```
/cmd set seeker effect give %player% night_vision 999999 0 true
/cmd set hider effect give %player% speed 999999 1 true
```

`%player%` is replaced with the player's name; the command runs from console the moment a player is
*assigned* that role at the end of the role-reveal spin (not when they're teleported into the map).
Extra seekers who join mid-match via the sword also trigger the seeker command.

### Better scoreboard

The sidebar now shows the current map name, phase (Starting / Picking Map / Assigning Roles / Hiding
/ Hunting / Match Over), a live timer, all seeker(s) in red, and hiders alive vs. caught (caught names
shown struck through), with a fraction count like `Hiders (3/5)`.

## Updated file list

- `maps.yml` — map ids + start/lobby locations
- `kits.yml` — custom seeker/hider kits (from `/inv edit`)
- `stats.yml` — leaderboard stats
- `role-commands.yml` — the `/cmd set seeker|hider` commands
- `config.yml` — timers and counts
